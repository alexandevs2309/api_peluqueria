from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model
from django.db import transaction

from .models import AuditLog

User = get_user_model()

def migrate_existing_logs():
    """
    Función para migrar todos los logs existentes al nuevo sistema unificado
    """
    migrated_count = 0
    
    # Migrar LoginAudit
    try:
        from apps.auth_api.models import LoginAudit
        for log in LoginAudit.objects.all():
            AuditLog.objects.create(
                user=log.user,
                action='LOGIN' if log.successful else 'LOGIN_FAILED',
                description=f"Intento de login {'exitoso' if log.successful else 'fallido'}",
                ip_address=log.ip_address,
                user_agent=log.user_agent,
                timestamp=log.timestamp,
                source='AUTH',
                extra_data={
                    'original_model': 'LoginAudit',
                    'original_id': log.id,
                    'successful': log.successful
                }
            )
            migrated_count += 1
    except ImportError:
        pass
    
    # Migrar AccessLog
    try:
        from apps.auth_api.models import AccessLog
        action_mapping = {
            'LOGIN': 'LOGIN',
            'LOGOUT': 'LOGOUT',
            'PASSWORD_CHANGE': 'PASSWORD_CHANGE',
            'ACTIVE_SESSIONS_VIEW': 'VIEW',
        }
        
        for log in AccessLog.objects.all():
            action = action_mapping.get(log.event_type, 'VIEW')
            AuditLog.objects.create(
                user=log.user,
                action=action,
                description=f"Evento: {log.event_type}",
                ip_address=log.ip_address,
                user_agent=log.user_agent,
                timestamp=log.timestamp,
                source='AUTH',
                extra_data={
                    'original_model': 'AccessLog',
                    'original_id': log.id,
                    'event_type': log.event_type
                }
            )
            migrated_count += 1
    except ImportError:
        pass
    
    # Migrar AdminActionLog
    try:
        from apps.roles_api.models import AdminActionLog
        for log in AdminActionLog.objects.all():
            AuditLog.objects.create(
                user=log.user,
                action='ADMIN_ACTION',
                description=log.action,
                ip_address=log.ip_address,
                timestamp=log.timestamp,
                source='ROLES',
                extra_data={
                    'original_model': 'AdminActionLog',
                    'original_id': log.id
                }
            )
            migrated_count += 1
    except ImportError:
        pass
    
    # Migrar SettingAuditLog
    try:
        from apps.settings_api.models import SettingAuditLog
        for log in SettingAuditLog.objects.all():
            content_type = ContentType.objects.get_for_model(log.setting)
            AuditLog.objects.create(
                user=log.changed_by,
                action='SETTING_UPDATE',
                description=f"Configuración actualizada: {log.change_summary}",
                content_type=content_type,
                object_id=log.setting.id,
                timestamp=log.changed_at,
                source='SETTINGS',
                extra_data={
                    'original_model': 'SettingAuditLog',
                    'original_id': log.id,
                    'change_summary': log.change_summary
                }
            )
            migrated_count += 1
    except ImportError:
        pass
    
    # Migrar SubscriptionAuditLog
    try:
        from apps.subscriptions_api.models import SubscriptionAuditLog
        action_mapping = {
            'created': 'SUBSCRIPTION_CREATE',
            'updated': 'SUBSCRIPTION_UPDATE',
            'cancelled': 'SUBSCRIPTION_CANCEL',
            'renewed': 'SUBSCRIPTION_RENEW',
            'plan_changed': 'SUBSCRIPTION_UPDATE',
        }
        
        for log in SubscriptionAuditLog.objects.all():
            content_type = ContentType.objects.get_for_model(log.subscription)
            action = action_mapping.get(log.action, 'SUBSCRIPTION_UPDATE')
            
            AuditLog.objects.create(
                user=log.user,
                action=action,
                description=f"Suscripción {log.action}",
                content_type=content_type,
                object_id=log.subscription.id,
                timestamp=log.created_at,
                source='SUBSCRIPTIONS',
                extra_data={
                    'original_model': 'SubscriptionAuditLog',
                    'original_id': log.id,
                    'action': log.action
                }
            )
            migrated_count += 1
    except ImportError:
        pass
    
    return migrated_count

def get_client_ip(request):
    """Obtiene la IP real del cliente considerando proxies"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def create_audit_log(user, action, description, content_object=None, 
                    ip_address=None, user_agent='', source='SYSTEM', 
                    extra_data=None, request=None):
    """
    Función helper para crear logs de auditoría de forma unificada
    """
    # Si se pasa request, extraer IP y user agent automáticamente
    if request:
        ip_address = ip_address or get_client_ip(request)
        user_agent = user_agent or request.META.get('HTTP_USER_AGENT', '')
    
    kwargs = {
        'user': user,
        'action': action,
        'description': description,
        'ip_address': ip_address,
        'user_agent': user_agent or '',
        'source': source,
    }
    
    if content_object:
        # Para GenericForeignKey, necesitamos establecer content_type y object_id explícitamente
        try:
            from django.contrib.contenttypes.models import ContentType
            kwargs['content_type'] = ContentType.objects.get_for_model(content_object)
        except Exception:
            # Si la tabla contenttypes no existe aún (durante migraciones), saltar
            kwargs['content_type'] = None

        # Manejar diferentes tipos de objetos que pueden no tener un atributo 'id' estándar.
        # OJO: object_id es PositiveIntegerField. Los modelos con pk UUID (Payment,
        # PaymentProof) no caben ahí y PostgreSQL abortaba la transacción con
        # "integer out of range". Para esos se registra el content_type y se deja
        # object_id vacío: el uuid real queda en extra_data y en la descripción.
        object_ref = None
        if hasattr(content_object, 'id'):
            object_ref = content_object.id
        elif hasattr(content_object, 'pk'):
            object_ref = content_object.pk

        if isinstance(object_ref, int):
            kwargs['object_id'] = object_ref
        else:
            kwargs['object_id'] = None
    
    if extra_data:
        kwargs['extra_data'] = extra_data
    
    try:
        # savepoint: si el INSERT falla, la transacción externa sigue siendo
        # utilizable. Antes un fallo aqui dejaba la transacción rota y la
        # vista devolvía 500 aunque el pago se hubiera procesado bien.
        with transaction.atomic():
            return AuditLog.objects.create(**kwargs)
    except Exception as e:
        # Durante migraciones o estados tempranos de la app la tabla puede no existir.
        # No queremos que una auditoría impida el procedimiento principal (migrate/tests).
        import logging
        logger = logging.getLogger(__name__)
        logger.debug("No se pudo crear AuditLog (ignorado): %s", e)
        return None
