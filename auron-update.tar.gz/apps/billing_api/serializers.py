from rest_framework import serializers
from django.utils import timezone
from .models import Invoice, PaymentAttempt


class PaymentAttemptSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentAttempt
        fields = ["id", "invoice", "attempted_at", "success", "status"]
        read_only_fields = ["id", "attempted_at"]

    def validate(self, data):
        request = self.context.get('request')
        if not request or not request.user or not request.user.is_authenticated:
            return data

        if request.user.is_superuser:
            return data

        invoice = data.get('invoice')
        if invoice:
            if invoice.user != request.user:
                tenant_id = getattr(getattr(request, 'tenant', None), 'id', None) or getattr(request.user, 'tenant_id', None)
                if not (tenant_id and invoice.user and invoice.user.tenant_id == tenant_id):
                    raise serializers.ValidationError("No tiene permiso para registrar intentos en esta factura.")

        return data


class InvoiceSerializer(serializers.ModelSerializer):
    user_email = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    tenant_name = serializers.SerializerMethodField()
    plan_name = serializers.SerializerMethodField()
    paid_at = serializers.DateTimeField(read_only=True)
    proof = serializers.SerializerMethodField()

    class Meta:
        model = Invoice
        fields = [
            "id", "user", "user_email", "user_name", "tenant_name",
            "subscription", "plan_name", "amount", "description",
            "due_date", "is_paid", "paid_at", "issued_at", "status",
            "payment_method", "proof",
            "discard_reason", "discarded_at",
        ]
        read_only_fields = [
            "id", "user", "amount", "is_paid", "issued_at", "status", "paid_at"
        ]

    def get_user_email(self, obj):
        return obj.user.email if obj.user else None

    def get_user_name(self, obj):
        if obj.user:
            return getattr(obj.user, 'full_name', None) or f"{obj.user.first_name} {obj.user.last_name}".strip() or obj.user.email
        return None

    def get_tenant_name(self, obj):
        if obj.user and hasattr(obj.user, 'tenant') and obj.user.tenant:
            return obj.user.tenant.name
        return None

    def get_plan_name(self, obj):
        if obj.subscription and hasattr(obj.subscription, 'plan') and obj.subscription.plan:
            return obj.subscription.plan.get_name_display()
        return None

    def get_proof(self, obj):
        payment = getattr(obj, 'payment', None)
        if not payment:
            return None
        try:
            proof = payment.proofs.select_related('reviewed_by').order_by('-created_at', '-id').first()
        except Exception:
            return None
        if not proof:
            return None
        file_url = None
        if proof.file:
            # El archivo NUNCA se expone como URL publica de MEDIA: solo se
            # descarga por el endpoint protegido, que valida permisos.
            file_url = f"/api/payments/manual/proof/{proof.id}/"

        return {
            'id': str(proof.id),
            'decision': proof.decision,
            'decision_note': proof.decision_note,
            'reviewed_at': proof.reviewed_at,
            'bank_reference': proof.bank_reference,
            'amount_provided': float(proof.amount_provided) if proof.amount_provided is not None else None,
            'created_at': proof.created_at,
            'file_name': proof.file_name or '',
            'file_url': file_url,
        }

    def validate_amount(self, value):
        """Validar que el monto sea positivo"""
        if value <= 0:
            raise serializers.ValidationError("El monto debe ser mayor a cero")
        return value

    def validate_due_date(self, value):
        """Validar que la fecha de vencimiento sea futura"""
        if value <= timezone.now():
            raise serializers.ValidationError("La fecha de vencimiento debe ser futura")
        return value

    def validate(self, data):
        """Validaciones adicionales"""
        # Si hay una suscripción, verificar que pertenezca al usuario
        request = self.context.get('request')
        if request and data.get('subscription'):
            if data['subscription'].user != request.user:
                raise serializers.ValidationError("La suscripción no pertenece al usuario actual")

        return data
