import sys
import json
import logging
import uuid
import hashlib

def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _auth_error(code: str, message: str, http_status: int, details=None) -> 'Response':
    """Error controlado con el mismo contrato que el registro."""
    return Response(
        {
            'error': message,
            'code': code,
            'type': 'VALIDATION' if http_status < 500 else 'SYSTEM',
            'message': message,
            'details': details or {},
        },
        status=http_status,
    )


def _resolve_password_token(uid: str, token: str):
    """Devuelve ``(user, error_message)`` validando uid + token de un solo uso."""
    if not uid or not token:
        return None, 'El enlace es inválido o está incompleto.'
    try:
        user_id = force_str(urlsafe_base64_decode(uid))
        user = User.objects.get(pk=user_id)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        return None, 'El enlace es inválido o ya fue utilizado.'

    if not default_token_generator.check_token(user, token):
        return None, 'El enlace es inválido, expiró o ya fue utilizado.'
    return user, None
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.exceptions import NotFound, ValidationError
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.throttling import UserRateThrottle, AnonRateThrottle
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from apps.emails.service import EmailRenderer
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.conf import settings
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError
from django_ratelimit.decorators import ratelimit
from django.utils.decorators import method_decorator
from drf_spectacular.utils import extend_schema
from .models import User, AccessLog
from .serializers import (
    ActiveSessionSerializer, RegisterSerializer, LoginSerializer,
    PasswordChangeSerializer, PasswordResetRequestSerializer,
    PasswordResetConfirmSerializer, SetInitialPasswordSerializer,
    MFASetupSerializer, MFAVerifySerializer,
    EmployeeUserSerializer, UserListSerializer, get_explicit_tenant_input,
    ResendVerificationSerializer
)
from .cookie_utils import set_auth_cookies
from .role_utils import (
    get_effective_role_api,
    get_effective_role_name,
    map_business_role_to_legacy_role,
)
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework import viewsets
from rest_framework.decorators import action
from apps.tenants_api.models import Tenant
from apps.subscriptions_api.models import SubscriptionPlan
from apps.roles_api.models import Role, UserRole
from apps.roles_api.default_permissions import ensure_role_default_permissions
import re
from datetime import timedelta
from .models import LoginAudit, AccessLog, ActiveSession
from .utils import get_client_ip, get_user_agent, get_client_jti
from .settings_policy import is_mfa_globally_enabled, get_jwt_expiry_minutes
from .login_policy import is_login_locked_out, get_login_lockout_message
from apps.settings_api.utils import maybe_auto_upgrade_user_limit

from django.utils.timezone import now
import pyotp
import qrcode
from io import BytesIO
from base64 import b64encode
from .authentication import DualJWTAuthentication


from apps.roles_api.role_hierarchy import validate_role_assignment, get_allowed_roles, can_modify_user
from apps.core.tenant_permissions import TenantPermissionByAction, resolve_request_tenant, _check_permission_in_db


User = get_user_model()
logger = logging.getLogger(__name__)

# Helper function to safely create audit logs
def _resolve_tenant(request, user=None):
    tenant = getattr(request, 'tenant', None)
    if tenant is not None:
        return tenant
    if user is not None and user.is_authenticated:
        return getattr(user, 'tenant', None)
    return None

def safe_create_login_audit(user, request, successful, message):
    """Crear LoginAudit truncando campos largos"""
    return LoginAudit.objects.create(
        tenant=_resolve_tenant(request, user),
        user=user,
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request)[:255] if get_user_agent(request) else '',
        successful=successful,
        message=str(message)[:255] if message else '',
        timestamp=now()
    )

def safe_create_access_log(user, event_type, request):
    """Crear AccessLog truncando campos largos"""
    return AccessLog.objects.create(
        tenant=_resolve_tenant(request, user),
        user=user,
        event_type=event_type,
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request)[:255] if get_user_agent(request) else '',
        timestamp=now()
    )


def issue_refresh_for_user(user, tenant=None):
    refresh = RefreshToken.for_user(user)
    access_token = refresh.access_token
    access_token.set_exp(lifetime=timedelta(minutes=get_jwt_expiry_minutes()))

    if tenant:
        refresh['tenant_id'] = tenant.id
        refresh['tenant_subdomain'] = tenant.subdomain
        access_token['tenant_id'] = tenant.id
        access_token['tenant_subdomain'] = tenant.subdomain

    return refresh, access_token

def _resolve_business_branding(user, request=None):
    business_name = 'Auron Suite'
    logo_url = ''

    if getattr(user, 'tenant', None):
        try:
            from apps.settings_api.barbershop_models import BarbershopSettings
            shop_settings = BarbershopSettings.objects.filter(tenant=user.tenant).first()
            if shop_settings:
                business_name = shop_settings.name or business_name
                if shop_settings.logo:
                    raw_logo = shop_settings.logo.url
                    if request is not None:
                        logo_url = request.build_absolute_uri(raw_logo)
                    else:
                        frontend_url = (getattr(settings, 'FRONTEND_URL', '') or 'http://localhost:4200').rstrip('/')
                        logo_url = f"{frontend_url}{raw_logo}" if raw_logo.startswith('/') else f"{frontend_url}/{raw_logo}"
        except Exception:
            pass

        if user.tenant.name and business_name == 'Auron Suite':
            business_name = user.tenant.name

    return business_name, logo_url

def _render_email_html(template_name, user, title, content='', cta_url=None, cta_label=None, request=None):
    business_name, logo_url = _resolve_business_branding(user, request=request)
    return EmailRenderer.render(template_name, {
        'business_name': business_name,
        'logo_url': logo_url,
        'title': title,
        'content': content,
        'cta_url': cta_url,
        'cta_label': cta_label or 'Abrir enlace',
        'user_full_name': user.full_name or user.email,
        'support_url': getattr(settings, 'SUPPORT_URL', ''),
    })

def _deliver_user_email(user, subject, text_body, html_body):
    from apps.auth_api.tasks import send_email_async
    send_email_async.delay(
        subject=subject,
        message=text_body,
        from_email='',
        recipient_list=[user.email],
        html_message=html_body,
    )

class RegisterThrottle(AnonRateThrottle):
    scope = 'register'

class LoginThrottle(AnonRateThrottle):
    scope = 'login'

class PasswordResetThrottle(AnonRateThrottle):
    scope = 'password_reset'

class MFAVerifyThrottle(UserRateThrottle):
    scope = 'mfa_verify'

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]
    throttle_classes = [RegisterThrottle]

    def perform_create(self, serializer):
        from django.db import transaction
        
        email = serializer.validated_data['email']
        
        # Transacción atómica para garantizar tenant antes de usuario
        with transaction.atomic():
            # Usar el plan seleccionado por el usuario o Basic como default para trial
            plan_name = self.request.data.get('planType', '').lower() or 'basic'
            starter_plan = SubscriptionPlan.objects.filter(name=plan_name).first()
            if not starter_plan:
                starter_plan = SubscriptionPlan.objects.filter(name='basic').first()
            if not starter_plan:
                starter_plan = SubscriptionPlan.objects.first()
            
            # Crear subdomain único
            full_name = serializer.validated_data.get('full_name', 'barbershop')
            subdomain = re.sub(r'[^a-zA-Z0-9]', '', full_name.lower())[:50]
            if not subdomain or len(subdomain) < 3:
                subdomain = 'barbershop'
            
            counter = 1
            original_subdomain = subdomain
            while Tenant.objects.filter(subdomain=subdomain).exists():
                subdomain = f'{original_subdomain}{counter}'
                counter += 1
            
            # Crear nombre de tenant único
            tenant_name = f'Barbería de {full_name}'
            counter = 1
            original_name = tenant_name
            while Tenant.objects.filter(name=tenant_name).exists():
                tenant_name = f'{original_name} {counter}'
                counter += 1
            
            # Crear tenant PRIMERO
            tenant = Tenant.objects.create(
                name=tenant_name,
                subdomain=subdomain,
                owner=None,
                subscription_plan=starter_plan,
                is_active=True
            )
            
            # Crear usuario con tenant asignado
            user = serializer.save(tenant=tenant)
            user.email_verification_token = uuid.uuid4().hex
            user.save(update_fields=['email_verification_token'])

            # Actualizar owner del tenant
            tenant.owner = user
            tenant.save(update_fields=['owner'])
            
            # Asignar rol Client-Admin
            try:
                client_admin_role = Role.objects.get(name='Client-Admin')
                ensure_role_default_permissions(client_admin_role)
                UserRole.objects.create(
                    user=user,
                    role=client_admin_role,
                    tenant=tenant
                )
            except Role.DoesNotExist:
                pass
        
        # Enviar email de verificación (fuera de transacción)
        email_subject = "Verifica tu correo"
        frontend_url = (getattr(settings, 'FRONTEND_URL', '') or 'http://localhost:4200').rstrip('/')
        verify_url = f"{frontend_url}/auth/verify-email/{user.email_verification_token}/"
        email_body = f"Hola {user.full_name}, verifica tu correo en: {verify_url}"
        email_html = _render_email_html(
            'verify_email.html',
            user=user,
            title=email_subject,
            cta_url=verify_url,
            cta_label='Verificar correo',
        )
        _deliver_user_email(user, email_subject, email_body, email_html)

class LoginView(generics.GenericAPIView):
    serializer_class = LoginSerializer
    permission_classes = [AllowAny]
    throttle_classes = [LoginThrottle]

    @method_decorator(ratelimit(key='ip', rate='10/m', method='POST', block=True))
    def post(self, request, *args, **kwargs):
        # Rate limit por tenant
        tenant_subdomain = get_explicit_tenant_input(request.data)
        email = (request.data.get('email') or '').strip().lower()
        ip_address = get_client_ip(request)
        user_for_lockout = None

        if email:
            if tenant_subdomain:
                tenant_for_lockout = Tenant.objects.filter(subdomain=tenant_subdomain).first()
                if tenant_for_lockout:
                    user_for_lockout = User.objects.filter(email__iexact=email, tenant=tenant_for_lockout).first()
            else:
                user_for_lockout = User.objects.filter(
                    email__iexact=email,
                    is_superuser=True,
                    tenant__isnull=True
                ).first()

        if is_login_locked_out(user=user_for_lockout, ip_address=ip_address):
            return Response({"detail": get_login_lockout_message()}, status=status.HTTP_429_TOO_MANY_REQUESTS)

        if tenant_subdomain:
            from django_ratelimit.core import is_ratelimited
            if is_ratelimited(request, group='tenant_login', key=lambda r, g: tenant_subdomain, rate='20/m', method='POST'):
                return Response({"detail": "Demasiados intentos de login para este tenant."}, status=status.HTTP_429_TOO_MANY_REQUESTS)
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError as e:
            if tenant_subdomain:
                try:
                    tenant = Tenant.objects.get(subdomain=tenant_subdomain)
                    user = User.objects.filter(email__iexact=email, tenant=tenant).first()
                except (Tenant.DoesNotExist, User.DoesNotExist):
                    user = None
            else:
                user = User.objects.filter(
                    email__iexact=email,
                    is_superuser=True,
                    tenant__isnull=True
                ).first()
            
            safe_create_login_audit(
                user=user,
                request=request,
                successful=False,
                message=f"Credenciales inválidas - Tenant: {tenant_subdomain or 'unknown'}"
            )
            raise
        
        user = serializer.validated_data['user']
        tenant = serializer.validated_data['tenant']

        user_role_api = get_effective_role_api(user, tenant=tenant)
        if not tenant and user_role_api != 'SUPER_ADMIN':
            return Response({"detail": "Usuario sin tenant asignado. Contacte al administrador."}, status=status.HTTP_400_BAD_REQUEST)

        if not user.is_active:
            LoginAudit.objects.create(
                user=user,
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                successful=False,
                message="Cuenta inactiva"[:255],
                timestamp=now()
            )
            return Response({"detail": "Cuenta inactiva. Contacte al administrador."}, status=status.HTTP_403_FORBIDDEN)

        if is_mfa_globally_enabled() and user.mfa_enabled:
            tenant_data = {"id": tenant.id, "subdomain": tenant.subdomain} if tenant else None
            return Response({
                "detail": "Se requiere verificación MFA.",
                "email": user.email,
                "tenant": tenant_data
            }, status=status.HTTP_200_OK)

        refresh, access = issue_refresh_for_user(user, tenant)
        access_token = str(access)
        refresh_token = str(refresh)
        jti = get_client_jti(access_token)

        ActiveSession.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            token_jti=jti,
            refresh_token=hash_token(refresh_token),
            is_active=True,
            tenant=tenant
        )

        AccessLog.objects.create(
            user=user,
            event_type='LOGIN',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )
        LoginAudit.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            successful=True,
            message="Inicio de sesión exitoso"[:255],
            timestamp=now()
        )

        user_role = get_effective_role_api(user, tenant=tenant)
        
        response_data = {
            'user': {
                'id': user.id,
                'email': user.email,
                'full_name': user.full_name,
                'role': user_role,
            },
        }
        
        if tenant:
            response_data['tenant'] = {
                'id': tenant.id,
                'name': tenant.name,
                'subdomain': tenant.subdomain,
            }

        response = Response(response_data)
        return set_auth_cookies(
            response,
            access_token=access_token,
            refresh_token=refresh_token,
            access_max_age=get_jwt_expiry_minutes() * 60,
            refresh_max_age=24 * 60 * 60,
            tenant_id=tenant.id if tenant else None,
        )

class LogoutView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        # Try to get refresh_token from cookies first, then from body
        refresh_token = request.COOKIES.get('refresh_token') or request.data.get('refresh_token')
        
        # Always return success response
        response = Response({"detail": "Sesión cerrada exitosamente."}, status=status.HTTP_200_OK)
        response.delete_cookie('access_token')
        response.delete_cookie('refresh_token')
        
        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
                
                # Try to find and expire session
                try:
                    session = ActiveSession.objects.get(refresh_token=hash_token(refresh_token))
                    session.expire_session()
                    
                    # Log successful logout if we have a user
                    if hasattr(request, 'user') and request.user.is_authenticated:
                        AccessLog.objects.create(
                            user=request.user,
                            event_type='LOGOUT',
                            ip_address=get_client_ip(request),
                            user_agent=get_user_agent(request)[:255],
                            timestamp=now()
                        )
                except ActiveSession.DoesNotExist:
                    pass
                    
            except TokenError:
                # Token invalid/expired, but still return success
                pass
        
        return response

class ChangePasswordView(generics.UpdateAPIView):
    serializer_class = PasswordChangeSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        serializer = self.get_serializer(data=request.data)

        if serializer.is_valid():
            if not user.check_password(serializer.validated_data.get("old_password")):
                return Response({"old_password": ["Contraseña incorrecta."]}, status=status.HTTP_400_BAD_REQUEST)

            user.set_password(serializer.validated_data.get("new_password"))
            user.save()

            AccessLog.objects.create(
                user=user,
                event_type='PASSWORD_CHANGE',
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                timestamp=now()
            )

            subject = "Cambio de contraseña exitoso"
            text_body = f"Hola {user.full_name}, tu contraseña ha sido cambiada exitosamente."
            html_body = _render_email_html(
                'password_changed.html',
                user=user,
                title=subject,
                request=request,
            )
            _deliver_user_email(user, subject, text_body, html_body)

            return Response({"detail": "Contraseña actualizada correctamente."})

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [PasswordResetThrottle]

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = (serializer.validated_data.get('email') or '').strip().lower()
        tenant_subdomain = get_explicit_tenant_input(serializer.validated_data)
        try:
            target_users = []
            if tenant_subdomain:
                # Permitir también negocios inactivos/suspendidos: su dueño necesita
                # recuperar acceso para poder regularizar la suscripción.
                tenant = Tenant.objects.filter(
                    subdomain=tenant_subdomain,
                    deleted_at__isnull=True
                ).first()
                if not tenant:
                    return Response(
                        {"detail": f"No se encontró un negocio con el subdominio '{tenant_subdomain}'."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                target_users = list(
                    User.objects.filter(email=email, tenant=tenant)[:1]
                )
            else:
                target_users = list(User.objects.filter(email=email).select_related('tenant')[:2])
                distinct_tenants = {user.tenant_id for user in target_users}
                if len(distinct_tenants) > 1:
                    return Response({
                        "detail": "Tu correo está asociado a varios negocios. Ingresa el subdominio del negocio.",
                        "code": "tenant_required",
                    }, status=status.HTTP_400_BAD_REQUEST)

            if not target_users:
                return Response({"detail": "Correo enviado si el usuario existe."}, status=status.HTTP_200_OK)

            # Use environment variable for frontend URL
            frontend_url = getattr(settings, 'ADMIN_FRONTEND_URL', '') or (getattr(settings, 'FRONTEND_URL', '') or 'http://localhost:4200')

            for user in target_users:
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                token = default_token_generator.make_token(user)
                reset_url = f"{frontend_url}/auth/reset-password/{uid}/{token}"

                AccessLog.objects.create(
                    user=user,
                    event_type='PASSWORD_RESET_REQUEST',
                    ip_address=get_client_ip(request),
                    user_agent=get_user_agent(request)[:255],
                    timestamp=now()
                )

                if settings.DEBUG:
                    logger.debug(
                        "Password reset link generated for user_id=%s reset_url=%s",
                        user.id,
                        reset_url,
                    )

                subject = "Restablecer contraseña"
                text_body = f"Hola {user.full_name}, para restablecer tu contraseña haz clic en el siguiente enlace:\n{reset_url}"
                html_body = _render_email_html(
                    'password_reset.html',
                    user=user,
                    title=subject,
                    cta_url=reset_url,
                    cta_label='Restablecer contraseña',
                    request=request,
                )
                try:
                    _deliver_user_email(user, subject, text_body, html_body)
                except Exception as exc:
                    return Response(
                        {"detail": f"Error al enviar correo: {exc}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    )

            return Response({"detail": "Correo enviado para restablecer contraseña."}, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            return Response({"detail": "Correo enviado si el usuario existe."}, status=status.HTTP_200_OK)

class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        AccessLog.objects.create(
            user=user,
            event_type='PASSWORD_RESET_CONFIRM',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )

        subject = "Contraseña restablecida"
        text_body = f"Hola {user.full_name}, tu contraseña ha sido restablecida exitosamente."
        html_body = _render_email_html(
            'password_reset_confirmed.html',
            user=user,
            title=subject,
            request=request,
        )
        _deliver_user_email(user, subject, text_body, html_body)

        return Response({"detail": "Contraseña restablecida con éxito."})

@extend_schema(
    responses={200: ActiveSessionSerializer(many=True)},
    description="Lista de sesiones activas del usuario autenticado."
)
class ActiveSessionsView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ActiveSessionSerializer
    pagination_class = LimitOffsetPagination

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return ActiveSession.objects.none()
        return ActiveSession.objects.filter(user=self.request.user, is_active=True)

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)  # Aplicar paginación
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            AccessLog.objects.create(
                user=request.user,
                event_type='ACTIVE_SESSIONS_VIEW',
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                timestamp=now()
            )
            return self.get_paginated_response(serializer.data)  # Devolver respuesta paginada
        serializer = self.get_serializer(queryset, many=True)
        AccessLog.objects.create(
            user=request.user,
            event_type='ACTIVE_SESSIONS_VIEW',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )
        return Response(serializer.data)

class TerminateSessionView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, jti):
        try:
            session = ActiveSession.objects.get(token_jti=jti, user=request.user, is_active=True)
            session.expire_session()
            AccessLog.objects.create(
                user=request.user,
                event_type='SESSION_TERMINATED',
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                timestamp=now()
            )
            return Response({"detail": "Sesión terminada exitosamente."}, status=status.HTTP_200_OK)
        except ActiveSession.DoesNotExist:
            raise NotFound("Sesión no encontrada o ya terminada.")

class VerifyEmailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, token):
        if not token:
            return _auth_error(
                'INVALID_VERIFICATION_TOKEN',
                'Token inválido: el enlace de verificación es inválido.',
                status.HTTP_400_BAD_REQUEST,
            )

        from apps.auth_api.onboarding import is_email_verification_token_valid
        user = User.objects.filter(email_verification_token=token).first()
        if user is None or not is_email_verification_token_valid(token):
            return _auth_error(
                'INVALID_VERIFICATION_TOKEN',
                'Token inválido: el enlace de verificación expiró o ya fue utilizado.',
                status.HTTP_400_BAD_REQUEST,
            )

        if getattr(user, 'is_email_verified', False):
            return Response(
                {'detail': 'Tu correo ya estaba verificado.', 'email_verified': True},
                status=status.HTTP_200_OK,
            )

        user.is_email_verified = True
        user.email_verification_token = None
        user.save(update_fields=['is_email_verified', 'email_verification_token'])
        AccessLog.objects.create(
            user=user,
            event_type='EMAIL_VERIFIED',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now(),
        )
        return Response(
            {'detail': 'Correo verificado exitosamente.', 'email_verified': True},
            status=status.HTTP_200_OK,
        )


class SetInitialPasswordView(APIView):
    """Valida y consume el enlace de un solo uso para crear la contraseña."""

    permission_classes = [AllowAny]
    throttle_classes = [PasswordResetThrottle]

    def get_throttles(self):
        # La validación del enlace al abrir la página no debe consumir el
        # límite de intentos del POST.
        if self.request.method == 'GET':
            return []
        return super().get_throttles()

    def get(self, request):
        uid = request.query_params.get('uid') or ''
        token = request.query_params.get('token') or ''
        user, error = _resolve_password_token(uid, token)
        if error:
            return _auth_error(
                'INVALID_OR_EXPIRED_TOKEN',
                error,
                status.HTTP_400_BAD_REQUEST,
            )
        return Response({
            'valid': True,
            'email': user.email,
            'full_name': user.full_name,
        })

    def post(self, request):
        serializer = SetInitialPasswordSerializer(data=request.data)
        if not serializer.is_valid():
            first_error = next(iter(serializer.errors.values()))
            message = first_error[0] if isinstance(first_error, (list, tuple)) else str(first_error)
            return _auth_error(
                'INVALID_PASSWORD_OR_TOKEN',
                message,
                status.HTTP_400_BAD_REQUEST,
                details=serializer.errors,
            )

        user = serializer.save()
        AccessLog.objects.create(
            user=user,
            event_type='PASSWORD_CHANGE',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now(),
        )

        # Correo de confirmación (no bloquea la respuesta).
        try:
            subject = 'Contraseña creada'
            text_body = (
                f'Hola {user.full_name or user.email}, tu contraseña fue creada '
                'correctamente y tu correo quedó verificado.'
            )
            html_body = _render_email_html(
                'password_changed.html',
                user=user,
                title=subject,
                request=request,
            )
            _deliver_user_email(user, subject, text_body, html_body)
        except Exception:  # pragma: no cover - nunca falla la operación principal
            logger.exception('No se pudo encolar el correo de confirmación user_id=%s', user.pk)

        return Response({
            'detail': 'Contraseña creada correctamente. Ya puedes iniciar sesión.',
            'email_verified': True,
        }, status=status.HTTP_200_OK)


class ResendVerificationView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [PasswordResetThrottle]

    def post(self, request):
        serializer = ResendVerificationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email'].strip().lower()

        # Respuesta genérica por seguridad (evitar enumeración de usuarios)
        generic_response = Response(
            {"detail": "Si el correo está registrado y no verificado, se ha enviado un nuevo enlace de verificación."},
            status=status.HTTP_200_OK,
        )

        try:
            from apps.auth_api.onboarding import send_onboarding_email

            users = User.objects.filter(email__iexact=email, is_email_verified=False)
            for user in users:
                if not user.email_verification_token:
                    from apps.auth_api.onboarding import generate_email_verification_token
                    user.email_verification_token = generate_email_verification_token()
                    user.save(update_fields=['email_verification_token'])
                send_onboarding_email(user, getattr(user, 'tenant', None))

            return generic_response
        except Exception as e:
            logger.error("Error reenviando email de verificación a %s: %s", email, str(e))
            return generic_response

class MFASetupView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        if not is_mfa_globally_enabled():
            return Response({"error": "MFA está deshabilitado por configuración del sistema."}, status=status.HTTP_400_BAD_REQUEST)
        if user.mfa_enabled:
            return Response({"error": "MFA ya está habilitado."}, status=status.HTTP_400_BAD_REQUEST)

        secret = user.mfa_secret or pyotp.random_base32()
        if user.mfa_secret != secret:
            user.mfa_secret = secret
            user.save(update_fields=['mfa_secret'])

        totp = pyotp.TOTP(secret)
        qr_uri = totp.provisioning_uri(user.email, issuer_name="HairSalon")
        qr = qrcode.make(qr_uri)
        buffer = BytesIO()
        qr.save(buffer)
        qr_code = b64encode(buffer.getvalue()).decode()

        AccessLog.objects.create(
            user=user,
            event_type='MFA_SETUP',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )
        return Response({"qr_code": qr_code, "secret": secret})

class MFAVerifyView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_classes = [MFAVerifyThrottle]

    def post(self, request):
        if not is_mfa_globally_enabled():
            return Response({"error": "MFA está deshabilitado por configuración del sistema."}, status=status.HTTP_400_BAD_REQUEST)
        serializer = MFAVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user
        totp = pyotp.TOTP(user.mfa_secret)
        if totp.verify(serializer.validated_data['code'], valid_window=2):
            user.mfa_enabled = True
            user.save()
            AccessLog.objects.create(
                user=user,
                event_type='MFA_VERIFIED',
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                timestamp=now()
            )
            return Response({"detail": "MFA verificado y habilitado."})
        return Response({"error": "Código inválido."}, status=status.HTTP_400_BAD_REQUEST)


class MFADisableView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_classes = [MFAVerifyThrottle]

    def post(self, request):
        user = request.user
        if not user.mfa_enabled or not user.mfa_secret:
            return Response({"error": "MFA no está habilitado."}, status=status.HTTP_400_BAD_REQUEST)

        serializer = MFAVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        totp = pyotp.TOTP(user.mfa_secret)

        if not totp.verify(serializer.validated_data['code'], valid_window=2):
            return Response({"error": "Código inválido."}, status=status.HTTP_400_BAD_REQUEST)

        user.mfa_enabled = False
        user.mfa_secret = None
        user.save(update_fields=['mfa_enabled', 'mfa_secret'])

        AccessLog.objects.create(
            user=user,
            event_type='MFA_DISABLED',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )
        return Response({"detail": "MFA deshabilitado correctamente."})

class MFALoginVerifyView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key='ip', rate='10/m', method='POST', block=True))
    def post(self, request):
        if not is_mfa_globally_enabled():
            return Response({"error": "MFA está deshabilitado por configuración del sistema."}, status=status.HTTP_400_BAD_REQUEST)
        serializer = MFAVerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = request.data.get('email')
        tenant_subdomain = get_explicit_tenant_input(request.data)
        

        if not tenant_subdomain:
            return Response({"error": "Tenant requerido."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            tenant = Tenant.objects.get(subdomain=tenant_subdomain)
            user = User.objects.get(email=email, tenant=tenant)
        except (Tenant.DoesNotExist, User.DoesNotExist):
            return Response({"error": "Usuario o tenant no encontrado."}, status=status.HTTP_400_BAD_REQUEST)

        totp = pyotp.TOTP(user.mfa_secret)
        if not totp.verify(serializer.validated_data['code'], valid_window=2):
            LoginAudit.objects.create(
                user=user,
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                successful=False,
                message="Código MFA inválido"[:255],
                timestamp=now()
            )
            return Response({"error": "Código MFA inválido."}, status=status.HTTP_400_BAD_REQUEST)

        if is_login_locked_out(user=user, ip_address=get_client_ip(request)):
            return Response({"error": get_login_lockout_message()}, status=status.HTTP_429_TOO_MANY_REQUESTS)

        refresh, access = issue_refresh_for_user(user, tenant)
        access_token = str(access)
        refresh_token = str(refresh)
        jti = get_client_jti(access_token)

        ActiveSession.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            token_jti=jti,
            refresh_token=hash_token(refresh_token),
            is_active=True,
            tenant=tenant
        )

        AccessLog.objects.create(
            user=user,
            event_type='LOGIN_MFA',
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            timestamp=now()
        )
        LoginAudit.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=get_user_agent(request)[:255],
            successful=True,
            message="Inicio de sesión con MFA exitoso"[:255],
            timestamp=now()
        )

        user_role = get_effective_role_api(user, tenant=tenant)

        response_data = {
            'user': {
                'id': user.id,
                'email': user.email,
                'full_name': user.full_name,
                'role': user_role,
                'branch_id': user.employee_profile.branch_id if hasattr(user, 'employee_profile') and user.employee_profile else None,
            },
            'message': 'Inicio de sesión con MFA exitoso'
        }

        if tenant:
            response_data['tenant'] = {
                'id': tenant.id,
                'name': tenant.name,
                'subdomain': tenant.subdomain,
            }

        response = Response(response_data)

        return set_auth_cookies(
            response,
            access_token=access_token,
            refresh_token=refresh_token,
            access_max_age=get_jwt_expiry_minutes() * 60,
            refresh_max_age=24 * 60 * 60,
            tenant_id=tenant.id if tenant else None,
        )



class UserPermission(TenantPermissionByAction):
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False

        if request.user.is_superuser:
            return True

        tenant = resolve_request_tenant(request)
        if not tenant:
            return False

        action = self._resolve_action(request, view)
        if not action:
            return False

        return super().has_permission(request, view)

    def has_object_permission(self, request, view, obj):
        if not request.user or not request.user.is_authenticated:
            return False

        if request.user.is_superuser:
            return True

        tenant = resolve_request_tenant(request)
        if not tenant:
            return False

        if obj.tenant != tenant:
            return False

        action = self._resolve_action(request, view)
        if action in ['update', 'partial_update']:
            if obj.id == request.user.id:
                return True
            return _check_permission_in_db(request.user, tenant, 'auth_api', 'change_user')

        return super().has_object_permission(request, view, obj)


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.none()  # Seguro por defecto
    permission_classes = [UserPermission]
    permission_map = {
        'list': 'auth_api.view_user',
        'retrieve': 'auth_api.view_user',
        'create': 'auth_api.add_user',
        'update': 'auth_api.change_user',
        'partial_update': 'auth_api.change_user',
        'destroy': 'auth_api.delete_user',
        'available_for_employee': 'auth_api.view_user',
        'bulk_delete': 'auth_api.delete_user',
        'upload_avatar': 'auth_api.change_user',
    }
    serializer_class = UserListSerializer
    http_method_names = ['get', 'post', 'put', 'patch', 'delete']

    def _get_request_tenant(self):
        tenant = getattr(self.request, 'tenant', None)
        if tenant is not None:
            return tenant

        user = getattr(self.request, 'user', None)
        if getattr(user, 'is_authenticated', False):
            return getattr(user, 'tenant', None)

        return None

    def _is_tenant_admin_or_superuser(self, request) -> bool:
        """Solo SuperAdmin o Client-Admin pueden gestionar usuarios."""
        return get_effective_role_name(
            request.user,
            tenant=self._get_request_tenant(),
        ) in {'SuperAdmin', 'Client-Admin'}
    
    def destroy(self, request, *args, **kwargs):
        """Override destroy to add logging and proper deletion"""
        if not self._is_tenant_admin_or_superuser(request):
            return Response(
                {'error': 'Solo Client-Admin puede eliminar usuarios'},
                status=status.HTTP_403_FORBIDDEN
            )

        instance = self.get_object()
        logger.info("Attempting to delete user_id=%s by actor_id=%s", instance.id, request.user.id)
        
        # Check if user can be deleted
        if instance.is_superuser and User.objects.filter(is_superuser=True).count() <= 1:
            return Response({
                'error': 'Cannot delete the last superuser'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # Log the deletion
            AccessLog.objects.create(
                user=request.user,
                event_type='USER_DELETED',
                ip_address=get_client_ip(request),
                user_agent=get_user_agent(request)[:255],
                timestamp=now()
            )
            
            # Perform the deletion
            self.perform_destroy(instance)
            logger.info("User deleted successfully user_id=%s", instance.id)
            
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            logger.exception("Error deleting user_id=%s", instance.id)
            return Response({
                'error': f'Failed to delete user: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

    def perform_destroy(self, instance):
        """Actually delete the user instance"""
        instance.delete()

    def get_object(self):
        """
        Resolve detail objects without DRF filter backends interfering with
        DELETE/PUT lookups. This keeps the same visibility rules as get_queryset
        while avoiding false 404s on existing users.
        """
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        lookup_value = self.kwargs.get(lookup_url_kwarg)
        filter_kwargs = {self.lookup_field: lookup_value}

        obj = self.get_queryset().filter(**filter_kwargs).first()
        if obj is None:
            logger.warning(
                "User lookup failed user_id=%s actor_id=%s actor_superuser=%s actor_tenant_id=%s request_tenant_id=%s",
                lookup_value,
                getattr(self.request.user, 'id', None),
                getattr(self.request.user, 'is_superuser', False),
                getattr(getattr(self.request.user, 'tenant', None), 'id', None),
                getattr(getattr(self.request, 'tenant', None), 'id', None),
            )
            raise NotFound("Usuario no encontrado.")

        self.check_object_permissions(self.request, obj)
        return obj
    
    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return EmployeeUserSerializer
        return UserListSerializer

    def create(self, request, *args, **kwargs):
        if not self._is_tenant_admin_or_superuser(request):
            return Response(
                {'error': 'Solo Client-Admin puede crear usuarios'},
                status=status.HTTP_403_FORBIDDEN
            )

        # Check user limits for non-superadmin
        if not request.user.is_superuser and getattr(request, 'tenant', request.user.tenant):
            tenant = getattr(request, 'tenant', request.user.tenant)
            if not tenant.can_add_user():
                upgrade_result = maybe_auto_upgrade_user_limit(tenant, changed_by=request.user)
                tenant.refresh_from_db(fields=['plan_type', 'subscription_plan', 'max_employees', 'max_users', 'settings', 'updated_at'])
            if not tenant.can_add_user():
                error_message = 'User limit reached for your plan'
                if upgrade_result.get('reason') == 'no_higher_plan':
                    error_message = 'User limit reached and there is no higher plan available for automatic upgrade'
                return Response({
                    'error': error_message,
                    'current': tenant.get_user_usage()['current'],
                    'limit': tenant.max_users
                }, status=status.HTTP_403_FORBIDDEN)
        
        # ✅ VALIDACIÓN DE JERARQUÍA DE ROLES
        requested_business_role = request.data.get('business_role')
        requested_role = request.data.get('role') or map_business_role_to_legacy_role(requested_business_role)
        actor_role = get_effective_role_name(request.user, tenant=self._get_request_tenant()) or 'Client-Staff'
        if requested_role:
            is_valid, error_msg = validate_role_assignment(
                creator_role=actor_role,
                target_role=requested_role,
                creator_is_superuser=request.user.is_superuser
            )
            if not is_valid:
                return Response({
                    'error': error_msg,
                    'your_role': actor_role,
                    'allowed_roles': get_allowed_roles(actor_role, request.user.is_superuser)
                }, status=status.HTTP_403_FORBIDDEN)
        
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError as e:
            return Response(e.detail, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            user = serializer.save()
            
            # FORZAR asignación de tenant si no se asignó
            if not user.tenant and not self.request.user.is_superuser:
                if hasattr(self.request, 'tenant') and self.request.tenant:
                    user.tenant = self.request.tenant
                    user.save()
            
            # Asignar rol si se especifica
            if requested_role:
                user.role = requested_role
                user.save()
                
                # Crear UserRole si no es SuperAdmin
                if requested_role != 'SuperAdmin':
                    try:
                        role = Role.objects.get(name=requested_role)
                        from apps.roles_api.default_permissions import ensure_role_default_permissions
                        ensure_role_default_permissions(role)
                        UserRole.objects.get_or_create(
                            user=user,
                            role=role,
                            tenant=user.tenant
                        )
                    except Role.DoesNotExist:
                        pass
            
            # Retornar datos completos del usuario
            response_serializer = UserListSerializer(user)
            return Response(response_serializer.data, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        is_self_update = instance.id == request.user.id

        if not is_self_update and not self._is_tenant_admin_or_superuser(request):
            return Response(
                {'error': 'Solo Client-Admin puede modificar usuarios'},
                status=status.HTTP_403_FORBIDDEN
            )

        # Permitir auto-edición básica del propio perfil sin validación jerárquica de roles.
        if is_self_update:
            allowed_self_fields = {'full_name', 'email', 'phone'}
            requested_fields = set(request.data.keys())
            blocked_fields = requested_fields - allowed_self_fields
            if blocked_fields:
                return Response(
                    {
                        'error': 'No puedes modificar estos campos en tu propio perfil',
                        'blocked_fields': sorted(list(blocked_fields))
                    },
                    status=status.HTTP_403_FORBIDDEN
                )

            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            try:
                serializer.is_valid(raise_exception=True)
                user = serializer.save()
                return Response(UserListSerializer(user).data)
            except ValidationError as e:
                return Response(e.detail, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        # ✅ SUPERUSER CAN MODIFY ANYONE - EARLY RETURN
        if request.user.is_superuser:
            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            try:
                serializer.is_valid(raise_exception=True)
                user = serializer.save()
                return Response(UserListSerializer(user).data)
            except ValidationError as e:
                return Response(e.detail, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        # ✅ VALIDAR QUE PUEDE MODIFICAR ESTE USUARIO (non-superuser path)
        actor_role = get_effective_role_name(request.user, tenant=self._get_request_tenant()) or 'Client-Staff'
        target_role = get_effective_role_name(instance, tenant=instance.tenant) or 'Client-Staff'
        can_modify, error_msg = can_modify_user(
            modifier_role=actor_role,
            target_user_role=target_role,
            modifier_is_superuser=False
        )
        if not can_modify:
            return Response({'error': error_msg}, status=status.HTTP_403_FORBIDDEN)
        
        # ✅ VALIDAR CAMBIO DE ROL SI SE ESPECIFICA
        requested_business_role = request.data.get('business_role')
        requested_role = request.data.get('role') or map_business_role_to_legacy_role(requested_business_role)
        if requested_role:
            new_role = requested_role
            is_valid, error_msg = validate_role_assignment(
                creator_role=actor_role,
                target_role=new_role,
                creator_is_superuser=request.user.is_superuser
            )
            if not is_valid:
                return Response({
                    'error': error_msg,
                    'your_role': actor_role,
                    'allowed_roles': get_allowed_roles(actor_role, request.user.is_superuser)
                }, status=status.HTTP_403_FORBIDDEN)
        
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        
        try:
            serializer.is_valid(raise_exception=True)
            user = serializer.save()
            
            # Actualizar rol si se especifica
            if requested_role:
                role_name = requested_role
                user.role = role_name
                user.save()
                
                # Manejar UserRole si no es SuperAdmin
                if role_name and role_name != 'SuperAdmin':
                    UserRole.objects.filter(user=user).delete()
                    try:
                        role = Role.objects.get(name=role_name)
                        from apps.roles_api.default_permissions import ensure_role_default_permissions
                        ensure_role_default_permissions(role)
                        UserRole.objects.get_or_create(
                            user=user,
                            role=role,
                            tenant=user.tenant
                        )
                    except Role.DoesNotExist:
                        pass
            
            # Retornar datos completos del usuario
            response_serializer = UserListSerializer(user)
            return Response(response_serializer.data)
            
        except ValidationError as e:
            return Response(e.detail, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def get_queryset(self):
        user = self.request.user
        
        # SuperAdmin: acceso total
        if user.is_superuser:
            tenant_id = self.request.query_params.get('tenant')
            queryset = User.objects.select_related('tenant').all()
            if tenant_id:
                return queryset.filter(tenant_id=tenant_id)
            return queryset
        
        # Usuario sin tenant: sin acceso
        tenant = self._get_request_tenant()
        if not tenant:
            return User.objects.none()
        
        # Filtrar por tenant del request o del usuario autenticado como fallback
        return User.objects.select_related('tenant').filter(tenant=tenant)

    @action(detail=False, methods=['get'])
    def available_for_employee(self, request):
        """Usuarios disponibles para ser empleados"""
        users = self.get_queryset().filter(tenant__isnull=False)
        return Response([{
            'id': user.id,
            'email': user.email,
            'full_name': user.full_name,
            'tenant_id': user.tenant_id,
            'roles': [{'id': role.id, 'name': role.name} for role in user.roles.all()]
        } for user in users])

    @action(detail=False, methods=['post'], url_path='me/avatar', permission_classes=[IsAuthenticated])
    def upload_avatar(self, request):
        """Subir avatar del usuario autenticado."""
        if 'avatar' not in request.FILES:
            return Response({'error': 'No avatar file provided'}, status=status.HTTP_400_BAD_REQUEST)

        avatar_file = request.FILES['avatar']

        allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
        if avatar_file.content_type not in allowed_types:
            return Response(
                {'error': 'Tipo de archivo no permitido. Use JPEG, PNG, WebP o GIF.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        max_size = 2 * 1024 * 1024  # 2MB
        if avatar_file.size > max_size:
            return Response(
                {'error': 'La imagen no puede superar los 2MB.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        ext = avatar_file.name.split('.')[-1].lower()
        allowed_exts = {'jpg', 'jpeg', 'png', 'webp', 'gif'}
        if ext not in allowed_exts:
            return Response(
                {'error': 'Extensión de archivo no permitida.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = request.user
        user.avatar = avatar_file
        user.save()

        return Response({
            'avatar_url': user.avatar.url if user.avatar else None,
            'message': 'Avatar actualizado correctamente'
        })
    
    @action(detail=False, methods=['post'])
    def bulk_delete(self, request):
        """Bulk delete users"""
        if not self._is_tenant_admin_or_superuser(request):
            return Response(
                {'error': 'Solo Client-Admin puede eliminar usuarios'},
                status=status.HTTP_403_FORBIDDEN
            )

        user_ids = request.data.get('user_ids', [])
        users = self.get_queryset().filter(id__in=user_ids)
        
        # Prevent deleting last superuser
        if users.filter(is_superuser=True).exists():
            remaining_superusers = User.objects.filter(is_superuser=True).exclude(id__in=user_ids).count()
            if remaining_superusers == 0:
                return Response({
                    'error': 'Cannot delete all superusers'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        count = users.count()
        users.delete()
        return Response({'deleted': count})


class VerifyAuthView(APIView):
    """Verificar autenticación con cookies httpOnly"""
    authentication_classes = [DualJWTAuthentication]
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        return Response({
            'authenticated': True,
            'user': {
                'id': request.user.id,
                'email': request.user.email,
                'role': get_effective_role_api(request.user, tenant=getattr(request, 'tenant', None)),
                'branch_id': request.user.employee_profile.branch_id if hasattr(request.user, 'employee_profile') and request.user.employee_profile else None,
            }
        })
