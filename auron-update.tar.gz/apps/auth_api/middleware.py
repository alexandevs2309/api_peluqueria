from django.http import HttpResponseForbidden
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from apps.tenants_api.models import Tenant
from django.utils.deprecation import MiddlewareMixin
from django.conf import settings

class CSRFProtectionMiddleware(MiddlewareMixin):
    """Protege endpoints mutantes contra CSRF cuando se usan cookies cross-site.

    Requiere header X-Requested-With: XMLHttpRequest en POST/PUT/PATCH/DELETE
    para producción (SameSite=None). El frontend Angular lo envía automáticamente
    via AuthInterceptor.
    """
    SAFE_METHODS = ('GET', 'HEAD', 'OPTIONS', 'TRACE')

    def process_view(self, request, view_func, view_args, view_kwargs):
        import sys
        if settings.DEBUG or 'test' in sys.argv or 'pytest' in sys.modules:
            return None

        if request.method in self.SAFE_METHODS:
            return None

        # Skip para login/logout, lookup y admin (necesitan funcionar sin AJAX)
        if request.path.startswith('/auth/') or request.path.startswith('/api/auth/'):
            return None
        if request.path.startswith('/admin/') or request.path.startswith('/api/admin/'):
            return None
        # Skip para webhooks y pagos (llamados por servicios externos)
        if request.path.startswith('/api/billing/webhooks/') or request.path.startswith('/api/payments/'):
            return None
        # Skip para WhatsApp webhook (Evolution API callback)
        if request.path.startswith('/api/settings/barbershop/whatsapp_webhook/'):
            return None
        # Skip para registro público (POST sin AJAX)
        if request.path.startswith('/api/subscriptions/register/'):
            return None
        if request.path.startswith('/api/subscriptions/check-email/'):
            return None
        # Skip para formulario de contacto y newsletter público (POST sin cookies/sesión)
        if request.path.startswith('/api/settings/contact/'):
            return None

        x_requested_with = request.META.get('HTTP_X_REQUESTED_WITH')
        if x_requested_with != 'XMLHttpRequest':
            return HttpResponseForbidden("CSRF: falta header X-Requested-With.")

        return None


class TenantValidationMiddleware(MiddlewareMixin):
    def process_view(self, request, view_func, view_args, view_kwargs):
        if not request.user.is_authenticated:
            return None

        if getattr(request.user, 'is_superuser', False):
            return None

        try:
            # Valida token (desde header o cookie)
            token_str = None
            auth_header = request.META.get('HTTP_AUTHORIZATION')
            if auth_header and auth_header.startswith('Bearer '):
                token_str = auth_header.split(' ')[1]
            else:
                token_str = request.COOKIES.get('access_token')

            if token_str:
                token = AccessToken(token_str)
                token_tenant_id = token.get('tenant_id')

                if not token_tenant_id or token_tenant_id != getattr(request.user, 'tenant_id', None):
                    return HttpResponseForbidden("Token no autorizado para este tenant.")

                # Opcional: Recarga tenant en request para views
                request.current_tenant = Tenant.objects.get(id=token_tenant_id)
            else:
                import sys
                if 'test' in sys.argv or 'pytest' in sys.modules:
                    return None
                return HttpResponseForbidden("Token requerido.")
        except (InvalidToken, TokenError, Tenant.DoesNotExist):
            return HttpResponseForbidden("Token o tenant inválido.")

        return None
