from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from rest_framework.throttling import AnonRateThrottle
from rest_framework.exceptions import ValidationError
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django_ratelimit.decorators import ratelimit
from django_ratelimit.core import is_ratelimited
from django.conf import settings
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import LoginSerializer, get_explicit_tenant_input
from .views import hash_token
from .models import ActiveSession, AccessLog, LoginAudit
from .utils import get_client_ip, get_user_agent, get_client_jti
from .settings_policy import is_mfa_globally_enabled, get_jwt_expiry_minutes
from .login_policy import is_login_locked_out, get_login_lockout_message
from .cookie_utils import clear_auth_cookies, set_auth_cookies
from django.utils.timezone import now
from django.contrib.auth import get_user_model
from apps.tenants_api.models import Tenant
from datetime import timedelta

User = get_user_model()


class CookieLoginThrottle(AnonRateThrottle):
    scope = 'login'


class CookieRefreshThrottle(AnonRateThrottle):
    scope = 'login'


def _jwt_cookie_max_age(setting_name: str) -> int:
    if setting_name == 'ACCESS_TOKEN_LIFETIME':
        return get_jwt_expiry_minutes() * 60

    lifetime = settings.SIMPLE_JWT.get(setting_name)
    if lifetime is None:
        return 0

    return max(0, int(lifetime.total_seconds()))


def _safe_user_agent(request) -> str:
    return (get_user_agent(request) or '')[:255]


def _resolve_tenant(request, user=None):
    tenant = getattr(request, 'tenant', None)
    if tenant is not None:
        return tenant
    if user is not None and user.is_authenticated:
        return getattr(user, 'tenant', None)
    return None

def _create_login_audit(user, request, successful: bool, message: str) -> None:
    LoginAudit.objects.create(
        tenant=_resolve_tenant(request, user),
        user=user,
        ip_address=get_client_ip(request),
        user_agent=_safe_user_agent(request),
        successful=successful,
        message=(message or '')[:255],
        timestamp=now()
    )


class CookieLoginView(APIView):
    """
    Vista de login que establece JWT tokens en httpOnly cookies
    Ruta: /api/auth/cookie-login/
    """
    permission_classes = [AllowAny]
    throttle_classes = [CookieLoginThrottle]
    
    def post(self, request):
        serializer = LoginSerializer(data=request.data, context={'request': request})
        tenant_subdomain = get_explicit_tenant_input(request.data)
        email = (request.data.get('email') or '').strip().lower()
        ip_address = get_client_ip(request)
        user_for_lockout = None

        if email:
            if tenant_subdomain:
                tenant_for_lockout = Tenant.objects.filter(subdomain=tenant_subdomain).first()
                if tenant_for_lockout:
                    user_for_lockout = User.objects.filter(email__iexact=email, tenant=tenant_for_lockout).first()
            else:
                user_for_lockout = User.objects.filter(
                    email__iexact=email,
                    is_superuser=True,
                    tenant__isnull=True
                ).first()

        if is_login_locked_out(user=user_for_lockout, ip_address=ip_address):
            return Response({"detail": get_login_lockout_message()}, status=status.HTTP_429_TOO_MANY_REQUESTS)

        def tenant_rate_key(group, request):
            tenant = getattr(request, 'tenant', None)
            if tenant:
                return f"tenant:{tenant.id}"

            return request.META.get('REMOTE_ADDR', 'unknown')
        try:
            serializer.is_valid(raise_exception=True)
        except ValidationError:
            email = (request.data.get('email') or '').strip().lower()
            user = None

            if email:
                try:
                    if tenant_subdomain:
                        tenant = Tenant.objects.filter(subdomain=tenant_subdomain).first()
                        if tenant:
                            user = User.objects.filter(email__iexact=email, tenant=tenant).first()
                    else:
                        user = User.objects.filter(
                            email__iexact=email,
                            is_superuser=True,
                            tenant__isnull=True
                        ).first()
                except Exception:
                    user = None

            _create_login_audit(
                user=user,
                request=request,
                successful=False,
                message=f"Credenciales inválidas - Cookie login - Tenant: {tenant_subdomain or 'unknown'}"
            )
            raise
        
        user = serializer.validated_data['user']
        tenant = serializer.validated_data['tenant']

        if is_mfa_globally_enabled() and user.mfa_enabled:
            tenant_data = {
                'id': tenant.id,
                'subdomain': tenant.subdomain,
            } if tenant else None

            return Response({
                'detail': 'Se requiere verificación MFA.',
                'email': user.email,
                'tenant': tenant_data,
                'requires_mfa': True,
            }, status=status.HTTP_200_OK)
        
        # Generar tokens
        refresh = RefreshToken.for_user(user)
        access = refresh.access_token
        access.set_exp(lifetime=timedelta(minutes=get_jwt_expiry_minutes()))
        if tenant:
            refresh['tenant_id'] = tenant.id
            refresh['tenant_subdomain'] = tenant.subdomain
            
        access_token = str(access)
        refresh_token = str(refresh)
        jti = get_client_jti(access_token)
        
        # Crear sesión activa
        ActiveSession.objects.create(
            user=user,
            ip_address=get_client_ip(request),
            user_agent=_safe_user_agent(request),
            token_jti=jti,
            refresh_token=hash_token(refresh_token),
            is_active=True,
            tenant=tenant
        )
        
        # Logs de auditoría
        AccessLog.objects.create(
            user=user,
            event_type='LOGIN',
            ip_address=get_client_ip(request),
            user_agent=_safe_user_agent(request),
            timestamp=now()
        )
        
        _create_login_audit(
            user=user,
            successful=True,
            request=request,
            message="Login con cookies exitoso"
        )
        
        # Respuesta con datos del usuario usando el rol efectivo.
        from .role_utils import get_effective_role_api
        user_role = get_effective_role_api(user, tenant=tenant)

        response_data = {
            'user': {
                'id': user.id,
                'email': user.email,
                'full_name': user.full_name,
                'phone': user.phone,
                'role': user_role,
                'is_active': user.is_active,
                'date_joined': user.date_joined,
                'avatar_url': user.avatar.url if user.avatar else None,
                'branch_id': user.employee_profile.branch_id if hasattr(user, 'employee_profile') and user.employee_profile else None,
            },
            'message': 'Login exitoso con cookies'
        }
        
        if tenant:
            response_data['tenant'] = {
                'id': tenant.id,
                'name': tenant.name,
                'subdomain': tenant.subdomain,
            }
        
        response = Response(response_data, status=status.HTTP_200_OK)
        
        return set_auth_cookies(
            response,
            access_token=access_token,
            refresh_token=refresh_token,
            access_max_age=_jwt_cookie_max_age('ACCESS_TOKEN_LIFETIME'),
            refresh_max_age=_jwt_cookie_max_age('REFRESH_TOKEN_LIFETIME'),
            tenant_id=tenant.id if tenant else None,
        )


class CookieLogoutView(APIView):
    """
    Vista de logout que limpia cookies httpOnly
    Ruta: /api/auth/cookie-logout/
    """
    permission_classes = [AllowAny]
    throttle_classes = [CookieLoginThrottle]

    def post(self, request):
        refresh_token = request.COOKIES.get('refresh_token')
        

        def tenant_rate_key(group, request):
            tenant = getattr(request, 'tenant', None)
            if tenant:
                return f"tenant:{tenant.id}"
            return request.META.get('REMOTE_ADDR', 'unknown')
        
        if is_ratelimited(
            request,
            group='tenant_login',
            key=tenant_rate_key,
            rate='20/m',
            method='POST'
        ):
            return Response({"detail": "Demasiados intentos de login. Intenta más tarde."}, status=status.HTTP_429_TOO_MANY_REQUESTS)
        

        if refresh_token:
            try:
                token = RefreshToken(refresh_token)
                token.blacklist()
                
                # Expirar sesión activa
                try:
                    session = ActiveSession.objects.get(refresh_token=refresh_token)
                    session.expire_session()
                    
                    # Log de logout si tenemos usuario
                    if hasattr(request, 'user') and request.user.is_authenticated:
                        AccessLog.objects.create(
                            user=request.user,
                            event_type='LOGOUT',
                            ip_address=get_client_ip(request),
                            user_agent=get_user_agent(request),
                            timestamp=now()
                        )
                except ActiveSession.DoesNotExist:
                    pass
                    
            except Exception:
                pass  # Token inválido, pero seguimos con logout
        
        response = Response({
            "detail": "Logout exitoso con cookies"
        }, status=status.HTTP_200_OK)
        
        return clear_auth_cookies(response)


class CookieRefreshView(APIView):
    """
    Vista para refrescar tokens usando cookies
    Ruta: /api/auth/cookie-refresh/
    """
    permission_classes = [AllowAny]
    throttle_classes = [CookieRefreshThrottle]
    
    def post(self, request):
        refresh_token = request.COOKIES.get('refresh_token')
        
        if not refresh_token:
            return Response({
                'error': 'No refresh token found'
            }, status=status.HTTP_401_UNAUTHORIZED)
        
        try:
            token = RefreshToken(refresh_token)
            # Verificar que el token no esté en blacklist (reutilización)
            try:
                token.verify()
            except Exception:
                raise

            user_id = token.payload.get('user_id')
            user = User.objects.get(pk=user_id)
            tenant_id = token.payload.get('tenant_id')

            # Validar tenant del usuario
            if tenant_id is not None and getattr(user, 'tenant_id', None) not in (None, tenant_id):
                raise ValidationError('Tenant mismatch')

            # Blacklist del refresh anterior (protección contra reutilización)
            try:
                token.blacklist()
            except Exception:
                pass

            # Emitir nuevo refresh + access (rotación real)
            new_refresh = RefreshToken.for_user(user)
            if tenant_id is not None:
                new_refresh['tenant_id'] = tenant_id
            new_access = new_refresh.access_token
            new_access.set_exp(lifetime=timedelta(minutes=get_jwt_expiry_minutes()))
            if tenant_id is not None:
                new_access['tenant_id'] = tenant_id

            response = Response({
                'message': 'Token refreshed successfully'
            }, status=status.HTTP_200_OK)
            
            return set_auth_cookies(
                response,
                access_token=str(new_access),
                refresh_token=str(new_refresh),
                access_max_age=_jwt_cookie_max_age('ACCESS_TOKEN_LIFETIME'),
                refresh_max_age=_jwt_cookie_max_age('REFRESH_TOKEN_LIFETIME'),
            )
            
        except Exception:
            response = Response({
                'error': 'Invalid refresh token'
            }, status=status.HTTP_401_UNAUTHORIZED)
            return clear_auth_cookies(response)


class LookupSubdomainView(APIView):
    permission_classes = [AllowAny]
    throttle_classes = [CookieLoginThrottle]

    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def post(self, request):
        from apps.tenants_api.models import Tenant
        email = (request.data.get('email') or '').strip().lower()
        if not email:
            return Response({'detail': 'Email requerido'}, status=400)
        tenant = Tenant.objects.filter(contact_email=email, deleted_at__isnull=True).first()
        if not tenant:
            return Response({'subdomain': None}, status=200)
        return Response({'subdomain': tenant.subdomain, 'name': tenant.name})
