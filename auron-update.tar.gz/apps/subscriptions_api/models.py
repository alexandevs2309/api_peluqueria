from django.db import models
from django.conf import settings
from datetime import timedelta
from django.db.models import JSONField
from django.utils import timezone
from dateutil.relativedelta import relativedelta
from django.core.exceptions import ValidationError


class PromotionalCredit(models.Model):
    tenant = models.ForeignKey(
        'tenants_api.Tenant', on_delete=models.CASCADE,
        related_name='promotional_credits'
    )
    months = models.PositiveIntegerField(help_text="Número de meses gratis otorgados")
    reason = models.TextField(blank=True, help_text="Motivo del crédito (ej. campaña Instagram, referido, etc.)")
    campaign_tag = models.CharField(
        max_length=50, blank=True, null=True,
        help_text="Tag opcional para agrupar por campaña (ej. INSTAGRAM2026, TIKTOK10)"
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, related_name='created_promotional_credits'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    used_at = models.DateTimeField(null=True, blank=True, help_text="Cuándo se aplicó el crédito")

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Crédito Promocional'
        verbose_name_plural = 'Créditos Promocionales'

    def apply(self):
        """Aplica el crédito: extiende suscripción y marca como usado."""
        from django.db import transaction
        if self.used_at:
            raise ValidationError("Este crédito ya fue aplicado.")
        with transaction.atomic():
            months = max(self.months, 1)
            tenant = self.tenant
            if tenant.subscription_status == "trial":
                if tenant.is_trial_expired():
                    tenant.trial_end_date = timezone.now().date() + relativedelta(months=months)
                else:
                    base = max(tenant.trial_end_date, timezone.now().date())
                    tenant.trial_end_date = base + relativedelta(months=months)
                tenant.save(update_fields=['trial_end_date', 'updated_at'])
            elif tenant.subscription_status == "active":
                if tenant.is_paid_access_expired() or not tenant.access_until:
                    tenant.access_until = timezone.now() + relativedelta(months=months)
                else:
                    base = max(tenant.access_until, timezone.now())
                    tenant.access_until = base + relativedelta(months=months)
                tenant.save(update_fields=['access_until', 'updated_at'])
            else:
                tenant.subscription_status = 'active'
                tenant.access_until = timezone.now() + relativedelta(months=months)
                tenant.save(update_fields=['subscription_status', 'access_until', 'updated_at'])
            self.used_at = timezone.now()
            self.save(update_fields=['used_at'])

    def __str__(self):
        status = "usado" if self.used_at else "pendiente"
        return f"{self.tenant.name} — {self.months} meses ({status})"


class SubscriptionPlan(models.Model):

    PLAN_CHOICES = [
        ('basic', 'Basic'),
        ('standard', 'Pro'),
        ('premium', 'Business'),
        ('enterprise', 'Enterprise'),
    ]

    name = models.CharField(max_length=100, unique=True, choices=PLAN_CHOICES, help_text="Name of the subscription plan")
    description = models.TextField(blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    duration_month = models.PositiveIntegerField(default=1, help_text="Duration in month for the subscription plan")
    stripe_price_id = models.CharField(
        max_length=120,
        blank=True,
        null=True,
        db_index=True,
        help_text="Stripe Price ID (ej: price_...) para cobro recurrente"
    )
    annual_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Precio anual del plan")
    stripe_annual_price_id = models.CharField(
        max_length=120,
        blank=True,
        null=True,
        db_index=True,
        help_text="Stripe Price ID (ej: price_...) para cobro recurrente anual"
    )
    paypal_product_id = models.CharField(
        max_length=120,
        blank=True,
        null=True,
        db_index=True,
        help_text="PayPal Product ID (ej: PROD-...) para producto base"
    )
    paypal_plan_id = models.CharField(
        max_length=120,
        blank=True,
        null=True,
        db_index=True,
        help_text="PayPal Plan ID (ej: P-...) para cobro mensual"
    )
    paypal_annual_plan_id = models.CharField(
        max_length=120,
        blank=True,
        null=True,
        db_index=True,
        help_text="PayPal Plan ID (ej: P-...) para cobro anual"
    )
    is_active = models.BooleanField(default=True)
    is_public = models.BooleanField(default=True, help_text="Visible y elegible en catalogo publico y onboarding")
    max_employees = models.PositiveIntegerField(default=0)
    max_users = models.PositiveIntegerField(default=0)
    allows_multiple_branches = models.BooleanField(default=False, help_text="Permite multiples sucursales")
    features = JSONField(default=dict)
    commercial_benefits = JSONField(default=list, blank=True)

    @property
    def contact_sales(self):
        """Planes sin precio público: la venta se gestiona con un asesor."""
        return self.name == 'enterprise'

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        from django.core.cache import cache
        cache.delete('public_plan_catalog')
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        from django.core.cache import cache
        cache.delete('public_plan_catalog')
        super().delete(*args, **kwargs)

    def __str__(self):
        return self.get_name_display()


class UserSubscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='subscriptions')
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.PROTECT, related_name='user_subscriptions')
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    auto_renew = models.BooleanField(default=False)
    billing_interval = models.CharField(
        max_length=20,
        default='month',
        choices=[('month', 'Mensual'), ('year', 'Anual')],
        help_text="Ciclo de facturacion: mensual o anual"
    )
    cancelled_at = models.DateTimeField(blank=True, null=True, help_text="Momento en que se solicitó la cancelación. Si está seteado, la suscripción expirará en end_date.")

    created_at = models.DateTimeField(auto_now_add=True)

    @staticmethod
    def _should_validate_employee_limit_change(old_limit, new_limit):
        """0 means unlimited, so only finite targets need capacity validation."""
        if new_limit == 0:
            return False
        if old_limit == 0:
            return True
        return new_limit < old_limit

    def change_plan(self, new_plan):
        old_plan = self.plan

        if self._should_validate_employee_limit_change(
            old_plan.max_employees,
            new_plan.max_employees,
        ):
            self._validate_employee_limit(new_plan)

        if not new_plan.allows_multiple_branches and old_plan.allows_multiple_branches:
            self._validate_branch_limit(new_plan)

        self.plan = new_plan
        self.save()

        SubscriptionAuditLog.objects.create(
            user=self.user,
            subscription=self,
            action='plan_changed',
            description=f'Plan cambiado de {old_plan.name} a {new_plan.name}'
        )

    def _validate_employee_limit(self, new_plan):
        from apps.employees_api.models import Employee

        tenant = self.user.tenant
        if not tenant:
            return

        if new_plan.max_employees == 0:
            return

        current_employees = Employee.objects.filter(tenant=tenant, is_active=True).count()

        if current_employees > new_plan.max_employees:
            raise ValidationError(
                f'No puede cambiar a este plan. Tiene {current_employees} empleados activos, '
                f'pero el plan {new_plan.get_name_display()} permite maximo {new_plan.max_employees}. '
                f'Desactive empleados antes de cambiar de plan.'
            )

    def _validate_branch_limit(self, new_plan):
        from apps.settings_api.models import Branch

        tenant = self.user.tenant
        if not tenant:
            return

        branch_count = Branch.objects.filter(tenant=tenant, is_active=True).count()

        if branch_count > 1:
            raise ValidationError(
                f'No puede cambiar a este plan. Tiene {branch_count} sucursales activas, '
                f'pero el plan {new_plan.get_name_display()} solo permite 1 sucursal. '
                f'Desactive sucursales antes de cambiar de plan.'
            )

    def save(self, *args, **kwargs):
        if self._state.adding:
            if not self.end_date:
                self.start_date = timezone.now()
                months = 12 if self.billing_interval == 'year' else self.plan.duration_month
                self.end_date = self.start_date + relativedelta(months=months)
        else:
            old = UserSubscription.objects.get(pk=self.pk)
            if old.is_active is False and self.is_active is True and not old.cancelled_at:
                raise ValueError("No se puede reactivar una suscripcion inactiva sin pasar por cancelacion")

        if self.end_date and self.end_date < timezone.now():
            self.is_active = False

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.email} -> {self.plan.name}"


class Subscription(models.Model):
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE)
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.PROTECT)
    stripe_subscription_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    paypal_subscription_id = models.CharField(max_length=255, unique=True, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    billing_interval = models.CharField(
        max_length=20,
        default='month',
        choices=[('month', 'Mensual'), ('year', 'Anual')],
        help_text="Ciclo de facturacion: mensual o anual"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('tenant', 'plan')

    @staticmethod
    def _should_validate_employee_limit_change(old_limit, new_limit):
        """0 means unlimited, so only finite targets need capacity validation."""
        if new_limit == 0:
            return False
        if old_limit == 0:
            return True
        return new_limit < old_limit

    def change_plan(self, new_plan):
        old_plan = self.plan

        if self._should_validate_employee_limit_change(
            old_plan.max_employees,
            new_plan.max_employees,
        ):
            self._validate_employee_limit(new_plan)

        if not new_plan.allows_multiple_branches and old_plan.allows_multiple_branches:
            self._validate_branch_limit(new_plan)

        self.plan = new_plan
        self.save()

    def _validate_employee_limit(self, new_plan):
        from apps.employees_api.models import Employee

        if new_plan.max_employees == 0:
            return

        current_employees = Employee.objects.filter(tenant=self.tenant, is_active=True).count()

        if current_employees > new_plan.max_employees:
            raise ValidationError(
                f'No puede cambiar a este plan. Tiene {current_employees} empleados activos, '
                f'pero el plan {new_plan.get_name_display()} permite maximo {new_plan.max_employees}. '
                f'Desactive empleados antes de cambiar de plan.'
            )

    def _validate_branch_limit(self, new_plan):
        from apps.settings_api.models import Branch

        branch_count = Branch.objects.filter(tenant=self.tenant, is_active=True).count()

        if branch_count > 1:
            raise ValidationError(
                f'No puede cambiar a este plan. Tiene {branch_count} sucursales activas, '
                f'pero el plan {new_plan.get_name_display()} solo permite 1 sucursal. '
                f'Desactive sucursales antes de cambiar de plan.'
            )

    def __str__(self):
        return f"{self.tenant.name} - {self.plan.name} - {self.stripe_subscription_id}"


class SubscriptionAuditLog(models.Model):
    ACTION_CHOICES = [
        ('created', 'Creacion'),
        ('updated', 'Actualizacion'),
        ('deleted', 'Eliminacion'),
        ('renewed', 'Renovacion'),
        ('cancelled', 'Cancelacion'),
        ('expired', 'Expiracion'),
        ('payment_failed', 'Fallo de pago'),
        ('payment_successful', 'Pago exitoso'),
        ('plan_changed', 'Cambio de plan'),
        ('trial_started', 'Inicio de prueba'),
        ('trial_ended', 'Fin de prueba'),
        ('subscription_suspended', 'Suspension de suscripcion'),
        ('subscription_resumed', 'Reanudacion de suscripcion'),
        ('subscription_paused', 'Pausa de suscripcion'),
        ('subscription_reactivated', 'Reactivacion de suscripcion'),
    ]

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='subscription_audit_logs')
    subscription = models.ForeignKey('UserSubscription', on_delete=models.CASCADE, related_name='audit_logs')
    action = models.CharField(max_length=50, choices=ACTION_CHOICES, help_text="Action performed on the subscription")
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Subscription Audit Log'
        verbose_name_plural = 'Subscription Audit Logs'

    def __str__(self):
        return f"{self.user.email} - {self.action} at {self.created_at}"
