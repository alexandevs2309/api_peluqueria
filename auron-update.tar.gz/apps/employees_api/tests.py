import pytest
from decimal import Decimal
from django.contrib.auth.models import Permission
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from django.urls import reverse
from apps.auth_api.factories import UserFactory
from apps.roles_api.models import Role, UserRole
from apps.employees_api.models import Employee, WorkSchedule
from apps.employees_api.earnings_models import PayrollDeduction
from apps.tenants_api.models import Tenant
from apps.subscriptions_api.models import SubscriptionPlan, UserSubscription

User = get_user_model()

@pytest.fixture
def admin_tenant(db):
    plan, _ = SubscriptionPlan.objects.get_or_create(
        name='basic',
        defaults={
            'description': 'Plan base test',
            'price': 0,
            'duration_month': 1,
            'max_employees': 50,
            'max_users': 50,
            'is_active': True,
            'features': {}
        }
    )
    return Tenant.objects.create(
        name="Admin Test Tenant",
        subdomain="admin-test-tenant",
        is_active=True,
        subscription_plan=plan,
        subscription_status='active',
    )

@pytest.fixture
def admin_user(admin_tenant):
    user = User.objects.create_user(
        email='admin.employees@example.com',
        password='testpassword123',
        full_name='Admin Employees',
        tenant=admin_tenant,
        is_email_verified=True
    )
    role, _ = Role.objects.get_or_create(
        name='Client-Admin',
        defaults={'scope': 'TENANT', 'description': 'Client admin test role'}
    )
    perms = Permission.objects.filter(
        content_type__app_label='employees_api'
    )
    role.permissions.add(*perms)
    UserRole.objects.get_or_create(user=user, role=role, tenant=admin_tenant)
    return user

@pytest.fixture
def admin_client(admin_user):
    client = APIClient()
    refresh = RefreshToken.for_user(admin_user)
    refresh['tenant_id'] = admin_user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=admin_user)
    return client

@pytest.fixture
def stylist_user(admin_tenant):
    user = UserFactory(is_email_verified=True, tenant=admin_tenant)
    stylist_role, _ = Role.objects.get_or_create(name='Stylist')
    UserRole.objects.get_or_create(user=user, role=stylist_role, tenant=admin_tenant)
    return user

@pytest.fixture
def normal_client(db):
    user = UserFactory(is_email_verified=True)
    client = APIClient()
    refresh = RefreshToken.for_user(user)
    refresh['tenant_id'] = user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=user)
    return client

@pytest.mark.django_db
def test_create_employee_success(admin_client, stylist_user):
    # Asignar plan con 5 empleados permitidos al tenant del stylist_user
    plan = SubscriptionPlan.objects.create(
        name="Pro",
        price=0,
        duration_month=1,
        max_employees=5
    )
    tenant = stylist_user.tenant
    tenant.subscription_plan = plan
    tenant.subscription_status = 'active'
    tenant.save()

    # Suscripción activa para el stylist_user
    UserSubscription.objects.create(
        user=stylist_user,
        plan=plan,
        start_date=timezone.now() - timezone.timedelta(days=1),
        end_date=timezone.now() + timezone.timedelta(days=29),
        is_active=True,
        auto_renew=True
    )

    payload = {
        'user_id': stylist_user.id,
        'profession': 'stylist',
        'phone': '1234567890',
        'hire_date': '2025-06-01',
        'is_active': True
    }
    response = admin_client.post(reverse('employee-list'), payload, format='json')
    print("Status:", response.status_code)
    print("Errors:", response.data)  # 👈 Esto es clave
    assert response.status_code == status.HTTP_201_CREATED

@pytest.mark.django_db
def test_create_employee_missing_data(admin_client):
    response = admin_client.post(reverse('employee-list'), {}, format='json')
    assert response.status_code == status.HTTP_400_BAD_REQUEST 

@pytest.mark.django_db
def test_delete_nonexistent_employee(admin_client):
    response = admin_client.delete(reverse('employee-detail', kwargs={'pk': 9999}))
    assert response.status_code == status.HTTP_404_NOT_FOUND

@pytest.mark.django_db
def test_list_employees_denied_to_non_admin(normal_client):
    response = normal_client.get(reverse('employee-list'))
    assert response.status_code in [403, 401]

@pytest.mark.django_db
def test_create_schedule_denied_for_stylist(stylist_user):
    client = APIClient()
    refresh = RefreshToken.for_user(stylist_user)
    refresh['tenant_id'] = stylist_user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=stylist_user)
    employee = Employee.objects.create(user=stylist_user, profession='stylist', tenant=stylist_user.tenant)
    payload = {
        'employee': employee.id,
        'day_of_week': 'monday',
        'start_time': '09:00:00',
        'end_time': '17:00:00'
    }
    response = client.post(reverse('work_schedule-list'), payload, format='json')
    assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_stylist_cannot_create_other_employee(stylist_user):
    client = APIClient()
    refresh = RefreshToken.for_user(stylist_user)
    refresh['tenant_id'] = stylist_user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=stylist_user)
    other_user = UserFactory(is_email_verified=True, tenant=stylist_user.tenant)
    payload = {
        'user_email': other_user.id,
        'profession': 'barber',
        'phone': '0987654321',
        'hire_date': '2025-06-01',
        'is_active': True
    }
    response = client.post(reverse('employee-list'), payload, format='json')
    assert response.status_code == status.HTTP_403_FORBIDDEN

@pytest.mark.django_db
def test_update_employee_denied_for_non_admin(normal_client):
    target_user = UserFactory()
    employee = Employee.objects.create(user=target_user, profession="stylist", tenant=target_user.tenant)
    response = normal_client.put(reverse("employee-detail", args=[employee.id]), {"profession": "stylist"})
    assert response.status_code in [403, 401]

@pytest.mark.django_db
def test_permission_denied_if_inactive():
    user = UserFactory(is_email_verified=True, is_active=False)
    client = APIClient()
    refresh = RefreshToken.for_user(user)
    refresh['tenant_id'] = user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=user)
    response = client.get(reverse("employee-list"))
    assert response.status_code in [403, 401]

@pytest.mark.django_db
def test_delete_employee_permission_denied_other_roles():
    user = UserFactory(is_email_verified=True)
    target_user = UserFactory()
    employee = Employee.objects.create(user=target_user, profession="stylist", tenant=target_user.tenant)
    client = APIClient()
    refresh = RefreshToken.for_user(user)
    refresh['tenant_id'] = user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=user)
    response = client.delete(reverse("employee-detail", args=[employee.id]))
    assert response.status_code in [403, 401]


@pytest.fixture
def tenant_for_schedules(db):
    plan, _ = SubscriptionPlan.objects.get_or_create(
        name='basic',
        defaults={
            'description': 'Plan base test',
            'price': 0,
            'duration_month': 1,
            'max_employees': 50,
            'max_users': 50,
            'is_active': True,
            'features': {}
        }
    )
    owner = User.objects.create_superuser(
        email='owner.schedules@example.com',
        password='testpassword123',
        full_name='Owner Schedules'
    )
    return Tenant.objects.create(
        name=f"Tenant Schedules {owner.id}",
        subdomain=f"tenant-schedules-{owner.id}",
        owner=owner,
        is_active=True,
        subscription_plan=plan,
        subscription_status='active',
    )


@pytest.fixture
def manager_user(tenant_for_schedules):
    manager = User.objects.create_user(
        email='manager.schedules@example.com',
        password='testpassword123',
        full_name='Manager Schedules',
        tenant=tenant_for_schedules,
        is_email_verified=True
    )
    role, _ = Role.objects.get_or_create(
        name='Manager',
        defaults={'scope': 'TENANT', 'description': 'Manager test role'}
    )
    perms = Permission.objects.filter(
        content_type__app_label='employees_api',
        codename__in=['view_employee', 'change_employee']
    )
    role.permissions.add(*perms)
    UserRole.objects.get_or_create(user=manager, role=role, tenant=tenant_for_schedules)
    Employee.objects.get_or_create(
        user=manager,
        defaults={'tenant': tenant_for_schedules, 'profession': 'general'}
    )
    return manager


@pytest.fixture
def manager_client(manager_user):
    client = APIClient()
    refresh = RefreshToken.for_user(manager_user)
    refresh['tenant_id'] = manager_user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    return client


@pytest.fixture
def team_employee(tenant_for_schedules):
    worker_user = User.objects.create_user(
        email='worker.schedules@example.com',
        password='testpassword123',
        full_name='Worker Schedules',
        tenant=tenant_for_schedules,
        is_email_verified=True
    )
    return Employee.objects.create(
        user=worker_user,
        tenant=tenant_for_schedules,
        profession='stylist'
    )


@pytest.mark.django_db
def test_manager_can_create_schedule_for_team_employee(manager_client, team_employee):
    from apps.employees_api.models import WorkSchedule
    WorkSchedule.objects.filter(employee=team_employee).delete()
    payload = {
        'employee': team_employee.id,
        'day_of_week': 'monday',
        'start_time': '09:00:00',
        'end_time': '17:00:00'
    }
    response = manager_client.post(reverse('work_schedule-list'), payload, format='json')
    assert response.status_code == status.HTTP_201_CREATED


@pytest.mark.django_db
def test_manager_can_update_schedule_for_team_employee(manager_client, team_employee):
    from apps.employees_api.models import WorkSchedule
    WorkSchedule.objects.filter(employee=team_employee).delete()
    schedule = WorkSchedule.objects.create(
        employee=team_employee,
        day_of_week='tuesday',
        start_time='09:00:00',
        end_time='17:00:00'
    )
    payload = {
        'employee': team_employee.id,
        'day_of_week': 'tuesday',
        'start_time': '10:00:00',
        'end_time': '18:00:00'
    }
    response = manager_client.put(
        reverse('work_schedule-detail', kwargs={'pk': schedule.id}),
        payload,
        format='json'
    )
    assert response.status_code == status.HTTP_200_OK


@pytest.mark.django_db
def test_manager_cannot_delete_schedule_sensitive_action(manager_client, team_employee):
    from apps.employees_api.models import WorkSchedule
    WorkSchedule.objects.filter(employee=team_employee).delete()
    schedule = WorkSchedule.objects.create(
        employee=team_employee,
        day_of_week='wednesday',
        start_time='09:00:00',
        end_time='17:00:00'
    )
    response = manager_client.delete(
        reverse('work_schedule-detail', kwargs={'pk': schedule.id})
    )
    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.fixture
def payroll_admin_user(tenant_for_schedules):
    user = User.objects.create_user(
        email='payroll.admin@example.com',
        password='testpassword123',
        full_name='Payroll Admin',
        tenant=tenant_for_schedules,
        is_email_verified=True
    )
    role, _ = Role.objects.get_or_create(
        name='Client-Admin',
        defaults={'scope': 'TENANT', 'description': 'Client admin test role'}
    )
    perms = Permission.objects.filter(
        content_type__app_label='employees_api',
        codename__in=['view_employee', 'manage_employee_loans', 'view_employee_payroll']
    )
    role.permissions.add(*perms)
    UserRole.objects.get_or_create(user=user, role=role, tenant=tenant_for_schedules)
    return user


@pytest.fixture
def payroll_admin_client(payroll_admin_user):
    client = APIClient()
    refresh = RefreshToken.for_user(payroll_admin_user)
    refresh['tenant_id'] = payroll_admin_user.tenant_id
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {str(refresh.access_token)}")
    client.force_authenticate(user=payroll_admin_user)
    return client


@pytest.fixture
def payroll_employee(tenant_for_schedules):
    worker_user = User.objects.create_user(
        email='payroll.worker@example.com',
        password='testpassword123',
        full_name='Payroll Worker',
        tenant=tenant_for_schedules,
        is_email_verified=True
    )
    return Employee.objects.create(
        user=worker_user,
        tenant=tenant_for_schedules,
        profession='general',
        payment_type='fixed',
        fixed_salary=Decimal('30000.00'),
        commission_rate=Decimal('0.00')
    )


@pytest.mark.django_db
def test_create_biweekly_loan_splits_installments_across_periods(payroll_admin_client, payroll_employee):
    from apps.employees_api.earnings_models import PayrollPeriod
    from datetime import timedelta
    
    period1 = PayrollPeriod.objects.create(
        employee=payroll_employee,
        period_type='biweekly',
        period_start=timezone.localdate(),
        period_end=timezone.localdate() + timedelta(days=14),
        status='open'
    )

    response = payroll_admin_client.post(
        reverse('employee-loans', kwargs={'pk': payroll_employee.id}),
        {
            'loan_type': 'personal_loan',
            'amount': '2000.00',
            'installments': 2,
            'reason': 'Prestamo prueba'
        },
        format='json'
    )

    assert response.status_code == status.HTTP_201_CREATED
    assert response.data['loan']['amount'] == 2000.0
    assert response.data['loan']['installment_amount'] == 1000.0

    from apps.employees_api.models import Loan
    assert Loan.objects.filter(employee=payroll_employee, status='active').count() == 1

    period1.calculate_amounts()
    period1.save()

    deductions = PayrollDeduction.objects.filter(
        period=period1,
        deduction_type='loan'
    )

    assert deductions.count() == 1
    assert deductions.first().amount == Decimal('1000.00')

    summary_response = payroll_admin_client.get(reverse('employee-loans-summary', kwargs={'pk': payroll_employee.id}))
    assert summary_response.status_code == status.HTTP_200_OK
    assert summary_response.data['total_loans'] == 1
    assert summary_response.data['active_loans'] == 1
    assert summary_response.data['remaining_balance'] == 2000.0
    assert summary_response.data['next_deduction'] == 1000.0



@pytest.fixture
def other_tenant_employee(db):
    plan, _ = SubscriptionPlan.objects.get_or_create(
        name='standard',
        defaults={
            'description': 'Plan standard test',
            'price': 0,
            'duration_month': 1,
            'max_employees': 20,
            'max_users': 20,
            'is_active': True,
            'features': {}
        }
    )
    owner = User.objects.create_superuser(
        email='owner.other.tenant@example.com',
        password='testpassword123',
        full_name='Owner Other Tenant'
    )
    tenant = Tenant.objects.create(
        name=f"Tenant Other {owner.id}",
        subdomain=f"tenant-other-{owner.id}",
        owner=owner,
        is_active=True,
        subscription_plan=plan,
        subscription_status='active',
    )
    worker_user = User.objects.create_user(
        email='worker.other.tenant@example.com',
        password='testpassword123',
        full_name='Worker Other Tenant',
        tenant=tenant,
        is_email_verified=True
    )
    return Employee.objects.create(user=worker_user, tenant=tenant, profession='stylist')


@pytest.mark.django_db
def test_manager_cannot_create_schedule_other_tenant(manager_client, other_tenant_employee):
    payload = {
        'employee': other_tenant_employee.id,
        'day_of_week': 'monday',
        'start_time': '09:00:00',
        'end_time': '17:00:00'
    }
    response = manager_client.post(reverse('work_schedule-list'), payload, format='json')
    assert response.status_code == status.HTTP_400_BAD_REQUEST


@pytest.mark.django_db
def test_manager_can_check_in_and_check_out_attendance(manager_client, team_employee):
    check_in_response = manager_client.post(
        reverse('attendance_record-check-in'),
        {'employee': team_employee.id},
        format='json'
    )
    assert check_in_response.status_code in [status.HTTP_200_OK, status.HTTP_201_CREATED]

    check_out_response = manager_client.post(
        reverse('attendance_record-check-out'),
        {'employee': team_employee.id},
        format='json'
    )
    assert check_out_response.status_code == status.HTTP_200_OK


@pytest.mark.django_db
def test_manager_cannot_check_in_attendance_other_tenant(manager_client, other_tenant_employee):
    response = manager_client.post(
        reverse('attendance_record-check-in'),
        {'employee': other_tenant_employee.id},
        format='json'
    )
    assert response.status_code == status.HTTP_400_BAD_REQUEST
