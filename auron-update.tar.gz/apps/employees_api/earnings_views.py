import logging
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from django.utils import timezone
from django.core.exceptions import ValidationError
from .earnings_models import PayrollPeriod, PayrollDeduction, PayrollConfiguration
from .earnings_serializers import PayrollPeriodSerializer, PayrollDeductionSerializer, PayrollConfigurationSerializer
from django.db import transaction
from django.db.models import Q, Count, Sum, F
from decimal import Decimal
from apps.core.tenant_permissions import TenantPermissionByAction
from apps.auth_api.role_utils import get_effective_role_name
from datetime import date, timedelta
from calendar import monthrange

logger = logging.getLogger(__name__)

class PayrollViewSet(viewsets.ViewSet):
    """ViewSet para gestión de nómina"""
    permission_classes = [TenantPermissionByAction]
    permission_map = {
        'list_periods': 'employees_api.view_employee_payroll',
        'my_earnings': 'employees_api.view_employee_payroll',
        'my_summary': 'employees_api.view_employee_payroll',
        'get_receipt': 'employees_api.view_employee_payroll',
        'period_detail': 'employees_api.view_employee_payroll',
        'generate_regalia': 'employees_api.change_employee_payroll',
        'list_regalia': 'employees_api.view_employee_payroll',
        'pay_regalia': 'employees_api.approve_payroll',
        'generate_vacations': 'employees_api.change_employee_payroll',
        'list_vacations': 'employees_api.view_employee_payroll',
        'enjoy_vacation': 'employees_api.change_employee_payroll',
        'compensate_vacation': 'employees_api.approve_payroll',
        'generate_liquidacion': 'employees_api.change_employee_payroll',
        'list_liquidaciones': 'employees_api.view_employee_payroll',
        'pay_liquidacion': 'employees_api.approve_payroll',
        'register_payment': 'employees_api.approve_payroll',
        'recalculate_period': 'employees_api.change_employee_payroll',
        'submit_for_approval': 'employees_api.change_employee_payroll',
        'approve_period': 'employees_api.approve_payroll',
        'reject_period': 'employees_api.approve_payroll',
        'history': 'employees_api.view_employee_payroll',
        'config': 'employees_api.view_employee_payroll',
        'ensure_period': 'employees_api.change_employee_payroll',
    }
    
    def _require_admin_role(self, request):
        """Validar que el usuario tenga rol de administrador"""
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if get_effective_role_name(request.user, tenant=tenant) not in {'SuperAdmin', 'Client-Admin'}:
            raise PermissionDenied("No autorizado para operaciones de nómina.")

    @action(detail=False, methods=['get', 'put'], url_path='config')
    def config(self, request):
        """Obtener o actualizar la configuración de nómina del tenant (ISR/SFS/AFP)"""
        user = request.user
        tenant = getattr(request, 'tenant', getattr(user, 'tenant', None))
        if not tenant:
            return Response({'error': 'No se pudo determinar el tenant'}, status=400)

        config, _ = PayrollConfiguration.objects.get_or_create(tenant=tenant)

        if request.method == 'PUT':
            self._require_admin_role(request)
            serializer = PayrollConfigurationSerializer(config, data=request.data, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)

        return Response(PayrollConfigurationSerializer(config).data)
    
    def get_queryset(self):
        user = self.request.user
        tenant = getattr(self.request, 'tenant', getattr(user, 'tenant', None))
        if tenant:
            return PayrollPeriod.objects.select_related(
                'employee__user',
                'employee__tenant'
            ).prefetch_related('deductions').filter(employee__tenant=tenant)
        return PayrollPeriod.objects.none()
    
    def _ensure_open_periods(self, tenant):
        """Auto-generar períodos abiertos para empleados activos sin período vigente"""
        from .models import Employee
        today = date.today()
        
        # Determinar período actual
        if today.day <= 15:
            start_date = today.replace(day=1)
            end_date = today.replace(day=15)
        else:
            start_date = today.replace(day=16)
            end_date = today.replace(day=monthrange(today.year, today.month)[1])
        
        active_employees = Employee.objects.filter(
            tenant=tenant,
            is_active=True
        )
        
        created = 0
        for employee in active_employees:
            _, was_created = PayrollPeriod.objects.get_or_create(
                employee=employee,
                period_start=start_date,
                period_end=end_date,
                defaults={
                    'period_type': 'biweekly',
                    'status': 'open',
                }
            )
            if was_created:
                created += 1
                # Calcular montos iniciales
                period = PayrollPeriod.objects.get(
                    employee=employee,
                    period_start=start_date,
                    period_end=end_date
                )
                period.calculate_amounts()
                period.save()
        
        return created

    @action(detail=False, methods=['get'], url_path='client/payroll')
    def list_periods(self, request):
        """Endpoint compatible con frontend: GET /payroll/client/payroll/"""
        from apps.employees_api.models import Employee
        from apps.pos_api.models import Sale
        from calendar import monthrange
        from django.db.models import Count, Sum

        # OJO: getattr() solo usa el valor por defecto si el atributo NO
        # existe. El middleware deja request.tenant = None para los
        # superusuarios de la plataforma, y en ese caso el respaldo nunca se
        # aplicaba y la nomina salia vacia.
        tenant = getattr(request, 'tenant', None)
        if tenant is None:
            tenant = getattr(getattr(request, 'user', None), 'tenant', None)
        if not tenant:
            return Response({'periods': []})

        today = timezone.localdate()

        if today.day <= 15:
            start_date = today.replace(day=1)
            end_date = today.replace(day=15)
        else:
            start_date = today.replace(day=16)
            end_date = today.replace(day=monthrange(today.year, today.month)[1])

        # 1. Bulk get_or_create períodos actuales (1 query)
        active_employees = Employee.objects.filter(tenant=tenant, is_active=True)
        employee_ids = list(active_employees.values_list('id', flat=True))

        from django.db.models import Q
        existing = PayrollPeriod.objects.filter(
            employee_id__in=employee_ids,
            period_start=start_date,
            period_end=end_date,
        ).values_list('employee_id', flat=True)

        to_create = [
            PayrollPeriod(
                employee_id=eid, period_type='biweekly',
                period_start=start_date, period_end=end_date, status='open',
            )
            for eid in employee_ids if eid not in existing
        ]
        if to_create:
            PayrollPeriod.objects.bulk_create(to_create, ignore_conflicts=True)

        # 2. Bulk sync snapshots + recalcular solo abiertos (bulk_update)
        open_periods = list(PayrollPeriod.objects.filter(
            employee_id__in=employee_ids,
            period_start=start_date, period_end=end_date,
            status='open',
        ).select_related('employee'))

        emp_map = {e.id: e for e in active_employees}
        for period in open_periods:
            emp = emp_map.get(period.employee_id)
            if emp:
                period.fixed_salary_snapshot = emp.fixed_salary
                period.commission_rate_snapshot = emp.commission_rate
                period.payment_type_snapshot = emp.payment_type
                period.calculate_amounts()

        if open_periods:
            PayrollPeriod.objects.bulk_update(open_periods, [
                'fixed_salary_snapshot', 'commission_rate_snapshot', 'payment_type_snapshot',
                'base_salary', 'commission_earnings', 'gross_amount',
                'deductions_total', 'net_amount', 'can_pay', 'pay_block_reason',
            ])

        # 3. Query períodos actuales (1 query)
        periods = self.get_queryset().select_related('employee__user')
        periods = periods.filter(period_start=start_date, period_end=end_date)

        status_filter = request.query_params.get('status')
        if status_filter:
            periods = periods.filter(status=status_filter)

        # 4. Ventas agrupadas (1 query con annotate) - alineado con cálculo determinístico
        period_ids = list(periods.values_list('id', flat=True))
        # Usar rango aware con TZ del tenant para consistencia
        from zoneinfo import ZoneInfo
        from django.utils.timezone import make_aware
        import datetime
        try:
            tenant_tz = ZoneInfo(getattr(tenant, 'timezone', None) or 'America/Santo_Domingo')
        except Exception:
            tenant_tz = ZoneInfo('America/Santo_Domingo')
        start_dt_aware = make_aware(datetime.datetime.combine(start_date, datetime.time.min), timezone=tenant_tz)
        end_dt_aware = make_aware(datetime.datetime.combine(end_date, datetime.time.max), timezone=tenant_tz)
        # ── Atribución de ventas por empleado ────────────────────────────
        # Regla de negocio: la venta se contabiliza UNA sola vez en la venta
        # bruta del negocio, pero cada empleado ve únicamente SUS líneas.
        #
        # Se aplican las MISMAS fuentes que usa la nómina (regla de fuente
        # única), por lo que reportar nunca puede contradecir el cálculo:
        #   · ventas SIN comisión por línea -> se imputan al empleado de la
        #     venta (comportamiento histórico, sin cambios);
        #   · ventas CON comisión por línea -> se imputa a cada empleado el
        #     importe de SUS líneas. Los productos no generan comisión de
        #     servicios, así que no suman a nadie.
        from apps.pos_api.models import SaleDetail

        sales_window = dict(
            tenant=tenant,
            date_time__gte=start_dt_aware,
            date_time__lte=end_dt_aware,
            status='confirmed',
        )

        # Ventas que ya tienen comisiones por línea: se imputan por línea.
        line_sale_ids = SaleDetail.objects.filter(
            sale__tenant=tenant,
            sale__date_time__gte=start_dt_aware,
            sale__date_time__lte=end_dt_aware,
            sale__status='confirmed',
            employee_id__in=employee_ids,
            commission_amount_snapshot__isnull=False,
        ).values('sale_id')

        # Fuente SALE: ventas históricas / un solo barbero.
        sale_level_agg = Sale.objects.filter(
            **sales_window,
            employee_id__in=employee_ids,
        ).exclude(id__in=line_sale_ids).values('employee_id').annotate(
            services_count=Count('id'),
            gross_sales=Sum('total'),
        )

        # Fuente LINE: atribución por línea de servicio.
        line_agg = SaleDetail.objects.filter(
            sale__tenant=tenant,
            sale__date_time__gte=start_dt_aware,
            sale__date_time__lte=end_dt_aware,
            sale__status='confirmed',
            employee_id__in=employee_ids,
            commission_amount_snapshot__isnull=False,
        ).values('employee_id').annotate(
            services_count=Count('sale_id', distinct=True),
            gross_sales=Sum(F('price') * F('quantity')),
        )

        gross_by_employee = {emp_id: Decimal('0.00') for emp_id in employee_ids}
        services_by_employee = {emp_id: 0 for emp_id in employee_ids}
        for row in sale_level_agg:
            gross_by_employee[row['employee_id']] = row['gross_sales'] or Decimal('0.00')
            services_by_employee[row['employee_id']] = row['services_count'] or 0
        for row in line_agg:
            emp_id = row['employee_id']
            gross_by_employee[emp_id] = (
                gross_by_employee.get(emp_id, Decimal('0.00')) + (row['gross_sales'] or Decimal('0.00'))
            )
            services_by_employee[emp_id] = (
                services_by_employee.get(emp_id, 0) + (row['services_count'] or 0)
            )

        sales_by_emp = {
            emp_id: {
                'services_count': services_by_employee.get(emp_id, 0),
                'gross_sales': float(gross_by_employee.get(emp_id) or 0),
            }
            for emp_id in employee_ids
        }

        # 5. Construir respuesta
        from apps.employees_api.payroll_services import PayrollCalculationService
        periods_data = []
        for period in periods:
            emp = period.employee
            user = emp.user

            sales_data = sales_by_emp.get(period.employee_id, {'services_count': 0, 'gross_sales': 0.0})

            try:
                calc = PayrollCalculationService.calculate_from_snapshots(period)
                display_base_salary = float(calc['base_salary'])
                display_commission = float(calc['commission_earnings'])
                display_gross = float(calc['gross_amount'])
            except Exception:
                display_base_salary = float(period.base_salary)
                display_commission = float(period.commission_earnings)
                display_gross = float(period.gross_amount)

            display_deductions = float(period.deductions_total)
            display_net = display_gross - display_deductions

            periods_data.append({
                'id': period.id,
                'employee_id': period.employee_id,
                'employee_name': user.full_name or user.email,
                'period_display': period.period_display,
                'status': period.status,
                'base_salary': display_base_salary,
                'commission_earnings': display_commission,
                'gross_amount': display_gross,
                'net_amount': display_net,
                'deductions_total': display_deductions,
                'period_start': period.period_start.isoformat(),
                'period_end': period.period_end.isoformat(),
                'can_pay': period.can_pay,
                'pay_block_reason': period.pay_block_reason,
                # Usar snapshot del período para consistencia con montos calculados
                'employee_payment_type': period.payment_type_snapshot or emp.payment_type,
                'employee_commission_rate': float(period.commission_rate_snapshot if period.commission_rate_snapshot is not None else (emp.commission_rate or 0)),
                # Configuración actual del empleado (informativa, puede diferir si cambió después)
                'current_payment_type': emp.payment_type,
                'current_commission_rate': float(emp.commission_rate or 0),
                'employee_profession': emp.get_profession_display() or emp.profession or '',
                'services_count': sales_data['services_count'],
                'gross_sales': round(sales_data['gross_sales'], 2),
            })

        return Response({'periods': periods_data})

    @action(detail=False, methods=['post'], url_path='client/payroll/ensure-period')
    def ensure_period(self, request):
        """Crea el período de nómina abierto actual para un empleado si no existe.

        Necesario para que "Liquidar" funcione con empleados que aún no tienen período
        (los períodos solo se generaban al emitir un préstamo). Idempotente: si el
        empleado ya tiene un período abierto en el ciclo actual, lo devuelve tal cual.
        """
        from apps.employees_api.models import Employee
        from calendar import monthrange

        self._require_admin_role(request)

        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'error': 'No se pudo determinar el tenant'}, status=400)

        employee_id = request.data.get('employee_id')
        if not employee_id:
            return Response({'error': 'employee_id es requerido'}, status=400)

        try:
            employee = Employee.objects.get(id=employee_id, tenant=tenant, is_active=True)
        except Employee.DoesNotExist:
            return Response({'error': 'Empleado no encontrado'}, status=404)

        today = timezone.localdate()
        if today.day <= 15:
            start_date = today.replace(day=1)
            end_date = today.replace(day=15)
        else:
            start_date = today.replace(day=16)
            end_date = today.replace(day=monthrange(today.year, today.month)[1])

        period, created = PayrollPeriod.objects.get_or_create(
            employee=employee,
            period_start=start_date,
            period_end=end_date,
            defaults={'period_type': 'biweekly', 'status': 'open'},
        )

        if created or period.status == 'open':
            period.calculate_amounts()
            period.save(update_fields=[
                'base_salary', 'commission_earnings', 'gross_amount',
                'deductions_total', 'net_amount', 'can_pay', 'pay_block_reason',
            ])

        return Response({
            'id': period.id,
            'employee_id': employee.id,
            'status': period.status,
            'net_amount': float(period.net_amount),
            'gross_amount': float(period.gross_amount),
            'created': created,
        })

    @action(detail=False, methods=['get'], url_path='client/payroll/history')
    def history(self, request):
        """Listar períodos pagados o cerrados (historial) con datos completos"""
        # Filtrar períodos que ya fueron pagados o aprobados (incluye los que fueron cerrados)
        periods = self.get_queryset().filter(status__in=['paid', 'approved', 'closed', 'rejected'])
        periods_data = []
        for p in periods:
            # Mapear estados legacy
            status = p.status
            if status == 'ready':
                status = 'approved'
            periods_data.append({
                'id': p.id,
                'employee_name': p.employee.user.full_name or p.employee.user.email,
                'period_display': p.period_display,
                'status': status,
                'base_salary': float(p.base_salary),
                'commission_earnings': float(p.commission_earnings),
                'gross_amount': float(p.gross_amount),
                'net_amount': float(p.net_amount),
                'deductions_total': float(p.deductions_total),
                'period_start': p.period_start.isoformat(),
                'period_end': p.period_end.isoformat(),
                'can_pay': p.can_pay,
                'pay_block_reason': p.pay_block_reason,
                'paid_at': p.paid_at.isoformat() if p.paid_at else None,
            })
        return Response({'periods': periods_data})

    @action(detail=False, methods=['get'], url_path='client/payroll/(?P<period_id>[^/.]+)/detail')
    def period_detail(self, request, period_id=None):
        """Detalle financiero completo de un período (servicios, comisiones, deducciones)."""
        try:
            period = PayrollPeriod.objects.select_related('employee__user', 'employee__tenant').get(id=period_id)
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)

        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if period.employee.tenant != tenant and not request.user.is_superuser:
            return Response({'error': 'No tienes permiso'}, status=403)

        from apps.pos_api.models import Sale, SaleDetail
        from zoneinfo import ZoneInfo
        from django.utils.timezone import make_aware
        import datetime
        try:
            tenant_tz = ZoneInfo(getattr(period.employee.tenant, 'timezone', None) or 'America/Santo_Domingo')
        except Exception:
            tenant_tz = ZoneInfo('America/Santo_Domingo')
        start_dt = make_aware(datetime.datetime.combine(period.period_start, datetime.time.min), timezone=tenant_tz)
        end_dt = make_aware(datetime.datetime.combine(period.period_end, datetime.time.max), timezone=tenant_tz)

        # Servicios que generan comisión (fuente única)
        services = []
        line_details = SaleDetail.objects.filter(
            employee=period.employee,
            sale__tenant=period.employee.tenant,
            sale__date_time__gte=start_dt,
            sale__date_time__lte=end_dt,
            sale__status='confirmed',
            commission_amount_snapshot__isnull=False,
        ).select_related('sale', 'employee')
        for d in line_details:
            services.append({
                'sale_id': d.sale_id,
                'service': d.name,
                'quantity': float(d.quantity),
                'line_total': float((d.price or 0) * (d.quantity or 0)),
                'commission_rate': float(d.commission_rate_snapshot) if d.commission_rate_snapshot is not None else None,
                'commission_amount': float(d.commission_amount_snapshot) if d.commission_amount_snapshot is not None else 0.0,
            })

        deductions = [
            {'type': dd.get_deduction_type_display(), 'amount': float(dd.amount), 'description': dd.description, 'source': dd.source}
            for dd in period.deductions.all()
        ]

        adjustments = []
        try:
            from apps.employees_api.adjustment_models import CommissionAdjustment
            for a in CommissionAdjustment.objects.filter(payroll_period=period):
                adjustments.append({'reason': a.reason, 'amount': float(a.amount), 'description': a.description})
        except Exception:
            pass

        return Response({
            'period_id': period.id,
            'employee': {
                'id': period.employee.id,
                'name': period.employee.user.full_name or period.employee.user.email,
                'payment_type': period.employee.payment_type,
                'profession': period.employee.profession or '',
            },
            'period': {
                'type': period.period_type,
                'start': period.period_start.isoformat(),
                'end': period.period_end.isoformat(),
                'display': period.period_display,
                'status': period.status,
            },
            'compensation': {
                'payment_type': period.payment_type_snapshot or period.employee.payment_type,
                'fixed_salary': float(period.fixed_salary_snapshot or period.employee.fixed_salary or 0),
                'commission_rate': float(period.commission_rate_snapshot or period.employee.commission_rate or 0),
            },
            'amounts': {
                'base_salary': float(period.base_salary),
                'commission_earnings': float(period.commission_earnings),
                'christmas_bonus': float(period.christmas_bonus),
                'gross_amount': float(period.gross_amount),
                'deductions_total': float(period.deductions_total),
                'net_amount': float(period.net_amount),
            },
            'employer_contributions': {
                'sfs': float(period.employer_sfs),
                'afp': float(period.employer_afp),
                'srl': float(period.employer_srl),
                'infotep': float(period.employer_infotep),
                'total': float(period.employer_total),
            },
            'services': services,
            'adjustments': adjustments,
            'deductions': deductions,
            'can_pay': period.can_pay,
            'pay_block_reason': period.pay_block_reason,
        })
    @action(detail=False, methods=['post'], url_path='client/payroll/generate-regalia')
    def generate_regalia(self, request):
        """Genera regalía pascual para todos los empleados activos del tenant."""
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'error': 'No se pudo determinar el tenant'}, status=400)

        year = request.data.get('year') or __import__('datetime').date.today().year
        try:
            year = int(year)
        except (ValueError, TypeError):
            return Response({'error': 'Año inválido'}, status=400)

        from apps.employees_api.models import Employee
        from apps.employees_api.earnings_models import RegaliaPascual

        employees = Employee.objects.filter(tenant=tenant, is_active=True)
        created = 0
        for emp in employees:
            RegaliaPascual.calculate_for_employee(emp, year)
            created += 1

        return Response({'message': f'Regalía generada para {created} empleados', 'year': year})

    @action(detail=False, methods=['get'], url_path='client/payroll/regalia')
    def list_regalia(self, request):
        """Lista regalías pascuales del tenant."""
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'regalias': []})
        from apps.employees_api.earnings_models import RegaliaPascual
        qs = RegaliaPascual.objects.filter(tenant=tenant)
        year = request.query_params.get('year')
        if year:
            qs = qs.filter(year=year)
        data = [
            {
                'id': r.id,
                'employee_id': r.employee_id,
                'employee_name': r.employee.user.full_name or r.employee.user.email,
                'year': r.year,
                'ordinary_salary_annual': float(r.ordinary_salary_annual),
                'amount': float(r.amount),
                'is_tax_exempt': r.is_tax_exempt,
                'status': r.status,
                'paid_at': r.paid_at.isoformat() if r.paid_at else None,
            }
            for r in qs
        ]
        return Response({'regalias': data})

    @action(detail=False, methods=['post'], url_path='client/payroll/regalia/(?P<regalia_id>[^/.]+)/pay')
    def pay_regalia(self, request, regalia_id=None):
        """Marca una regalía como pagada."""
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        from apps.employees_api.earnings_models import RegaliaPascual
        try:
            regalia = RegaliaPascual.objects.get(id=regalia_id, tenant=tenant)
        except RegaliaPascual.DoesNotExist:
            return Response({'error': 'Regalía no encontrada'}, status=404)
        if regalia.status == 'paid':
            return Response({'error': 'Ya fue pagada'}, status=400)
        regalia.mark_as_paid(request.user, request.data.get('reference'))
        return Response({'message': 'Regalía pagada', 'amount': float(regalia.amount)})

    @action(detail=False, methods=['post'], url_path='client/payroll/generate-vacations')
    def generate_vacations(self, request):
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'error': 'No se pudo determinar el tenant'}, status=400)
        year = request.data.get('year') or __import__('datetime').date.today().year
        try:
            year = int(year)
        except (ValueError, TypeError):
            return Response({'error': 'Año inválido'}, status=400)
        from apps.employees_api.models import Employee
        from apps.employees_api.earnings_models import Vacation
        employees = Employee.objects.filter(tenant=tenant, is_active=True)
        created = 0
        for emp in employees:
            Vacation.calculate_for_employee(emp, year)
            created += 1
        return Response({'message': f'Vacaciones generadas para {created} empleados', 'year': year})

    @action(detail=False, methods=['get'], url_path='client/payroll/vacations')
    def list_vacations(self, request):
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'vacations': []})
        from apps.employees_api.earnings_models import Vacation
        qs = Vacation.objects.filter(tenant=tenant)
        year = request.query_params.get('year')
        if year:
            qs = qs.filter(year=year)
        data = [
            {
                'id': v.id,
                'employee_id': v.employee_id,
                'employee_name': v.employee.user.full_name or v.employee.user.email,
                'year': v.year,
                'days_entitled': v.days_entitled,
                'days_taken': v.days_taken,
                'days_remaining': v.days_entitled - v.days_taken,
                'paid_amount': float(v.paid_amount),
                'status': v.status,
                'start_date': v.start_date.isoformat() if v.start_date else None,
                'end_date': v.end_date.isoformat() if v.end_date else None,
            }
            for v in qs
        ]
        return Response({'vacations': data})

    @action(detail=False, methods=['post'], url_path='client/payroll/vacations/(?P<vacation_id>[^/.]+)/enjoy')
    def enjoy_vacation(self, request, vacation_id=None):
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        from apps.employees_api.earnings_models import Vacation
        from datetime import date
        try:
            vac = Vacation.objects.get(id=vacation_id, tenant=tenant)
        except Vacation.DoesNotExist:
            return Response({'error': 'Vacación no encontrada'}, status=404)
        start = request.data.get('start_date')
        end = request.data.get('end_date')
        if not start or not end:
            return Response({'error': 'start_date y end_date requeridos'}, status=400)
        try:
            vac.mark_enjoyed(date.fromisoformat(start), date.fromisoformat(end))
        except ValueError as e:
            return Response({'error': str(e)}, status=400)
        return Response({'message': 'Vacación registrada', 'days_taken': vac.days_taken})

    @action(detail=False, methods=['post'], url_path='client/payroll/vacations/(?P<vacation_id>[^/.]+)/compensate')
    def compensate_vacation(self, request, vacation_id=None):
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        from apps.employees_api.earnings_models import Vacation
        try:
            vac = Vacation.objects.get(id=vacation_id, tenant=tenant)
        except Vacation.DoesNotExist:
            return Response({'error': 'Vacación no encontrada'}, status=404)
        if vac.status == 'compensated':
            return Response({'error': 'Ya fue compensada'}, status=400)
        vac.compensate(request.user, request.data.get('termination_type'), None)
        return Response({'message': 'Vacación compensada', 'paid_amount': float(vac.paid_amount)})

    @action(detail=False, methods=['post'], url_path='client/payroll/generate-liquidacion')
    def generate_liquidacion(self, request):
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'error': 'No se pudo determinar el tenant'}, status=400)
        from apps.employees_api.models import Employee
        from apps.employees_api.earnings_models import Liquidacion
        employee_id = request.data.get('employee_id')
        termination_date = request.data.get('termination_date')
        termination_type = request.data.get('termination_type', 'desahucio')
        if not employee_id or not termination_date:
            return Response({'error': 'employee_id y termination_date requeridos'}, status=400)
        try:
            employee = Employee.objects.get(id=employee_id, tenant=tenant)
        except Employee.DoesNotExist:
            return Response({'error': 'Empleado no encontrado'}, status=404)
        from datetime import date
        try:
            td = date.fromisoformat(termination_date)
        except ValueError:
            return Response({'error': 'Fecha inválida'}, status=400)
        total_utilities = request.data.get('total_utilities')
        total_payroll = request.data.get('total_payroll')
        participacion_exempt = bool(request.data.get('participacion_exempt', False))
        asistencia = request.data.get('asistencia_economica', '0')
        liq = Liquidacion.calculate(
            employee=employee,
            termination_date=td,
            termination_type=termination_type,
            total_utilities=total_utilities,
            total_payroll=total_payroll,
            participacion_exempt=participacion_exempt,
            asistencia_economica=asistencia,
        )
        return Response({
            'id': liq.id,
            'total': float(liq.total),
            'preaviso': float(liq.preaviso_amount),
            'cesantia': float(liq.cesantia_amount),
            'vacaciones': float(liq.vacation_amount),
            'regalia': float(liq.regalia_proporcional),
            'participacion': float(liq.participacion_beneficios),
        })

    @action(detail=False, methods=['get'], url_path='client/payroll/liquidaciones')
    def list_liquidaciones(self, request):
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        if not tenant:
            return Response({'liquidaciones': []})
        from apps.employees_api.earnings_models import Liquidacion
        qs = Liquidacion.objects.filter(tenant=tenant)
        data = [
            {
                'id': l.id,
                'employee_id': l.employee_id,
                'employee_name': l.employee.user.full_name or l.employee.user.email,
                'termination_date': l.termination_date.isoformat(),
                'termination_type': l.termination_type,
                'total': float(l.total),
                'status': l.status,
                'paid_at': l.paid_at.isoformat() if l.paid_at else None,
            }
            for l in qs
        ]
        return Response({'liquidaciones': data})

    @action(detail=False, methods=['post'], url_path='client/payroll/liquidaciones/(?P<liq_id>[^/.]+)/pay')
    def pay_liquidacion(self, request, liq_id=None):
        self._require_admin_role(request)
        tenant = getattr(request, 'tenant', getattr(request.user, 'tenant', None))
        from apps.employees_api.earnings_models import Liquidacion
        try:
            liq = Liquidacion.objects.get(id=liq_id, tenant=tenant)
        except Liquidacion.DoesNotExist:
            return Response({'error': 'Liquidación no encontrada'}, status=404)
        if liq.status == 'paid':
            return Response({'error': 'Ya fue pagada'}, status=400)
        liq.mark_as_paid(request.user, request.data.get('reference'))
        return Response({'message': 'Liquidación pagada', 'total': float(liq.total)})
    @action(detail=False, methods=['get'], url_path='client/payroll/my-earnings')
    def my_earnings(self, request):
        """Mis períodos de nómina (filtrado por empleado logueado)"""
        try:
            employee = request.user.employee_profile
        except AttributeError:
            return Response({'error': 'No tienes perfil de empleado'}, status=403)

        periods = PayrollPeriod.objects.filter(
            employee=employee,
            employee__tenant=getattr(request, 'tenant', request.user.tenant)
        ).select_related('employee__user').order_by('-period_start')

        periods_data = []
        for period in periods:
            status = period.status
            if status == 'ready':
                status = 'approved'
            periods_data.append({
                'id': period.id,
                'period_display': period.period_display,
                'status': status,
                'base_salary': float(period.base_salary),
                'commission_earnings': float(period.commission_earnings),
                'gross_amount': float(period.gross_amount),
                'net_amount': float(period.net_amount),
                'christmas_bonus': float(period.christmas_bonus),
                'deductions_total': float(period.deductions_total),
                'period_start': period.period_start.isoformat(),
                'period_end': period.period_end.isoformat(),
                'can_pay': period.can_pay,
                'pay_block_reason': period.pay_block_reason,
                'payment_method': period.get_payment_method_display() if period.payment_method else None,
                'paid_at': period.paid_at.isoformat() if period.paid_at else None,
            })

        return Response({'periods': periods_data})

    @action(detail=False, methods=['get'], url_path='client/payroll/my-summary')
    def my_summary(self, request):
        """Resumen de ingresos del empleado logueado"""
        try:
            employee = request.user.employee_profile
        except AttributeError:
            return Response({'error': 'No tienes perfil de empleado'}, status=403)

        periods = PayrollPeriod.objects.filter(
            employee=employee,
            employee__tenant=getattr(request, 'tenant', request.user.tenant)
        ).exclude(status='rejected')

        total_gross = sum(float(p.gross_amount) for p in periods)
        total_net = sum(float(p.net_amount) for p in periods)
        total_deductions = sum(float(p.deductions_total) for p in periods)
        paid_periods = periods.filter(status='paid').count()
        pending_periods = periods.filter(status__in=['open', 'pending_approval', 'approved']).count()

        return Response({
            'total_gross': round(total_gross, 2),
            'total_net': round(total_net, 2),
            'total_deductions': round(total_deductions, 2),
            'paid_periods': paid_periods,
            'pending_periods': pending_periods,
            'payment_type': employee.get_payment_type_display(),
            'commission_rate': float(employee.commission_rate),
        })
    
    @action(detail=False, methods=['post'], url_path='client/payroll/register_payment')
    def register_payment(self, request):
        """Endpoint compatible con frontend: POST /payroll/client/payroll/register_payment/"""
        self._require_admin_role(request)
        
        period_id = request.data.get('period_id')
        payment_method = request.data.get('payment_method')
        payment_reference = request.data.get('payment_reference', '')
        
        if not period_id or not payment_method:
            return Response({'error': 'period_id y payment_method son requeridos'}, status=400)
        
        try:
            with transaction.atomic():
                # 🔒 BLOQUEO REAL DE FILA
                period = PayrollPeriod.objects.select_for_update().get(id=period_id)
                
                if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                    return Response({'error': 'No tienes permiso'}, status=403)
                
                if period.status == 'paid':
                    return Response({'error': 'Ya fue pagado'}, status=400)
                
                if period.status != 'approved':
                    return Response({'error': 'El período debe estar aprobado antes de pagar'}, status=400)
                
                if not period.can_pay:
                    return Response({'error': period.pay_block_reason}, status=400)
                
                period.mark_as_paid(payment_method, payment_reference, request.user)
                self._send_payment_notification(period)
            
            return Response({
                'payment_id': str(period.id),
                'message': 'Pago registrado exitosamente',
                'amount_paid': float(period.net_amount),
                'paid_at': period.paid_at.isoformat()
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)
        except ValueError as e:
            return Response({'error': str(e)}, status=400)
    
    @action(detail=False, methods=['post'], url_path='client/payroll/(?P<period_id>[^/.]+)/recalculate')
    def recalculate_period(self, request, period_id=None):
        """Recalcular período manualmente (solo si está open o pending)"""
        self._require_admin_role(request)
        
        try:
            period = PayrollPeriod.objects.get(id=period_id)
            
            if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                return Response({'error': 'No tienes permiso'}, status=403)
            
            if period.status in ['approved', 'paid']:
                return Response({'error': 'No se puede recalcular un período aprobado o pagado'}, status=400)
            
            period.calculate_amounts()
            period.save()
            
            return Response({
                'message': 'Período recalculado exitosamente',
                'gross_amount': float(period.gross_amount),
                'net_amount': float(period.net_amount)
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)
    
    @action(detail=False, methods=['post'], url_path='client/payroll/(?P<period_id>[^/.]+)/submit')
    def submit_for_approval(self, request, period_id=None):
        """Enviar período para aprobación"""
        self._require_admin_role(request)

        try:
            period = PayrollPeriod.objects.get(id=period_id)
            
            if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                return Response({'error': 'No tienes permiso'}, status=403)
            
            if period.status != 'open':
                return Response({'error': 'Solo se pueden enviar períodos abiertos'}, status=400)
            
            period.submitted_by = request.user
            period.close_period()
            
            return Response({
                'message': 'Período enviado para aprobación',
                'status': period.status
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)
    
    @action(detail=False, methods=['post'], url_path='client/payroll/(?P<period_id>[^/.]+)/approve')
    def approve_period(self, request, period_id=None):
        """Aprobar período para pago"""
        self._require_admin_role(request)
        
        try:
            # CONCURRENCIA: bloquear el período dentro de la transacción para que dos
            # aprobaciones simultáneas no aprueben dos veces (check + save atómicos).
            with transaction.atomic():
                period = PayrollPeriod.objects.select_for_update().get(id=period_id)
                
                if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                    return Response({'error': 'No tienes permiso'}, status=403)
                
                period.approve(request.user)
            
            # Notificación FUERA del bloque atómico: solo se envía si la aprobación
            # realmente hizo commit, evitando duplicados.
            self._send_approval_notification(period)
            
            return Response({
                'message': 'Período aprobado exitosamente',
                'status': period.status
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)
        except ValueError as e:
            return Response({'error': str(e)}, status=400)
        except ValidationError as e:
            return Response({'error': str(e)}, status=400)
    
    @action(detail=False, methods=['post'], url_path='client/payroll/(?P<period_id>[^/.]+)/reject')
    def reject_period(self, request, period_id=None):
        """Rechazar período"""
        self._require_admin_role(request)
        
        reason = request.data.get('reason', 'Sin motivo especificado')
        
        try:
            period = PayrollPeriod.objects.get(id=period_id)
            
            if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                return Response({'error': 'No tienes permiso'}, status=403)
            
            period.reject(request.user, reason)
            self._send_rejection_notification(period)
            
            return Response({
                'message': 'Período rechazado',
                'status': period.status,
                'reason': reason
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Período no encontrado'}, status=404)
        except ValueError as e:
            return Response({'error': str(e)}, status=400)
    
    def _send_payment_notification(self, period):
        """Enviar notificación de pago"""
        try:
            from apps.auth_api.tasks import send_email_async
            from apps.emails.service import EmailRenderer

            employee_email = period.employee.user.email
            employee_name = period.employee.user.full_name or employee_email

            tenant = period.employee.tenant
            business_name = tenant.name if tenant else 'Auron Suite'

            subject = f'Pago Procesado - {period.period_display}'
            message = f'''Hola {employee_name},

Tu pago del período {period.period_display} ha sido procesado exitosamente.

Detalles:
- Sueldo Base: ${period.base_salary:,.2f}
- Comisiones de Ventas: ${period.commission_earnings:,.2f}
- Monto Bruto: ${period.gross_amount:,.2f}
- Deducciones: ${period.deductions_total:,.2f}
- Monto Neto: ${period.net_amount:,.2f}
- Método: {period.get_payment_method_display()}
- Referencia: {period.payment_reference or 'N/A'}

Saludos,
Equipo de Nómina'''

            html_body = EmailRenderer.render('payroll_notification.html', {
                'business_name': business_name,
                'title': subject,
                'user_full_name': employee_name,
                'message': f'Tu pago del período <strong>{period.period_display}</strong> ha sido procesado exitosamente.',
                'details': [
                    ('Sueldo Base', f'${period.base_salary:,.2f}'),
                    ('Comisiones de Ventas', f'${period.commission_earnings:,.2f}'),
                    ('Monto Bruto', f'${period.gross_amount:,.2f}'),
                    ('Deducciones', f'${period.deductions_total:,.2f}'),
                    ('Monto Neto', f'${period.net_amount:,.2f}'),
                    ('Método', period.get_payment_method_display()),
                    ('Referencia', period.payment_reference or 'N/A'),
                ],
            })

            send_email_async.delay(
                subject=subject,
                message=message,
                from_email='',
                recipient_list=[employee_email],
                html_message=html_body,
            )

            period.notification_sent = True
            period.notification_sent_at = timezone.now()
            period.save()
        except Exception as e:
            logger.error("Error sending payment notification for period %s: %s", period.id, e)

    def _send_approval_notification(self, period):
        """Enviar notificación de aprobación"""
        try:
            from apps.auth_api.tasks import send_email_async
            from apps.emails.service import EmailRenderer

            employee_email = period.employee.user.email
            employee_name = period.employee.user.full_name or employee_email

            tenant = period.employee.tenant
            business_name = tenant.name if tenant else 'Auron Suite'

            subject = f'Período Aprobado - {period.period_display}'
            message = f'''Hola {employee_name},

Tu período de nómina {period.period_display} ha sido aprobado.

Monto a recibir: ${period.net_amount:,.2f}

El pago será procesado próximamente.

Saludos,
Equipo de Nómina'''

            html_body = EmailRenderer.render('payroll_notification.html', {
                'business_name': business_name,
                'title': subject,
                'user_full_name': employee_name,
                'message': f'Tu período de nómina <strong>{period.period_display}</strong> ha sido aprobado.',
                'details': [
                    ('Monto a recibir', f'${period.net_amount:,.2f}'),
                ],
                'extra_note': 'El pago será procesado próximamente.',
            })

            send_email_async.delay(
                subject=subject,
                message=message,
                from_email='',
                recipient_list=[employee_email],
                html_message=html_body,
            )
        except Exception as e:
            logger.error("Error sending approval notification for period %s: %s", period.id, e)

    def _send_rejection_notification(self, period):
        """Enviar notificación de rechazo"""
        try:
            from apps.auth_api.tasks import send_email_async
            from apps.emails.service import EmailRenderer

            employee_email = period.employee.user.email
            employee_name = period.employee.user.full_name or employee_email

            tenant = period.employee.tenant
            business_name = tenant.name if tenant else 'Auron Suite'

            subject = f'Período Rechazado - {period.period_display}'
            message = f'''Hola {employee_name},

Tu período de nómina {period.period_display} ha sido rechazado.

Motivo: {period.rejection_reason}

Por favor, contacta con el departamento de nómina para más información.

Saludos,
Equipo de Nómina'''

            html_body = EmailRenderer.render('payroll_notification.html', {
                'business_name': business_name,
                'title': subject,
                'user_full_name': employee_name,
                'message': f'Tu período de nómina <strong>{period.period_display}</strong> ha sido rechazado.',
                'details': [
                    ('Motivo', period.rejection_reason),
                ],
                'extra_note': 'Contacta con el departamento de nómina para más información.',
            })

            send_email_async.delay(
                subject=subject,
                message=message,
                from_email='',
                recipient_list=[employee_email],
                html_message=html_body,
            )
        except Exception as e:
            logger.error("Error sending rejection notification for period %s: %s", period.id, e)
    
    @action(detail=False, methods=['get'], url_path='payments/(?P<payment_id>[^/.]+)/receipt')
    def get_receipt(self, request, payment_id=None):
        """Endpoint compatible con frontend: GET /payroll/client/payroll/payments/{id}/receipt/"""
        try:
            period = PayrollPeriod.objects.select_related('employee__user', 'employee__tenant').get(id=payment_id)
            
            if period.employee.tenant != getattr(request, 'tenant', request.user.tenant):
                return Response({'error': 'No tienes permiso'}, status=403)

            if period.status != 'paid':
                return Response({'error': 'El período no ha sido pagado'}, status=400)

            deductions = [{'type': d.get_deduction_type_display(), 'amount': float(d.amount), 'description': d.description} for d in period.deductions.all()]
            
            return Response({
                'payment_id': str(period.id),
                'company': {'name': period.employee.tenant.name, 'address': getattr(period.employee.tenant, 'address', 'N/A')},
                'employee': {'name': period.employee.user.full_name or period.employee.user.email, 'email': period.employee.user.email, 'payment_type': period.employee.get_payment_type_display()},
                'period': {'display': period.period_display, 'start_date': period.period_start.isoformat(), 'end_date': period.period_end.isoformat(), 'type': period.get_period_type_display()},
                'amounts': {'base_salary': float(period.base_salary), 'commission_earnings': float(period.commission_earnings), 'gross_amount': float(period.gross_amount), 'deductions': {'total': float(period.deductions_total), 'items': deductions}, 'net_amount': float(period.net_amount), 'christmas_bonus': float(period.christmas_bonus)},
                'employer_contributions': {'sfs': float(period.employer_sfs), 'afp': float(period.employer_afp), 'srl': float(period.employer_srl), 'infotep': float(period.employer_infotep), 'total': float(period.employer_total)},
                'payment_info': {'method': period.get_payment_method_display() if period.payment_method else 'N/A', 'reference': period.payment_reference or 'N/A', 'paid_at': period.paid_at.isoformat() if period.paid_at else None, 'paid_by': period.paid_by.full_name if period.paid_by else 'N/A'}
            })
        except PayrollPeriod.DoesNotExist:
            return Response({'error': 'Recibo no encontrado'}, status=404)


class PayrollConfigurationViewSet(viewsets.GenericViewSet):
    """ViewSet para gestionar configuración global de nómina del tenant"""
    permission_classes = [TenantPermissionByAction]
    permission_map = {
        'retrieve': 'employees_api.view_employee_payroll',
        'update': 'employees_api.manage_payroll_config',
        'partial_update': 'employees_api.manage_payroll_config',
    }
    serializer_class = PayrollConfigurationSerializer

    def get_object(self):
        tenant = getattr(self.request, 'tenant', getattr(self.request.user, 'tenant', None))
        obj, _ = PayrollConfiguration.objects.get_or_create(tenant=tenant)
        return obj

    def retrieve(self, request):
        serializer = self.get_serializer(self.get_object())
        return Response(serializer.data)

    def update(self, request):
        serializer = self.get_serializer(self.get_object(), data=request.data, partial=False)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    def partial_update(self, request):
        serializer = self.get_serializer(self.get_object(), data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
