from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from decimal import Decimal, ROUND_HALF_UP
from calendar import monthrange
from datetime import date, timedelta
import json
import uuid

from django.utils import timezone
from django.db import transaction
from apps.tenants_api.base_viewsets import TenantScopedViewSet
from apps.tenants_api.models import Tenant
from apps.core.tenant_permissions import TenantPermissionByAction
from apps.subscriptions_api.access_control import can_add_employee
from apps.settings_api.utils import maybe_auto_upgrade_employee_limit
from apps.services_api.models import ServiceEmployee
from .models import Employee, WorkSchedule, AttendanceRecord
from apps.roles_api.models import UserRole
from .serializers import EmployeeSerializer, EmployeeServiceSerializer, WorkScheduleSerializer, AttendanceRecordSerializer

class EmployeeViewSet(TenantScopedViewSet):
    queryset = Employee.objects.select_related('user', 'tenant').prefetch_related('employee_services').all()
    serializer_class = EmployeeSerializer
    permission_classes = [TenantPermissionByAction]
    
    # Mapeo de permisos por acción
    permission_map = {
        'list': 'employees_api.view_employee',
        'retrieve': 'employees_api.view_employee',
        'by_user': 'employees_api.view_employee',
        'create': 'employees_api.add_employee',
        'update': 'employees_api.change_employee',
        'partial_update': 'employees_api.change_employee',
        'destroy': 'employees_api.delete_employee',
        'assign_service': 'employees_api.change_employee',
        'assign_services': 'employees_api.change_employee',
        'services': 'employees_api.view_employee',
        'schedule': 'employees_api.view_employee',
        'set_schedule': 'employees_api.change_employee',
        'stats': 'employees_api.view_employee',
        'payroll_config': 'employees_api.view_employee_payroll',
        'payment_history': 'employees_api.view_employee_payroll',
        'payment_stats': 'employees_api.view_employee_payroll',
        'loans': 'employees_api.manage_employee_loans',
        'loans_summary': 'employees_api.view_employee_payroll',
    }

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            import sys
            print(f"=== EMPLOYEE CREATION VALIDATION ERROR ===\nPayload: {request.data}\nErrors: {serializer.errors}\n=============================", file=sys.stderr, flush=True)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        """Override para validar límite de empleados según plan"""
        user = self.request.user
        
        # SuperAdmin: puede crear sin validación de límite
        if user.is_superuser:
            # Asignar tenant si no viene en data
            if 'tenant' not in serializer.validated_data:
                tenant_id = self.request.data.get('tenant_id')
                if not tenant_id:
                    raise ValidationError("Se requiere tenant_id para crear empleados como superadmin")
                from django.shortcuts import get_object_or_404
                tenant = get_object_or_404(Tenant, pk=tenant_id)
                serializer.save(tenant=tenant)
            else:
                serializer.save()
            return
        
        # Usuario normal: validar límite y asignar tenant
        tenant = getattr(self.request, 'tenant', None) or getattr(self.request.user, 'tenant', None)
        if not tenant:
            raise ValidationError("Usuario sin tenant asignado")
        
        current_count = tenant.employees.filter(is_active=True).count() if hasattr(tenant, 'employees') else 0
            
        # Validar límite de empleados según el plan
        plan_type = getattr(tenant, 'plan_type', 'basic')
        if not can_add_employee(tenant, current_count=current_count, amount=1):
            upgrade_result = maybe_auto_upgrade_employee_limit(tenant, changed_by=user)
            tenant.refresh_from_db(fields=['plan_type', 'subscription_plan', 'max_employees', 'max_users', 'settings', 'updated_at'])
            if upgrade_result.get('upgraded'):
                plan_type = getattr(tenant, 'plan_type', plan_type)
            current_count = tenant.employees.filter(is_active=True).count() if hasattr(tenant, 'employees') else 0
            if not can_add_employee(tenant, current_count=current_count, amount=1):
                error_message = f'Su plan {plan_type} no permite más empleados. Actualice su plan.'
                if upgrade_result.get('reason') == 'no_higher_plan':
                    error_message = 'Ya se alcanzó el plan más alto disponible y no hay más capacidad automática para empleados.'
                elif upgrade_result.get('reason') == 'disabled':
                    error_message = f'Su plan {plan_type} no permite más empleados. Actualice su plan.'
                raise ValidationError({
                    'error': 'Límite de empleados alcanzado',
                    'message': error_message,
                    'current': current_count,
                    'limit': tenant.max_employees,
                    'unlimited': tenant.max_employees == 0,
                })

        serializer.save(tenant=tenant)

    def _build_loan_description(
        self,
        *,
        plan_id: str,
        total_amount: Decimal,
        installment_number: int,
        total_installments: int,
        reason: str,
    ) -> str:
        metadata = {
            'plan_id': plan_id,
            'total_amount': str(total_amount.quantize(Decimal('0.01'))),
            'installment_number': installment_number,
            'total_installments': total_installments,
        }
        reason_text = (reason or '').strip()
        return f"{self.LOAN_METADATA_PREFIX}{json.dumps(metadata, separators=(',', ':'))}\n{reason_text}"

    def _extract_loan_metadata(self, deduction):
        description = deduction.description or ''
        if not description.startswith(self.LOAN_METADATA_PREFIX):
            installments = max(int(deduction.installments or 1), 1)
            amount = Decimal(str(deduction.amount or 0))
            return {
                'plan_id': f'legacy-{deduction.id}',
                'total_amount': amount * installments,
                'installment_number': 1,
                'total_installments': installments,
                'reason': description.strip(),
            }

        metadata_line, _, reason = description.partition('\n')
        raw_metadata = metadata_line[len(self.LOAN_METADATA_PREFIX):]

        try:
            parsed = json.loads(raw_metadata)
        except json.JSONDecodeError:
            installments = max(int(deduction.installments or 1), 1)
            amount = Decimal(str(deduction.amount or 0))
            return {
                'plan_id': f'legacy-{deduction.id}',
                'total_amount': amount * installments,
                'installment_number': 1,
                'total_installments': installments,
                'reason': description.strip(),
            }

        total_installments = max(int(parsed.get('total_installments') or deduction.installments or 1), 1)
        installment_number = max(int(parsed.get('installment_number') or 1), 1)

        return {
            'plan_id': parsed.get('plan_id') or f'legacy-{deduction.id}',
            'total_amount': Decimal(str(parsed.get('total_amount') or deduction.amount or 0)),
            'installment_number': installment_number,
            'total_installments': total_installments,
            'reason': reason.strip(),
        }

    def _get_or_create_current_payroll_period(self, employee):
        from apps.employees_api.earnings_models import PayrollPeriod

        period = PayrollPeriod.objects.filter(
            employee=employee,
            status__in=['open', 'pending_approval']
        ).order_by('period_start').first()

        if period:
            return period

        today = timezone.now().date()
        if today.day <= 15:
            start_date = today.replace(day=1)
            end_date = today.replace(day=15)
        else:
            start_date = today.replace(day=16)
            end_date = today.replace(day=monthrange(today.year, today.month)[1])

        period, _ = PayrollPeriod.objects.get_or_create(
            employee=employee,
            period_start=start_date,
            period_end=end_date,
            defaults={
                'period_type': 'biweekly',
                'status': 'open',
            }
        )
        return period

    def _get_next_period_bounds(self, period_type: str, current_start: date, current_end: date):
        if period_type == 'weekly':
            next_start = current_end + timedelta(days=1)
            next_end = next_start + timedelta(days=6)
            return next_start, next_end

        if period_type == 'monthly':
            if current_start.month == 12:
                next_year = current_start.year + 1
                next_month = 1
            else:
                next_year = current_start.year
                next_month = current_start.month + 1
            next_start = date(next_year, next_month, 1)
            next_end = date(next_year, next_month, monthrange(next_year, next_month)[1])
            return next_start, next_end

        if current_start.day == 1:
            next_start = current_start.replace(day=16)
            next_end = current_start.replace(day=monthrange(current_start.year, current_start.month)[1])
            return next_start, next_end

        if current_start.month == 12:
            next_year = current_start.year + 1
            next_month = 1
        else:
            next_year = current_start.year
            next_month = current_start.month + 1
        next_start = date(next_year, next_month, 1)
        next_end = date(next_year, next_month, 15)
        return next_start, next_end

    def _get_or_create_installment_periods(self, employee, installments: int):
        from apps.employees_api.earnings_models import PayrollPeriod

        periods = []
        current_period = self._get_or_create_current_payroll_period(employee)
        periods.append(current_period)

        while len(periods) < installments:
            previous = periods[-1]
            next_start, next_end = self._get_next_period_bounds(
                previous.period_type,
                previous.period_start,
                previous.period_end,
            )
            next_period, _ = PayrollPeriod.objects.get_or_create(
                employee=employee,
                period_start=next_start,
                period_end=next_end,
                defaults={
                    'period_type': previous.period_type,
                    'status': 'open',
                }
            )
            periods.append(next_period)

        return periods

    @action(detail=False, methods=['get'], url_path=r'by-user/(?P<user_id>[^/.]+)')
    def by_user(self, request, user_id=None):
        employee = self.get_queryset().filter(user_id=user_id).first()
        if not employee:
            return Response({'detail': 'Empleado no encontrado'}, status=status.HTTP_404_NOT_FOUND)

        serializer = self.get_serializer(employee)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        employee = self.get_object()
        employee.is_active = False
        employee.save(update_fields=['is_active', 'updated_at'])
        try:
            user_obj = employee.user
            if user_obj and not user_obj.is_superuser:
                user_obj.is_active = False
                user_obj.role = 'CLIENT_STAFF'
                user_obj.save(update_fields=['is_active', 'role'])
        except Exception:
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)

    @action(detail=True, methods=['post'])
    def assign_service(self, request, pk=None):
        employee = self.get_object()
        serializer = EmployeeServiceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(employee=employee)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def assign_services(self, request, pk=None):
        employee = self.get_object()
        service_ids = request.data.get('service_ids', [])
        if not isinstance(service_ids, list):
            return Response({'service_ids': ['Debe proporcionar una lista de ids de servicios.']}, status=status.HTTP_400_BAD_REQUEST)

        from apps.services_api.models import Service
        valid_ids = set()
        for service_id in service_ids:
            if isinstance(service_id, str) and not str(service_id).isdigit():
                return Response({'service_ids': [f'El id "{service_id}" no es válido.']}, status=status.HTTP_400_BAD_REQUEST)
            valid_ids.add(int(service_id))

        with transaction.atomic():
            ServiceEmployee.objects.filter(employee=employee).delete()
            servicios = Service.objects.filter(id__in=valid_ids, is_active=True, tenant=self.request.tenant)
            encontrados = {s.id for s in servicios}
            faltantes = valid_ids - encontrados
            if faltantes:
                raise ValidationError({'service_ids': [f'Los servicios {sorted(faltantes)} no existen o no pertenecen a este negocio.']})
            ServiceEmployee.objects.bulk_create(
                [ServiceEmployee(employee=employee, service=s) for s in servicios]
            )

        return Response({'detail': 'Servicios asignados correctamente'})

    @action(detail=True, methods=['get'])
    def services(self, request, pk=None):
        employee = self.get_object()
        employee_services = ServiceEmployee.objects.filter(employee=employee).select_related('service')
        serializer = EmployeeServiceSerializer(employee_services, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def schedule(self, request, pk=None):
        employee = self.get_object()
        schedules = WorkSchedule.objects.filter(employee=employee)
        serializer = WorkScheduleSerializer(schedules, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def set_schedule(self, request, pk=None):
        employee = self.get_object()
        schedules_data = request.data.get('schedules', [])
        
        # Limpiar horarios existentes
        WorkSchedule.objects.filter(employee=employee).delete()
        
        # Crear nuevos horarios
        for schedule_data in schedules_data:
            schedule_data['employee'] = employee.id
            serializer = WorkScheduleSerializer(data=schedule_data)
            if serializer.is_valid():
                serializer.save()
                
        return Response({'detail': 'Horarios actualizados correctamente'})

    @action(detail=True, methods=['get'])
    def stats(self, request, pk=None):
        employee = self.get_object()
        from apps.appointments_api.models import Appointment
        from apps.pos_api.models import Sale
        from django.utils import timezone
        from datetime import timedelta
        
        # Estadísticas del último mes
        last_month = timezone.now() - timedelta(days=30)
        tenant = getattr(self.request, 'tenant', self.request.user.tenant)
        
        appointments_count = Appointment.objects.filter(
            tenant=tenant,
            stylist=employee.user,
            date_time__gte=last_month
        ).count()
        
        sales_count = Sale.objects.filter(
            tenant=tenant,
            user=employee.user,
            date_time__gte=last_month
        ).count()
        
        return Response({
            'appointments_last_month': appointments_count,
            'sales_last_month': sales_count,
            'services_count': ServiceEmployee.objects.filter(employee=employee).count()
        })
    
    @action(detail=True, methods=['get', 'put'], url_path='payroll_config')
    def payroll_config(self, request, pk=None):
        employee = self.get_object()

        if request.method == 'GET':
            return Response({
                'payment_type': employee.payment_type or 'commission',
                'fixed_salary': float(employee.fixed_salary) if employee.fixed_salary else 0.0,
                'commission_rate': float(employee.commission_rate) if employee.commission_rate else 0.0,
            })

        elif request.method == 'PUT':
            from apps.auth_api.role_utils import get_effective_role_api
            user_role = get_effective_role_api(request.user, tenant=getattr(request, 'tenant', None))
            if user_role != 'CLIENT_ADMIN' and not request.user.is_superuser:
                return Response({'error': 'Solo administradores pueden modificar compensación'}, status=403)

            import logging
            from decimal import Decimal, InvalidOperation
            _log = logging.getLogger('employees_api.payroll_config')
            _log.debug('[PAYROLL_CONFIG] PUT employee=%s keys=%s', pk, list(request.data.keys()))

            payment_type = request.data.get('payment_type')
            if payment_type and payment_type not in ['fixed', 'commission', 'mixed']:
                return Response({'error': 'payment_type inválido'}, status=400)

            raw_fixed = request.data.get('fixed_salary')
            raw_commission = request.data.get('commission_rate')

            new_fixed_salary = None
            new_commission_rate = None

            if raw_fixed is not None:
                try:
                    new_fixed_salary = Decimal(str(raw_fixed))
                except (InvalidOperation, ValueError):
                    return Response({'error': 'fixed_salary inválido'}, status=400)
                if new_fixed_salary < 0:
                    return Response({'error': 'fixed_salary no puede ser negativo'}, status=400)

            if raw_commission is not None:
                try:
                    new_commission_rate = Decimal(str(raw_commission))
                except (InvalidOperation, ValueError):
                    return Response({'error': 'commission_rate inválido'}, status=400)
                if new_commission_rate < 0 or new_commission_rate > 100:
                    return Response({'error': 'commission_rate debe estar entre 0 y 100'}, status=400)

            old_payment_type = employee.payment_type
            old_fixed_salary = Decimal(str(employee.fixed_salary)) if employee.fixed_salary is not None else Decimal('0.00')
            old_commission_rate = Decimal(str(employee.commission_rate)) if employee.commission_rate is not None else Decimal('40.00')

            if payment_type:
                employee.payment_type = payment_type
            if new_fixed_salary is not None:
                employee.fixed_salary = new_fixed_salary
            if new_commission_rate is not None:
                employee.commission_rate = new_commission_rate

            with transaction.atomic():
                employee.save()
                _log.info('[PAYROLL_CONFIG] saved employee=%s fixed_salary=%s payment_type=%s commission_rate=%s',
                          employee.id, employee.fixed_salary, employee.payment_type, employee.commission_rate)

                from apps.employees_api.earnings_models import PayrollPeriod
                open_periods = PayrollPeriod.objects.filter(
                    employee=employee,
                    status='open',
                )
                updated = open_periods.update(
                    fixed_salary_snapshot=employee.fixed_salary,
                    commission_rate_snapshot=employee.commission_rate,
                    payment_type_snapshot=employee.payment_type,
                )
                if updated:
                    _log.info('[PAYROLL_CONFIG] sync snapshots on %s open periods: fixed_salary=%s commission_rate=%s payment_type=%s',
                              updated, employee.fixed_salary, employee.commission_rate, employee.payment_type)

                new_fixed_decimal = Decimal(str(employee.fixed_salary)) if employee.fixed_salary is not None else Decimal('0.00')
                new_commission_decimal = Decimal(str(employee.commission_rate)) if employee.commission_rate is not None else Decimal('40.00')

                if (old_payment_type != employee.payment_type or
                    old_fixed_salary != new_fixed_decimal or
                    old_commission_rate != new_commission_decimal):

                    from apps.employees_api.compensation_models import EmployeeCompensationHistory
                    from django.utils import timezone

                    EmployeeCompensationHistory.objects.create(
                        employee=employee,
                        payment_type=employee.payment_type,
                        fixed_salary=new_fixed_decimal,
                        commission_rate=new_commission_decimal,
                        effective_date=timezone.now().date(),
                        created_by=request.user,
                        change_reason='Actualización manual de configuración de nómina'
                    )
                    _log.info('[PAYROLL_CONFIG] compensation history created for employee=%s', employee.id)

            return Response({
                'message': 'Configuración actualizada',
                'payment_type': employee.payment_type,
                'fixed_salary': float(employee.fixed_salary) if employee.fixed_salary else 0.0,
                'commission_rate': float(employee.commission_rate) if employee.commission_rate else 0.0,
            })
    
    @action(detail=True, methods=['get'], url_path='payment_history')
    def payment_history(self, request, pk=None):
        """Historial de pagos del empleado"""
        employee = self.get_object()
        from apps.employees_api.earnings_models import PayrollPeriod
        
        periods = PayrollPeriod.objects.filter(
            employee=employee,
            status='paid'
        ).order_by('-period_start')
        
        history = [{
            'id': p.id,
            'period_display': p.period_display,
            'period_start': p.period_start.isoformat(),
            'period_end': p.period_end.isoformat(),
            'gross_amount': float(p.gross_amount),
            'deductions_total': float(p.deductions_total),
            'net_amount': float(p.net_amount),
            'paid_at': p.paid_at.isoformat() if p.paid_at else None,
            'payment_method': p.payment_method,
            'payment_reference': p.payment_reference
        } for p in periods]
        
        return Response({'payments': history, 'count': len(history)})
    
    @action(detail=True, methods=['get'], url_path='payment_stats')
    def payment_stats(self, request, pk=None):
        """Estadísticas de pagos del empleado"""
        employee = self.get_object()
        from apps.employees_api.earnings_models import PayrollPeriod
        from django.db.models import Sum, Avg, Count
        from django.utils import timezone
        from datetime import timedelta
        
        # Todos los pagos
        all_payments = PayrollPeriod.objects.filter(employee=employee, status='paid')
        
        # Últimos 6 meses
        six_months_ago = timezone.now().date() - timedelta(days=180)
        recent_payments = all_payments.filter(period_start__gte=six_months_ago)
        
        stats = {
            'total_payments': all_payments.count(),
            'total_earned': float(all_payments.aggregate(total=Sum('net_amount'))['total'] or 0),
            'average_payment': float(all_payments.aggregate(avg=Avg('net_amount'))['avg'] or 0),
            'last_6_months': {
                'count': recent_payments.count(),
                'total': float(recent_payments.aggregate(total=Sum('net_amount'))['total'] or 0),
                'average': float(recent_payments.aggregate(avg=Avg('net_amount'))['avg'] or 0)
            },
            'last_payment': None
        }
        
        last_payment = all_payments.order_by('-paid_at').first()
        if last_payment:
            stats['last_payment'] = {
                'date': last_payment.paid_at.isoformat() if last_payment.paid_at else None,
                'amount': float(last_payment.net_amount),
                'period': last_payment.period_display
            }
        
        return Response(stats)
    
    @action(detail=True, methods=['get', 'post'], url_path='loans')
    def loans(self, request, pk=None):
        """Gestionar préstamos del empleado"""
        employee = self.get_object()
        from apps.employees_api.models import Loan
        from apps.employees_api.earnings_models import PayrollPeriod, PayrollDeduction
        import uuid
        
        if request.method == 'GET':
            active_loans = Loan.objects.filter(employee=employee).order_by('-created_at')
            
            type_labels = {
                'advance': 'Anticipo de Sueldo',
                'personal_loan': 'Préstamo Personal',
                'emergency': 'Préstamo de Emergencia'
            }
            
            current_period = PayrollPeriod.objects.filter(
                employee=employee,
                status='open'
            ).order_by('period_start').first()
            
            loans_data = []
            for loan in active_loans:
                installment_amount = (loan.amount / max(loan.installments, 1)).quantize(Decimal('0.01'))
                
                loans_data.append({
                    'id': loan.id,
                    'request_date': loan.created_at.isoformat(),
                    'loan_type': loan.loan_type,
                    'type_display': type_labels.get(loan.loan_type, 'Préstamo Personal'),
                    'installments': loan.installments,
                    'monthly_payment': float(installment_amount),
                    'remaining_balance': float(loan.remaining_balance),
                    'status': loan.status,
                    'reason': loan.description or 'Sin motivo',
                    'amount': float(loan.amount),
                    'period': current_period.period_display if current_period else 'N/A',
                    'period_status': current_period.status if current_period else 'open',
                })
            
            return Response({'loans': loans_data, 'count': len(loans_data)})
        
        elif request.method == 'POST':
            amount = request.data.get('amount')
            description = request.data.get('description') or request.data.get('reason', '')
            loan_type = request.data.get('type') or request.data.get('loan_type', 'personal_loan')
            installments = request.data.get('installments', 1)
            
            # Normalizar tipo
            type_mapping = {
                'personal_loan': 'personal_loan',
                'loan': 'personal_loan',
                'emergency': 'emergency',
                'emergency_loan': 'emergency',
                'advance': 'advance'
            }
            loan_type = type_mapping.get(loan_type, 'personal_loan')
            
            if not amount:
                return Response({'error': 'amount es requerido'}, status=400)
            try:
                total_amount = Decimal(str(amount)).quantize(Decimal('0.01'))
                installments = int(installments)
            except Exception:
                return Response({'error': 'amount/installments inválidos'}, status=400)
 
            if total_amount <= 0:
                return Response({'error': 'amount debe ser mayor que cero'}, status=400)
            if installments <= 0:
                return Response({'error': 'installments debe ser mayor que cero'}, status=400)
            
            # Verificar duplicado reciente
            recent_threshold = timezone.now() - timedelta(seconds=5)
            existing = Loan.objects.filter(
                employee=employee,
                loan_type=loan_type,
                amount=total_amount,
                created_at__gte=recent_threshold
            ).exists()
 
            if existing:
                return Response({'error': 'Préstamo duplicado detectado'}, status=400)
 
            with transaction.atomic():
                loan = Loan.objects.create(
                    employee=employee,
                    loan_type=loan_type,
                    amount=total_amount,
                    installments=installments,
                    remaining_balance=total_amount,
                    status='active',
                    description=description
                )
                
                # Recalcular el periodo actual abierto del empleado para que se inserte la primera cuota inmediatamente si es posible
                current_period = PayrollPeriod.objects.filter(
                    employee=employee,
                    status='open'
                ).order_by('period_start').first()
                
                if current_period:
                    current_period.calculate_amounts()
                    current_period.save()
            
            installment_amount = (total_amount / installments).quantize(Decimal('0.01'))
            return Response({
                'message': 'Préstamo creado exitosamente',
                'loan': {
                    'id': loan.id,
                    'type': loan_type,
                    'amount': float(total_amount),
                    'installments': installments,
                    'installment_amount': float(installment_amount),
                    'description': description,
                    'period': current_period.period_display if current_period else 'N/A'
                }
            }, status=201)
    
    @action(detail=True, methods=['get'], url_path='loans_summary')
    def loans_summary(self, request, pk=None):
        """Resumen de préstamos del empleado"""
        employee = self.get_object()
        from apps.employees_api.models import Loan
        from django.db.models import Sum
        
        # Préstamos activos (status='active')
        active_loans = Loan.objects.filter(
            employee=employee,
            status='active'
        )
        
        # Préstamos pagados (status='paid')
        paid_loans = Loan.objects.filter(
            employee=employee,
            status='paid'
        )
        
        all_loans = Loan.objects.filter(
            employee=employee
        ).order_by('created_at')
        
        # Calcular el balance restante total
        remaining_balance = active_loans.aggregate(total=Sum('remaining_balance'))['total'] or Decimal('0.00')
        total_amount = all_loans.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        paid_amount = paid_loans.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
        
        # Próxima cuota a descontar: suma de las cuotas quincenales de todos los préstamos activos
        next_deduction = Decimal('0.00')
        for loan in active_loans:
            installment = (loan.amount / max(loan.installments, 1)).quantize(Decimal('0.01'))
            next_deduction += min(installment, loan.remaining_balance)
            
        summary = {
            'pending': {
                'count': active_loans.count(),
                'total': float(remaining_balance)
            },
            'paid': {
                'count': paid_loans.count(),
                'total': float(paid_amount)
            },
            'total_loans': all_loans.count(),
            'total_amount': float(total_amount),
            'remaining_balance': float(remaining_balance),
            'next_deduction': float(next_deduction),
            'active_loans': active_loans.count(),
        }
        
        return Response(summary)

class WorkScheduleViewSet(viewsets.ModelViewSet):
    queryset = WorkSchedule.objects.select_related('employee', 'employee__user', 'employee__tenant').all()
    serializer_class = WorkScheduleSerializer
    pagination_class = None
    permission_classes = [TenantPermissionByAction]
    permission_map = {
        'list': 'employees_api.view_employee',
        'retrieve': 'employees_api.view_employee',
        'create': 'employees_api.change_employee',
        'update': 'employees_api.change_employee',
        'partial_update': 'employees_api.change_employee',
        'destroy': 'employees_api.delete_employee',
    }

    def get_queryset(self):
        user = self.request.user

        if user.is_superuser:
            tenant = getattr(self.request, 'tenant', None)
            if tenant:
                queryset = WorkSchedule.objects.filter(employee__tenant=tenant)
            else:
                queryset = WorkSchedule.objects.all()
        elif not hasattr(self.request, 'tenant') or not self.request.tenant:
            return WorkSchedule.objects.none()
        else:
            is_tenant_admin = UserRole.objects.filter(
                user=user,
                tenant=self.request.tenant,
                role__name__in=['Client-Admin', 'Manager']
            ).exists()

            if is_tenant_admin:
                queryset = WorkSchedule.objects.filter(employee__tenant=self.request.tenant)
            else:
                queryset = WorkSchedule.objects.filter(
                    employee__tenant=self.request.tenant,
                    employee__user=user
                )

        branch_id = self.request.query_params.get('branch_id') or self.request.query_params.get('branch')
        
        tenant = getattr(self.request, 'tenant', None)
        if tenant and not tenant.has_feature('multi_location'):
            branch_id = None
        
        # Enforce branch restriction for non-admins
        if user and getattr(user, 'is_authenticated', False) and not user.is_superuser:
            from apps.auth_api.role_utils import get_effective_role_api
            user_role = get_effective_role_api(user, tenant=self.request.tenant)
            if user_role != 'CLIENT_ADMIN' and hasattr(user, 'employee_profile') and user.employee_profile:
                if user.employee_profile.branch_id:
                    branch_id = user.employee_profile.branch_id

        if branch_id:
            from django.db.models import Q
            queryset = queryset.filter(Q(employee__branch_id=branch_id) | Q(employee__branch__isnull=True))

        return queryset

    def perform_create(self, serializer):
        user = self.request.user
        tenant = getattr(self.request, 'tenant', None)

        if not tenant and not user.is_superuser:
            raise ValidationError("Usuario sin tenant asignado")

        # Permitir a admins/manager asignar horario al empleado enviado en payload,
        # siempre dentro del mismo tenant. Si no viene, usar su propio empleado.
        employee = serializer.validated_data.get('employee')
        if employee:
            if not user.is_superuser and employee.tenant_id != tenant.id:
                raise ValidationError("No puede asignar horarios a empleados de otro tenant")
            serializer.save()
            return

        try:
            employee = Employee.objects.get(user=user)
        except Employee.DoesNotExist:
            raise ValidationError("Debe enviar employee para crear el horario")

        if not user.is_superuser and employee.tenant_id != tenant.id:
            raise ValidationError("Empleado fuera del tenant")

        serializer.save(employee=employee)


class AttendanceRecordViewSet(viewsets.ModelViewSet):
    queryset = AttendanceRecord.objects.select_related('employee', 'employee__user', 'employee__tenant').all()
    serializer_class = AttendanceRecordSerializer
    permission_classes = [TenantPermissionByAction]
    permission_map = {
        'list': 'employees_api.view_employee',
        'retrieve': 'employees_api.view_employee',
        'create': 'employees_api.change_employee',
        'update': 'employees_api.change_employee',
        'partial_update': 'employees_api.change_employee',
        'destroy': 'employees_api.delete_employee',
        'check_in': 'employees_api.change_employee',
        'check_out': 'employees_api.change_employee',
        'justify_attendance': 'employees_api.change_employee',
    }

    def get_queryset(self):
        user = self.request.user

        if user.is_superuser:
            tenant = getattr(self.request, 'tenant', None)
            if tenant:
                queryset = self.queryset.filter(employee__tenant=tenant)
            else:
                queryset = self.queryset
        elif not hasattr(self.request, 'tenant') or not self.request.tenant:
            return AttendanceRecord.objects.none()
        else:
            is_tenant_admin = UserRole.objects.filter(
                user=user,
                tenant=self.request.tenant,
                role__name__in=['Client-Admin', 'Manager']
            ).exists()

            if is_tenant_admin:
                queryset = self.queryset.filter(employee__tenant=self.request.tenant)
            else:
                queryset = self.queryset.filter(
                    employee__tenant=self.request.tenant,
                    employee__user=user
                )

        branch_id = self.request.query_params.get('branch_id') or self.request.query_params.get('branch')
        
        # Enforce branch restriction for non-admins
        if user and getattr(user, 'is_authenticated', False) and not user.is_superuser:
            from apps.auth_api.role_utils import get_effective_role_api
            user_role = get_effective_role_api(user, tenant=self.request.tenant)
            if user_role != 'CLIENT_ADMIN' and hasattr(user, 'employee_profile') and user.employee_profile:
                if user.employee_profile.branch_id:
                    branch_id = user.employee_profile.branch_id

        if branch_id:
            queryset = queryset.filter(employee__branch_id=branch_id)

        return queryset

    def perform_create(self, serializer):
        user = self.request.user
        tenant = getattr(self.request, 'tenant', None)

        if not tenant and not user.is_superuser:
            raise ValidationError("Usuario sin tenant asignado")

        employee = serializer.validated_data.get('employee')
        if employee:
            if not user.is_superuser and employee.tenant_id != tenant.id:
                raise ValidationError("No puede registrar asistencia para otro tenant")
            serializer.save()
            return

        try:
            employee = Employee.objects.get(user=user)
        except Employee.DoesNotExist:
            raise ValidationError("Debe enviar employee para registrar asistencia")

        if not user.is_superuser and employee.tenant_id != tenant.id:
            raise ValidationError("Empleado fuera del tenant")

        serializer.save(employee=employee)

    @action(detail=False, methods=['post'])
    def check_in(self, request):
        employee = self._resolve_employee(request)
        today = timezone.localdate()
        now = timezone.now()

        days_mapping = {
            0: 'monday',
            1: 'tuesday',
            2: 'wednesday',
            3: 'thursday',
            4: 'friday',
            5: 'saturday',
            6: 'sunday'
        }
        day_name = days_mapping[today.weekday()]
        
        status_value = 'present'
        notes_value = ''
        
        # Buscar horario de hoy
        schedule = WorkSchedule.objects.filter(employee=employee, day_of_week=day_name).first()
        if schedule:
            grace_minutes = 15
            if employee.branch_id:
                from apps.settings_api.models import Setting
                tenant = getattr(request, 'tenant', request.user.tenant)
                setting = Setting.objects.filter(branch_id=employee.branch_id, branch__tenant=tenant).first()
                if setting and isinstance(setting.preferences, dict):
                    grace_minutes = setting.preferences.get('attendance_grace_period_minutes', 15)
            
            local_now = timezone.localtime(now)
            current_time = local_now.time()
            
            current_minutes = current_time.hour * 60 + current_time.minute
            start_minutes = schedule.start_time.hour * 60 + schedule.start_time.minute
            
            if current_minutes > (start_minutes + grace_minutes):
                status_value = 'late'
                minutes_late = current_minutes - start_minutes
                notes_value = f"Retraso de {minutes_late} minutos"
            else:
                status_value = 'present'
        else:
            notes_value = "Check-in fuera de horario laboral"

        record, created = AttendanceRecord.objects.get_or_create(
            employee=employee,
            work_date=today,
            defaults={
                'check_in_at': now,
                'status': status_value,
                'is_justified': False,
                'notes': notes_value
            }
        )

        if not created and record.check_in_at:
            serializer = self.get_serializer(record)
            return Response(
                {
                    'detail': 'Ya existe check-in para hoy',
                    'record': serializer.data
                },
                status=status.HTTP_200_OK
            )

        if not record.check_in_at:
            record.check_in_at = now
            record.status = status_value
            if notes_value:
                record.notes = notes_value
            record.save(update_fields=['check_in_at', 'status', 'notes', 'updated_at'])

        serializer = self.get_serializer(record)
        return Response(serializer.data, status=status.HTTP_200_OK if not created else status.HTTP_201_CREATED)

    @action(detail=False, methods=['post'])
    def check_out(self, request):
        employee = self._resolve_employee(request)
        today = timezone.localdate()
        now = timezone.now()

        try:
            record = AttendanceRecord.objects.get(employee=employee, work_date=today)
        except AttendanceRecord.DoesNotExist:
            return Response({'detail': 'No existe check-in para hoy'}, status=status.HTTP_400_BAD_REQUEST)

        if not record.check_in_at:
            return Response({'detail': 'No existe check-in para hoy'}, status=status.HTTP_400_BAD_REQUEST)

        if record.check_out_at:
            serializer = self.get_serializer(record)
            return Response(
                {
                    'detail': 'Ya existe check-out para hoy',
                    'record': serializer.data
                },
                status=status.HTTP_200_OK
            )

        record.check_out_at = now
        
        # Calcular duración del turno
        delta = record.check_out_at - record.check_in_at
        total_seconds = int(delta.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        
        duration_str = f"Trabajado: {hours}h {minutes}m"
        if record.notes:
            record.notes = f"{record.notes} | {duration_str}"
        else:
            record.notes = duration_str

        record.save(update_fields=['check_out_at', 'notes', 'updated_at'])
        serializer = self.get_serializer(record)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'], url_path='justify')
    def justify_attendance(self, request, pk=None):
        record = self.get_object()
        user = request.user
        
        if not user.is_superuser:
            is_admin_or_manager = UserRole.objects.filter(
                user=user,
                tenant=getattr(request, 'tenant', user.tenant if hasattr(user, 'tenant') else None),
                role__name__in=['Client-Admin', 'Manager']
            ).exists()
            if not is_admin_or_manager:
                return Response({'detail': 'No tiene permisos para justificar asistencias'}, status=status.HTTP_403_FORBIDDEN)

        reason = request.data.get('reason', '')
        if not reason:
            return Response({'error': 'Debe proporcionar un motivo de justificación'}, status=status.HTTP_400_BAD_REQUEST)

        record.is_justified = True
        record.justification_reason = reason
        record.justified_by = user
        record.save(update_fields=['is_justified', 'justification_reason', 'justified_by', 'updated_at'])

        serializer = self.get_serializer(record)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def _resolve_employee(self, request):
        tenant = getattr(request, 'tenant', None)
        user = request.user
        employee_id = request.data.get('employee')

        if employee_id:
            try:
                if user.is_superuser:
                    employee = Employee.objects.get(pk=employee_id)
                else:
                    employee = Employee.objects.get(pk=employee_id, tenant=tenant)
            except Employee.DoesNotExist:
                raise ValidationError("Empleado no encontrado")
            if not user.is_superuser and employee.tenant_id != getattr(tenant, 'id', None):
                raise ValidationError("No puede registrar asistencia para otro tenant")
            
            # Validación de seguridad: si no es su propio empleado, debe ser admin/manager
            if employee.user_id != user.id and not user.is_superuser:
                from rest_framework.exceptions import PermissionDenied
                is_admin_or_manager = UserRole.objects.filter(
                    user=user,
                    tenant=tenant,
                    role__name__in=['Client-Admin', 'Manager']
                ).exists()
                if not is_admin_or_manager:
                    raise PermissionDenied("No tienes permisos para registrar asistencia de otros colaboradores")
            return employee

        try:
            employee = Employee.objects.get(user=user)
        except Employee.DoesNotExist:
            raise ValidationError("Debe enviar employee")

        if not user.is_superuser and employee.tenant_id != getattr(tenant, 'id', None):
            raise ValidationError("Empleado fuera del tenant")
        return employee
