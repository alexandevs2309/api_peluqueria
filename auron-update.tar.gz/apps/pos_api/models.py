from django.db import models 
from django.utils import timezone
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from decimal import Decimal
from apps.clients_api.models import Client
from apps.services_api.models import Service
from apps.inventory_api.models import Product
from apps.roles_api.models import Role
from django.utils.crypto import get_random_string


User = get_user_model()

class Sale(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('void', 'Void'),
        ('refunded', 'Refunded'),
    ]
    
    # ✅ CAMPO TENANT DIRECTO para filtrado eficiente
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='sales', null=True)
    branch = models.ForeignKey('settings_api.Branch', null=True, blank=True, on_delete=models.SET_NULL, related_name='branch_sales')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sales', null=True, blank=True)
    employee = models.ForeignKey('employees_api.Employee', on_delete=models.SET_NULL, null=True, blank=True, related_name='sales')
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True, blank=True, related_name='sales', db_index=True)
    period = models.ForeignKey('employees_api.PayrollPeriod', on_delete=models.SET_NULL, null=True, blank=True, related_name='sales', db_index=True)
    cash_register = models.ForeignKey('CashRegister', on_delete=models.SET_NULL, null=True, blank=True, related_name='sales', db_index=True)
    date_time = models.DateTimeField(default=timezone.now)
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    discount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    discount_reason = models.TextField(blank=True, default='', help_text='Motivo del descuento (requerido para descuentos > umbral)')
    paid = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    payment_method = models.CharField(max_length=50, choices=[
        ('cash', 'Cash'),
        ('card', 'Card'),
        ('transfer', 'Transfer'),
        ('mixed', 'Mixed'),
        ('other', 'Other')
    ], default='cash')
    closed = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='confirmed')

    # ── Reembolsos parciales ───────────────────────────────────────────────
    # Suma ya reembolsada. Permite reembolsos parciales idempotentes y
    # proportionally audited. Las ventas históricas inician en 0.00.
    amount_refunded = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    
    # Snapshot de comisión (FASE 1 - Payroll Determinístico)
    commission_rate_snapshot = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text='Tasa de comisión vigente al momento de la venta'
    )
    commission_amount_snapshot = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        help_text='Monto de comisión calculado al momento de la venta'
    )
    
    # Loyalty
    points_earned = models.PositiveIntegerField(default=0, help_text='Puntos de lealtad ganados en esta venta')
    points_redeemed = models.PositiveIntegerField(default=0, help_text='Puntos de lealtad canjeados en esta venta')

    # Promoción aplicada (FK + snapshot del nombre)
    promotion = models.ForeignKey('Promotion', null=True, blank=True, on_delete=models.SET_NULL, related_name='sales')
    promotion_name = models.CharField(max_length=255, blank=True, default='', help_text='Nombre de la promoción al momento de la venta')

    # Cupón aplicado (FK + código)
    coupon = models.ForeignKey('Coupon', null=True, blank=True, on_delete=models.SET_NULL, related_name='sales')
    coupon_code = models.CharField(max_length=50, blank=True, default='', help_text='Código del cupón al momento de la venta')

    # Comprobante Fiscal (NCF - República Dominicana)
    ncf = models.CharField(max_length=11, blank=True, null=True, db_index=True, help_text='Número de Comprobante Fiscal generado')
    ncf_type = models.CharField(max_length=2, blank=True, null=True, help_text='Tipo de comprobante (B01, B02, etc.)')
    rnc = models.CharField(max_length=20, blank=True, null=True, help_text='RNC o Cédula del cliente facturado')
    company_name = models.CharField(max_length=255, blank=True, null=True, help_text='Razón Social del cliente facturado')

    # Campos de auditoría
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='sales_created')
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='sales_updated')
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        ordering = ['-date_time']
        verbose_name = 'Sale'
        verbose_name_plural = 'Sales'
        indexes = [
            models.Index(fields=['tenant']),
            models.Index(fields=['date_time', 'user']),
            models.Index(fields=['date_time', 'employee']),
            models.Index(fields=['status']),
            models.Index(fields=['tenant', '-date_time']),
        ]
        permissions = [
            ('refund_sale', 'Can refund sales'),
            ('view_financial_reports', 'Can view financial reports'),
        ]
    
    def save(self, *args, **kwargs):
        from django.core.exceptions import ValidationError
        
        # ✅ AUTO-ASIGNAR TENANT en creación
        if self.pk is None:
            if not self.tenant_id and self.user:
                self.tenant = self.user.tenant
            elif not self.tenant_id and self.employee:
                self.tenant = self.employee.tenant
            
            # Nueva venta: establecer status=confirmed por defecto
            if not self.status:
                self.status = 'confirmed'

            # Auto-poblar promotion_name si se asignó una promoción
            if self.promotion_id and not self.promotion_name:
                self.promotion_name = self.promotion.name

            # Auto-poblar coupon_code si se asignó un cupón
            if self.coupon_id and not self.coupon_code:
                self.coupon_code = self.coupon.code
            
            # NUEVO: Capturar snapshots de comisión al crear
            if self.employee:
                from apps.pos_api.services import SaleCommissionService
                from decimal import Decimal
                rate, amount = SaleCommissionService.calculate_commission_snapshot(
                    employee=self.employee,
                    sale_total=self.total,
                    sale_date=self.date_time.date() if self.date_time else None
                )
                self.commission_rate_snapshot = rate
                self.commission_amount_snapshot = amount
            
            return super().save(*args, **kwargs)
        
        # FIX POS-004: Para updates, siempre cargar el estado anterior
        try:
            old_instance = Sale.objects.get(pk=self.pk)
        except Sale.DoesNotExist:
            return super().save(*args, **kwargs)
        
        # FIX POS-004: Whitelist para update_fields — bloquear campos financieros en ventas confirmadas
        update_fields = kwargs.get('update_fields')
        if update_fields and old_instance.status != 'draft':
            # Campos que NUNCA pueden modificarse via update_fields en ventas no-draft
            IMMUTABLE_FIELDS = {
                'total', 'discount', 'paid', 'payment_method',
                'employee', 'employee_id', 'tenant', 'tenant_id',
                'period', 'period_id',
                'commission_rate_snapshot', 'commission_amount_snapshot',
                'client', 'client_id', 'branch', 'branch_id',
            }
            blocked = IMMUTABLE_FIELDS & set(update_fields)
            if blocked:
                raise ValidationError(
                    f"No se pueden modificar campos protegidos en una venta "
                    f"con status '{old_instance.status}': {', '.join(sorted(blocked))}"
                )
            return super().save(*args, **kwargs)
        
        # PROTECCIÓN CRÍTICA: Si snapshot existe, period es INMUTABLE
        if old_instance.commission_amount_snapshot is not None:
            if old_instance.period_id != self.period_id:
                raise ValidationError(
                    "No se puede cambiar el período de una venta con snapshot de comisión. "
                    "La comisión ya fue calculada y asignada."
                )
        
        # VALIDACIÓN: Evitar reasignación de period si está aprobado/pagado
        if old_instance.period_id != self.period_id and old_instance.period_id is not None:
            try:
                from apps.employees_api.earnings_models import PayrollPeriod
                old_period = PayrollPeriod.objects.get(pk=old_instance.period_id)
                if old_period.status in ['approved', 'paid']:
                    raise ValidationError(
                        f"No se puede reasignar la venta a otro período. "
                        f"El período actual está {old_period.get_status_display()}."
                    )
            except PayrollPeriod.DoesNotExist:
                pass
        
        # Permitir modificación solo si status=draft
        if old_instance.status != 'draft':
            # Permitir cambios SOLO en el campo status (para transiciones void/refunded)
            if old_instance.status != self.status:
                # Validar transiciones permitidas
                allowed_transitions = {
                    'confirmed': ['void', 'refunded'],
                    'void': [],
                    'refunded': [],
                }
                if self.status not in allowed_transitions.get(old_instance.status, []):
                    raise ValidationError(
                        f"No se puede cambiar status de '{old_instance.status}' a '{self.status}'"
                    )
                # Solo permitir cambio de status, nada más
                self.total = old_instance.total
                self.discount = old_instance.discount
                self.paid = old_instance.paid
                self.payment_method = old_instance.payment_method
                self.client_id = old_instance.client_id
                self.employee_id = old_instance.employee_id
                self.period_id = old_instance.period_id
                return super().save(*args, **kwargs)
            
            # Intentando modificar otros campos
            raise ValidationError(
                f"No se puede modificar una venta con status '{old_instance.status}'. "
                "Solo se permiten modificaciones en ventas con status 'draft'."
            )
        
        # Status es draft: permitir modificación
        return super().save(*args, **kwargs)
    
    def delete(self, *args, **kwargs):
        from django.core.exceptions import ValidationError
        
        if self.status != 'draft':
            raise ValidationError(
                f"No se puede eliminar una venta con status '{self.status}'. "
                "Solo se permiten eliminaciones de ventas con status 'draft'."
            )
        return super().delete(*args, **kwargs)

    # ── Regla explícita y verificable de fuente de comisión ────────────────
    # Una venta NUNCA tiene comisión a nivel de venta y a nivel de línea a la
    # vez. Esta es la única fuente de verdad usada por la nómina, los reportes
    # y los reembolsos:
    #
    #   - Si existe ≥1 detalle con `commission_amount_snapshot` no nulo
    #     => fuente = LINE (detalle). El snapshot de venta se ignora.
    #   - En cualquier otro caso
    #     => fuente = SALE (histórico). Se respeta el snapshot de venta.
    #
    # Esta regla es determinista, idempotente y preserva las ventas
    # históricas sin recalcular ni un solo centavo.
    COMMISSION_SOURCE_NONE = 'none'
    COMMISSION_SOURCE_SALE = 'sale'
    COMMISSION_SOURCE_LINE = 'line'

    @property
    def commission_source(self):
        """Devuelve 'line', 'sale' o 'none' según la regla de precedencia."""
        if self.pk is None:
            return self.COMMISSION_SOURCE_NONE
        has_line = self.details.filter(
            commission_amount_snapshot__isnull=False
        ).exists()
        if has_line:
            return self.COMMISSION_SOURCE_LINE
        if self.commission_amount_snapshot is not None:
            return self.COMMISSION_SOURCE_SALE
        return self.COMMISSION_SOURCE_NONE

    @property
    def refundable_amount(self):
        """Monto que aún puede reembolsarse (protege contra sobre-reembolso)."""
        return (self.total or Decimal('0.00')) - (self.amount_refunded or Decimal('0.00'))

    @classmethod
    def write_commission_snapshots(cls, sale, rate, amount):
        """
        Escribe los snapshots de comisión a nivel de VENTA.

        Uso exclusivo del flujo de creación (SaleViewSet.perform_create) y de
        la simulación de datos históricos en pruebas. Usa un UPDATE directo
        para poder escribir los snapshots justo después de crear la venta,
        que es cuando el modelo los calcula provisionalmente y hay que
        ajustarlos a la fuente correcta (línea vs venta).

        No debilita la inmutabilidad: cualquier cambio posterior por API sigue
        bloqueado por el whitelist de IMMUTABLE_FIELDS en save().
        """
        cls.objects.filter(pk=sale.pk).update(
            commission_rate_snapshot=rate,
            commission_amount_snapshot=amount,
        )
        sale.commission_rate_snapshot = rate
        sale.commission_amount_snapshot = amount
        return sale

class SaleDetail(models.Model):
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name='details', db_index=True)
    
    # GenericForeignKey para referenciar Product o Service
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=False, validators=[], db_index=True)
    object_id = models.PositiveIntegerField(null=False, blank=False, db_index=True)
    content_object = GenericForeignKey('content_type', 'object_id')

    def clean(self):
        from django.core.exceptions import ValidationError
        if not self.content_type or not self.object_id:
            raise ValidationError('Both content type and object ID are required.')
        
        # Validación cross-tenant: el producto/servicio debe pertenecer al tenant de la venta
        if self.sale and self.sale.tenant_id:
            model_name = self.content_type.model if self.content_type else None
            
            if model_name == 'product':
                if not Product.objects.filter(id=self.object_id, tenant=self.sale.tenant).exists():
                    raise ValidationError({
                        'object_id': 'Product does not belong to the sale\'s tenant'
                    })
            elif model_name == 'service' and self.content_type.app_label == 'services_api':
                if not Service.objects.filter(id=self.object_id, tenant=self.sale.tenant).exists():
                    raise ValidationError({
                        'object_id': 'Service does not belong to the sale\'s tenant'
                    })

        # Validación cross-tenant del empleado responsable de la línea
        if self.employee_id and self.sale and self.sale.tenant_id:
            if self.employee.tenant_id != self.sale.tenant_id:
                raise ValidationError({
                    'employee': 'El empleado no pertenece al tenant de la venta'
                })
            # Un empleado solo puede quedar a cargo de servicios que realmente presta.
            model_name = self.content_type.model if self.content_type else None
            if model_name == 'service':
                from apps.services_api.models import ServiceEmployee
                employee_services = ServiceEmployee.objects.filter(employee=self.employee)
                # Solo se valida si el empleado tiene servicios asignados
                # explícitamente (misma semántica que el módulo de Citas).
                if employee_services.exists() and not employee_services.filter(service_id=self.object_id).exists():
                    raise ValidationError({
                        'employee': 'El empleado no presta este servicio'
                    })

    @property
    def line_total(self):
        """Total de la línea (cantidad × precio), base comisionable de la línea."""
        return (self.price or Decimal('0.00')) * (self.quantity or 0)

    def save(self, *args, **kwargs):
        from django.core.exceptions import ValidationError

        # Inmutabilidad: una vez creada la línea en una venta confirmada, ni el
        # empleado ni los snapshots de comisión pueden cambiar. Sin esto, un
        # reembolso podría dejar la nómina inconsistente con la venta.
        if self.pk is not None:
            try:
                old = SaleDetail.objects.get(pk=self.pk)
            except SaleDetail.DoesNotExist:
                return super().save(*args, **kwargs)
            if old.sale_id and Sale.objects.filter(pk=old.sale_id).exclude(status='draft').exists():
                protected = {
                    'employee': old.employee_id,
                    'employee_id': old.employee_id,
                    'commission_rate_snapshot': old.commission_rate_snapshot,
                    'commission_amount_snapshot': old.commission_amount_snapshot,
                    'commission_source': old.commission_source,
                }
                for field, expected in protected.items():
                    current = getattr(self, field, None)
                    if current != expected:
                        raise ValidationError(
                            f"No se puede modificar '{field}' en una línea de venta ya confirmada. "
                            "Los snapshots de comisión son inmutables."
                        )
        return super().save(*args, **kwargs)
    
    # Campos para almacenar datos al momento de la venta
    name = models.CharField(max_length=255)  # Nombre del producto/servicio
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=14, decimal_places=2)  # Precio al momento de la venta

    # ── Comisión por línea (FASE 2: comisiones por servicio) ──────────────
    # Una venta puede tener varios servicios realizados por distintos
    # barberos. El empleado es QUIEN performed ESA línea, no la venta entera.
    employee = models.ForeignKey(
        'employees_api.Employee',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='sale_details',
        help_text='Empleado/barbero responsable de esta línea',
    )
    # Snapshots inmutables: congelan la tasa y el monto al momento de cobrar,
    # para que un cambio posterior de configuración no altere la nómina.
    commission_rate_snapshot = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        help_text='Porcentaje de comisión vigente para esta línea al momento de la venta',
    )
    commission_amount_snapshot = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        null=True,
        blank=True,
        help_text='Monto de comisión de esta línea al momento de la venta',
    )
    # Trazabilidad de la regla de negocio que resolvió la tasa (auditoría).
    commission_source = models.CharField(
        max_length=32,
        blank=True,
        default='',
        help_text='Origen de la tasa: service|history|global|none',
    )

    class Meta:
        verbose_name = 'Sale Detail'
        verbose_name_plural = 'Sale Details'
        indexes = [
            models.Index(fields=['employee', 'commission_amount_snapshot']),
        ]

    def __str__(self): 
        try:
            return f"{self.content_type.model}:{self.object_id} - {self.name}"
        except AttributeError:
            return f"Unknown type:{self.object_id} - {self.name}"
    
    @property
    def item_type(self):
        """Helper para obtener el tipo de item (product/service)"""
        try:
            return self.content_type.model
        except AttributeError:
            return 'unknown'

class Payment(models.Model):
    sale = models.ForeignKey(Sale, on_delete=models.CASCADE, related_name='payments')
    method = models.CharField(max_length=50, choices=[
            ('cash', 'Cash'),
            ('card', 'Card'),
            ('transfer', 'Transfer'),
            ('mixed', 'Mixed'),
            ('other', 'Other'),
        ], default='cash')
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    provider_transaction_id = models.CharField(max_length=255, null=True, blank=True, help_text='Transaction ID from payment provider (Stripe, CardNET, etc.)')

class CashRegister(models.Model):
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='cash_registers', null=True)
    branch = models.ForeignKey('settings_api.Branch', null=True, blank=True, on_delete=models.SET_NULL, related_name='branch_cash_registers')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='cash_registers')
    opened_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    initial_cash = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    final_cash = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    is_open = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['-opened_at']
        indexes = [
            models.Index(fields=['user', 'opened_at']),
            models.Index(fields=['is_open']),
            models.Index(fields=['tenant', 'is_open'], name='pos_api_cas_tenant__911952_idx'),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['tenant', 'user', 'branch'],
                condition=models.Q(is_open=True),
                name='unique_open_register_per_user_branch',
            ),
            # Postgres trata los NULL como distintos en un unique index: un usuario sin
            # sucursal (branch IS NULL) quedaría sin protección, por eso esta constraint
            # adicional cubre el caso de cajas sin sucursal.
            models.UniqueConstraint(
                fields=['tenant', 'user'],
                condition=models.Q(is_open=True, branch__isnull=True),
                name='unique_open_register_per_user_no_branch',
            ),
        ]
    
    def save(self, *args, **kwargs):
        from decimal import Decimal
        if self.initial_cash is None:
            self.initial_cash = Decimal('0')
        if self.final_cash is None:
            self.final_cash = Decimal('0')
        super().save(*args, **kwargs)
    
    @property
    def sales_amount(self):
        """Calcular ventas en efectivo asociadas a esta sesión de caja"""
        # Usar annotation si está disponible (evita query extra)
        if hasattr(self, '_sales_amount_annotated'):
            return float(self._sales_amount_annotated)
        from django.db.models import Sum
        from .models import Payment
        if not self.opened_at:
            return 0.00
        
        sales_total = Payment.objects.filter(
            sale__cash_register=self,
            sale__tenant=self.tenant,
            method='cash',
            sale__status='confirmed'
        ).aggregate(total=Sum('amount'))['total'] or 0
        
        return float(sales_total)

    
    @property
    def display_amount(self):
        """Monto esperado en caja: inicial + ventas"""
        return float(self.initial_cash) + self.sales_amount

class CashCount(models.Model):
    """Arqueo de caja - conteo físico de dinero"""
    cash_register = models.ForeignKey(CashRegister, on_delete=models.CASCADE, related_name='cash_counts')
    denomination = models.DecimalField(max_digits=14, decimal_places=2)  # 1, 5, 10, 20, 50, 100
    count = models.IntegerField(default=0)  # cantidad de billetes/monedas
    total = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)  # denominacion * count
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Cash Count'
        verbose_name_plural = 'Cash Counts'
        unique_together = ['cash_register', 'denomination']

class Promotion(models.Model):
    """Sistema de promociones y descuentos"""
    PROMOTION_TYPES = [
        ('percentage', 'Percentage Discount'),
        ('fixed', 'Fixed Amount Discount'),
        ('buy_x_get_y', 'Buy X Get Y Free'),
        ('combo', 'Combo Offer')
    ]
    
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='promotions', null=True, blank=True)
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    type = models.CharField(max_length=20, choices=PROMOTION_TYPES)
    conditions = models.JSONField(default=dict)  # Condiciones específicas
    discount_value = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    min_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    max_uses = models.IntegerField(null=True, blank=True)  # Límite de usos
    current_uses = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = 'Promotion'
        verbose_name_plural = 'Promotions'
        ordering = ['-created_at']

class Coupon(models.Model):
    """Sistema de cupones promocionales manuales por código"""
    COUPON_TYPES = [
        ('percentage', 'Percentage Discount'),
        ('fixed', 'Fixed Amount Discount'),
    ]

    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='coupons', null=True, blank=True)
    code = models.CharField(max_length=50, db_index=True)
    description = models.TextField(blank=True, default='')
    type = models.CharField(max_length=20, choices=COUPON_TYPES, default='percentage')
    value = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    min_purchase_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0.00)
    
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    
    is_active = models.BooleanField(default=True)
    max_uses = models.PositiveIntegerField(null=True, blank=True, help_text='Límite de usos totales del cupón')
    current_uses = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Coupon'
        verbose_name_plural = 'Coupons'
        unique_together = ['tenant', 'code']
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.code} ({self.type}) - {self.tenant.name if self.tenant else 'Global'}"

class Receipt(models.Model):
    """Recibos generados"""
    sale = models.OneToOneField(Sale, on_delete=models.CASCADE, related_name='receipt')
    receipt_number = models.CharField(max_length=50, unique=True)
    template_used = models.CharField(max_length=100, default='default')
    generated_at = models.DateTimeField(auto_now_add=True)
    printed_count = models.IntegerField(default=0)
    last_printed = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = 'Receipt'
        verbose_name_plural = 'Receipts'
        ordering = ['-generated_at']

class PosConfiguration(models.Model):
    """Configuración del POS por tenant"""
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, null=True, blank=True, related_name='pos_configs')
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='pos_config')
    business_name = models.CharField(max_length=255, blank=True)
    address = models.TextField(blank=True)
    phone = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    rnc = models.CharField(max_length=30, blank=True, null=True, help_text='RNC/Cédula para comprobantes fiscales (RD)')
    currency = models.CharField(max_length=3, default='USD')
    currency_symbol = models.CharField(max_length=5, default='$')
    tax_rate = models.DecimalField(max_digits=5, decimal_places=4, default=0.0000)
    tax_included = models.BooleanField(default=False)
    receipt_template = models.TextField(default='default')
    receipt_footer = models.TextField(blank=True)
    auto_print_receipt = models.BooleanField(default=False)
    require_customer = models.BooleanField(default=False)
    allow_negative_stock = models.BooleanField(default=False)
    
    class Meta:
        verbose_name = 'POS Configuration'
        verbose_name_plural = 'POS Configurations'


class NCFSequence(models.Model):
    COMPROBANTE_TYPES = [
        ('01', 'Crédito Fiscal (B01)'),
        ('02', 'Consumidor Final (B02)'),
        ('14', 'Regímenes Especiales (B14)'),
        ('15', 'Gubernamentales (B15)'),
    ]

    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='ncf_sequences')
    type = models.CharField(max_length=2, choices=COMPROBANTE_TYPES, default='02')
    prefix = models.CharField(max_length=3, default='B')
    start_sequence = models.PositiveIntegerField(default=1)
    end_sequence = models.PositiveIntegerField()
    current_sequence = models.PositiveIntegerField(default=1)
    expiration_date = models.DateField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Secuencia NCF'
        verbose_name_plural = 'Secuencias NCF'
        unique_together = ['tenant', 'type', 'prefix', 'start_sequence']
        ordering = ['type', '-is_active', '-created_at']

    def __str__(self):
        return f"{self.prefix}{self.type} ({self.start_sequence} - {self.end_sequence}) - {self.tenant.name if self.tenant else ''}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.start_sequence > self.end_sequence:
            raise ValidationError("La secuencia inicial no puede ser mayor que la secuencia final.")
        if self.current_sequence < self.start_sequence or self.current_sequence > self.end_sequence + 1:
            raise ValidationError("La secuencia actual debe estar dentro del rango especificado.")

    def get_next_ncf(self):
        """Genera el NCF formateado de 11 caracteres (sin avanzar la secuencia)."""
        if not self.is_active:
            return None
        if self.current_sequence > self.end_sequence:
            return None
        from django.utils import timezone
        if self.expiration_date < timezone.localdate():
            return None
        
        return f"{self.prefix}{self.type}{self.current_sequence:08d}"
