
from django.utils.translation import gettext_lazy as _
from rest_framework import serializers

from apps.appointments_api.models import Appointment
from .models import Sale, SaleDetail, Payment, CashRegister, CashCount, Promotion, Receipt, PosConfiguration, NCFSequence, Coupon
from apps.inventory_api.models import Product, StockMovement



class SaleDetailSerializer(serializers.ModelSerializer):
    item_type = serializers.SerializerMethodField()
    # Field to specify the type of content ('service' or 'product')
    content_type = serializers.CharField(help_text="Type of item being sold (service/product)")
    # Alias de entrada: 'employee' y 'employee_id' significan lo mismo.
    employee_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    employee_name = serializers.SerializerMethodField()

    class Meta:
        model = SaleDetail
        fields = [
            'id', 'content_type', 'object_id', 'name', 'quantity', 'price', 'item_type',
            'employee', 'employee_id', 'employee_name',
            'commission_rate_snapshot', 'commission_amount_snapshot', 'commission_source',
        ]
        # Los snapshots SIEMPRE los calcula el backend; el cliente solo
        # declara QUIÉN hizo la línea.
        read_only_fields = [
            'commission_rate_snapshot', 'commission_amount_snapshot',
            'commission_source', 'employee_name',
        ]

    def get_employee_name(self, obj):
        emp_user = getattr(getattr(obj, 'employee', None), 'user', None)
        return getattr(emp_user, 'full_name', None) or getattr(emp_user, 'email', None)

    def get_fields(self):
        fields = super().get_fields()
        if 'employee' not in fields:
            # Se declara aquí para resolver el queryset con el tenant del
            # request sin capturarlo al importar el módulo.
            from apps.employees_api.models import Employee
            request = self.context.get('request')
            queryset = Employee.objects.none()
            if request is not None:
                tenant = getattr(request, 'tenant', None) or getattr(
                    getattr(request, 'user', None), 'tenant', None
                )
                if tenant:
                    queryset = Employee.objects.filter(tenant=tenant)
                elif getattr(getattr(request, 'user', None), 'is_superuser', False):
                    queryset = Employee.objects.all()
            fields['employee'] = serializers.PrimaryKeyRelatedField(
                queryset=queryset, required=False, allow_null=True
            )
        return fields

    def to_internal_value(self, data):
        # Acepta 'employee' o 'employee_id' con el mismo significado.
        if hasattr(data, 'get') and 'employee' not in data and data.get('employee_id'):
            try:
                data = data.copy()
                data['employee'] = data['employee_id']
            except Exception:
                pass
        return super().to_internal_value(data)

    def get_item_type(self, obj):
        return obj.content_type.model

class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ['id', 'method', 'amount', 'provider_transaction_id']

class SaleSerializer(serializers.ModelSerializer):
    details = SaleDetailSerializer(many=True)
    payments = PaymentSerializer(many=True)
    appointment = serializers.PrimaryKeyRelatedField(queryset=Appointment.objects.none(), required=False)
    client_name = serializers.CharField(source='client.full_name', read_only=True)
    employee_name = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    coupon = serializers.PrimaryKeyRelatedField(queryset=Coupon.objects.none(), required=False, allow_null=True)

    class Meta:
        model = Sale
        fields = [
            'id', 'branch', 'client', 'client_name', 'employee', 'employee_name', 'user', 'user_name', 
            'date_time', 'total', 'discount', 'paid', 'payment_method', 'closed', 'details', 
            'payments', 'appointment', 'points_earned', 'points_redeemed',
            'ncf', 'ncf_type', 'rnc', 'company_name',
            'promotion', 'promotion_name',
            'coupon', 'coupon_code',
        ]
        read_only_fields = [
            'user', 'user_name', 'date_time', 'closed', 'client_name', 'employee_name', 
            'points_earned', 'points_redeemed', 'ncf', 'promotion_name', 'coupon_code',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        request = self.context.get('request')
        if request:
            tenant = getattr(request, 'tenant', None) or getattr(getattr(request, 'user', None), 'tenant', None)
            if tenant:
                # Scoped: only appointments belonging to this tenant
                from django.db.models import Q
                self.fields['appointment'].queryset = Appointment.objects.filter(
                    Q(client__tenant=tenant) | Q(stylist__tenant=tenant)
                )
                from apps.clients_api.models import Client
                from apps.settings_api.models import Branch
                from apps.employees_api.models import Employee
                self.fields['client'].queryset = Client.objects.filter(tenant=tenant)
                self.fields['employee'].queryset = Employee.objects.filter(tenant=tenant)
                self.fields['branch'].queryset = Branch.objects.filter(tenant=tenant)
                self.fields['promotion'].queryset = Promotion.objects.filter(tenant=tenant)
                self.fields['coupon'].queryset = Coupon.objects.filter(tenant=tenant)
            elif request.user.is_superuser:
                # Superuser without tenant scope sees all (admin/global context)
                self.fields['appointment'].queryset = Appointment.objects.all()
                from apps.clients_api.models import Client
                from apps.settings_api.models import Branch
                from apps.employees_api.models import Employee
                self.fields['client'].queryset = Client.objects.all()
                self.fields['employee'].queryset = Employee.objects.all()
                self.fields['branch'].queryset = Branch.objects.all()
                self.fields['promotion'].queryset = Promotion.objects.all()
                self.fields['coupon'].queryset = Coupon.objects.all()
            else:
                # No tenant - no access
                self.fields['appointment'].queryset = Appointment.objects.none()
                from apps.clients_api.models import Client
                from apps.settings_api.models import Branch
                from apps.employees_api.models import Employee
                self.fields['client'].queryset = Client.objects.none()
                self.fields['employee'].queryset = Employee.objects.none()
                self.fields['branch'].queryset = Branch.objects.none()
                self.fields['promotion'].queryset = Promotion.objects.none()
                self.fields['coupon'].queryset = Coupon.objects.none()

    def get_employee_name(self, obj):
        employee_user = getattr(getattr(obj, 'employee', None), 'user', None)
        return getattr(employee_user, 'full_name', None) or getattr(employee_user, 'email', None)

    def get_user_name(self, obj):
        user = getattr(obj, 'user', None)
        if user:
            return getattr(user, 'full_name', None) or getattr(user, 'email', None)
        return None

    def validate(self, data):
        import logging
        logger = logging.getLogger(__name__)
        logger.debug("Validating sale payload")
        
        # Validar que existan details y payments
        if not data.get('details'):
            raise serializers.ValidationError("Se requiere al menos un detalle de venta")
        if not data.get('payments'):
            raise serializers.ValidationError("Se requiere al menos un método de pago")
        
        # Validaciones específicas de NCF para República Dominicana
        ncf_type = data.get('ncf_type')
        if ncf_type:
            # Validar que sea un tipo válido
            valid_types = [t[0] for t in NCFSequence.COMPROBANTE_TYPES]
            if ncf_type not in valid_types:
                raise serializers.ValidationError({
                    'ncf_type': _('Invalid NCF type.')
                })
            
            if ncf_type == '01':
                rnc = (data.get('rnc') or '').strip()
                company_name = (data.get('company_name') or '').strip()
                if not rnc:
                    raise serializers.ValidationError({
                        'rnc': _('RNC is required for Fiscal Credit (B01) invoices.')
                    })
                if not company_name:
                    raise serializers.ValidationError({
                        'company_name': _('Company name is required for Fiscal Credit (B01) invoices.')
                    })
                # Validar RNC en RD: 9 o 11 dígitos numéricos
                import re
                if not re.match(r'^\d{9}$|^\d{11}$', rnc):
                    raise serializers.ValidationError({
                        'rnc': _('Invalid RNC. Must be exactly 9 or 11 digits.')
                    })
        
        # Validación cross-tenant
        request = self.context.get('request')
        if not request:
            return data
        
        tenant = getattr(request, 'tenant', None) or getattr(getattr(request, 'user', None), 'tenant', None)
        
        # SuperAdmin puede relacionar cualquier objeto
        if request.user.is_superuser:
            return data
        
        # Usuario sin tenant no puede crear ventas
        if not tenant:
            raise serializers.ValidationError(_('User without assigned tenant'))
        
        # Validar appointment pertenece al tenant
        appointment = data.get('appointment')
        if appointment:
            # Appointment no tiene tenant directo, validar via client o stylist
            from django.db.models import Q
            valid_appointment = Appointment.objects.filter(
                Q(client__tenant_id=tenant.id) | Q(stylist__tenant_id=tenant.id),
                id=appointment.id
            ).exists()
            
            if not valid_appointment:
                raise serializers.ValidationError({
                    'appointment': _('Appointment does not belong to your tenant')
                })
        
        # Validar client pertenece al tenant
        client = data.get('client')
        if client and hasattr(client, 'tenant_id'):
            if client.tenant_id != tenant.id:
                raise serializers.ValidationError({
                    'client': _('Client does not belong to your tenant')
                })

        # Validar coupon pertenece al tenant
        coupon = data.get('coupon')
        if coupon and hasattr(coupon, 'tenant_id'):
            if coupon.tenant_id != tenant.id:
                raise serializers.ValidationError({
                    'coupon': _('Coupon does not belong to your tenant')
                })
            
        return data

    def create(self, validated_data):
        details_data = validated_data.pop('details')
        payments_data = validated_data.pop('payments')
        user = self.context['request'].user
        validated_data['user'] = user

        # FIX POS-003: Obtener tenant para validación cross-tenant
        request = self.context.get('request')
        tenant = getattr(request, 'tenant', None) or getattr(getattr(request, 'user', None), 'tenant', None)

        # FIX POS-003: Validar cross-tenant ANTES de crear la venta
        if tenant and not user.is_superuser:
            from apps.inventory_api.models import Product
            from apps.services_api.models import Service
            for detail in details_data:
                object_id = detail.get('object_id')
                content_type_str = detail.get('content_type')
                if not object_id or not content_type_str:
                    raise serializers.ValidationError(
                        "Cada detalle debe tener content_type y object_id"
                    )
                try:
                    oid = int(object_id)
                except (TypeError, ValueError):
                    raise serializers.ValidationError(
                        f"object_id inválido: {object_id}"
                    )
                if content_type_str == 'product':
                    if not Product.objects.filter(id=oid, tenant=tenant, is_active=True).exists():
                        raise serializers.ValidationError(
                            f"Producto {oid} no encontrado en tu sucursal"
                        )
                elif content_type_str == 'service':
                    if not Service.objects.filter(id=oid, tenant=tenant, is_active=True).exists():
                        raise serializers.ValidationError(
                            f"Servicio {oid} no encontrado en tu sucursal"
                        )
                else:
                    raise serializers.ValidationError(
                        f"Tipo de contenido inválido: {content_type_str}"
                    )

        appointment = validated_data.pop('appointment', None)
        sale = Sale.objects.create(**validated_data)

        # Crear detalles
        for detail in details_data:
            # Convertir content_type string a ContentType object
            from django.contrib.contenttypes.models import ContentType
            if detail['content_type'] == 'service':
                content_type = ContentType.objects.get(app_label='services_api', model='service')
            else:  # product
                content_type = ContentType.objects.get(app_label='inventory_api', model='product')
            
            detail['content_type'] = content_type
            # 'employee_id' es alias de entrada; la FK real es 'employee'.
            # 'employee' ya viene resuelto como instancia por el serializer.
            detail.pop('employee_id', None)
            # Los productos nunca llevan barbero responsable.
            if detail['content_type'].model != 'service':
                detail.pop('employee', None)
            SaleDetail.objects.create(sale=sale, **detail)
            # Stock ya se descuenta en perform_create() con transacciones atómicas

        for payment in payments_data:
            Payment.objects.create(sale=sale, **payment)

        # Si existe appointment, cambiar estado a 'completed'
        if appointment and isinstance(appointment, Appointment):
            allowed_statuses = ["completed", "cancelled", "no_show"]
            new_status = "completed"
            if new_status not in allowed_statuses:
                raise serializers.ValidationError("Estado de cita inválido")
            appointment.status = new_status
            appointment.sale = sale
            appointment.save(update_fields=['status', 'sale'])

        return sale

class CashRegisterSerializer(serializers.ModelSerializer):
    sales_amount = serializers.SerializerMethodField()
    user_name = serializers.SerializerMethodField()
    user_role = serializers.SerializerMethodField()
    
    class Meta:
        model = CashRegister
        fields = ['id', 'user', 'user_name', 'user_role', 'branch', 'opened_at', 'closed_at', 'initial_cash', 'final_cash', 'is_open', 'sales_amount']
        read_only_fields = ['user', 'user_name', 'user_role', 'opened_at', 'closed_at', 'sales_amount']

    def get_user_name(self, obj):
        if obj.user:
            return obj.user.full_name or obj.user.email
        return None

    def get_user_role(self, obj):
        if not obj.user:
            return None
        try:
            from apps.auth_api.role_utils import get_effective_role_api
            tenant = getattr(obj, 'tenant', None)
            return get_effective_role_api(obj.user, tenant=tenant)
        except Exception:
            return getattr(obj.user, 'role', None)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        request = self.context.get('request')
        if request:
            tenant = getattr(request, 'tenant', None) or getattr(getattr(request, 'user', None), 'tenant', None)
            if tenant:
                from apps.settings_api.models import Branch
                from django.contrib.auth import get_user_model
                User = get_user_model()
                self.fields['branch'].queryset = Branch.objects.filter(tenant=tenant)
                self.fields['user'].queryset = User.objects.filter(tenant=tenant)
    
    def get_sales_amount(self, obj):
        """Calcular ventas en efectivo asociadas a esta sesión de caja"""
        if not obj.opened_at:
            return 0.0
        return obj.sales_amount

class CashCountSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashCount
        fields = ['id', 'cash_register', 'denomination', 'count', 'total', 'created_at']
        read_only_fields = ['total', 'created_at']
    
    def validate(self, data):
        data['total'] = data['denomination'] * data['count']
        return data

class CashRegisterCreateSerializer(serializers.ModelSerializer):
    """Serializer para crear caja registradora"""
    initial_cash = serializers.DecimalField(max_digits=10, decimal_places=2, default=0.00, min_value=0)
    
    class Meta:
        model = CashRegister
        fields = ['initial_cash']
    
    def validate_initial_cash(self, value):
        if value is None:
            return 0.00
        return value

class CashRegisterCloseSerializer(serializers.ModelSerializer):
    """Serializer para cerrar caja registradora"""
    final_cash = serializers.DecimalField(max_digits=10, decimal_places=2, min_value=0)
    
    class Meta:
        model = CashRegister
        fields = ['final_cash']
    
    def validate_final_cash(self, value):
        if value is None:
            raise serializers.ValidationError("final_cash es requerido para cerrar la caja")
        return value

class PromotionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Promotion
        fields = ['id', 'name', 'description', 'type', 'conditions', 'discount_value', 
                 'min_amount', 'start_date', 'end_date', 'is_active', 'max_uses', 'current_uses']

    def validate(self, attrs):
        from decimal import Decimal, InvalidOperation

        type_ = attrs.get('type', getattr(self.instance, 'type', None))
        conditions = attrs.get('conditions', getattr(self.instance, 'conditions', None) or {}) or {}
        discount_value = attrs.get('discount_value', getattr(self.instance, 'discount_value', None))
        min_amount = attrs.get('min_amount', getattr(self.instance, 'min_amount', 0))
        max_uses = attrs.get('max_uses', getattr(self.instance, 'max_uses', None))

        def _positive(value, field):
            if value is None:
                return
            try:
                if Decimal(str(value)) <= 0:
                    raise serializers.ValidationError({field: 'Debe ser mayor a 0.'})
            except (InvalidOperation, ValueError):
                raise serializers.ValidationError({field: 'Valor numérico inválido.'})

        def _validate_product_ids(ids):
            bad = [i for i in (ids or []) if (not isinstance(i, int)) or i <= 0]
            if bad:
                raise serializers.ValidationError({
                    'conditions': f'product_ids inválidos: {bad}. Usa ids positivos o deja vacío para aplicar a todo.'
                })

        if type_ == 'buy_x_get_y':
            if int(conditions.get('buy_quantity') or 0) < 1:
                raise serializers.ValidationError({'conditions': 'buy_quantity debe ser al menos 1.'})
            if int(conditions.get('get_quantity') or 0) < 1:
                raise serializers.ValidationError({'conditions': 'get_quantity debe ser al menos 1.'})
            _validate_product_ids(conditions.get('product_ids'))
        elif type_ == 'combo':
            if not conditions.get('product_ids'):
                raise serializers.ValidationError({'conditions': 'combo requiere product_ids no vacío.'})
            _validate_product_ids(conditions.get('product_ids'))
            _positive(conditions.get('bundle_price'), 'bundle_price')

        _positive(discount_value, 'discount_value')
        if min_amount is not None:
            try:
                if Decimal(str(min_amount)) < 0:
                    raise serializers.ValidationError({'min_amount': 'No puede ser negativo.'})
            except (InvalidOperation, ValueError):
                raise serializers.ValidationError({'min_amount': 'Valor numérico inválido.'})
        if max_uses is not None:
            try:
                if int(max_uses) < 0:
                    raise serializers.ValidationError({'max_uses': 'No puede ser negativo.'})
            except (TypeError, ValueError):
                raise serializers.ValidationError({'max_uses': 'Valor numérico inválido.'})

        start = attrs.get('start_date', getattr(self.instance, 'start_date', None))
        end = attrs.get('end_date', getattr(self.instance, 'end_date', None))
        if start and end and end <= start:
            raise serializers.ValidationError({'end_date': 'Debe ser posterior a la fecha de inicio.'})

        return attrs

class ReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Receipt
        fields = ['id', 'sale', 'receipt_number', 'template_used', 'generated_at', 
                 'printed_count', 'last_printed']
        read_only_fields = ['receipt_number', 'generated_at']

class PosConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PosConfiguration
        fields = ['id', 'tenant', 'user', 'business_name', 'address', 'phone', 'email', 'website', 'rnc',
                 'currency', 'currency_symbol', 'tax_rate', 'tax_included',
                 'receipt_template', 'receipt_footer', 'auto_print_receipt', 'require_customer',
                 'allow_negative_stock']
        read_only_fields = ['tenant', 'user']


class NCFSequenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = NCFSequence
        fields = [
            'id', 'tenant', 'type', 'prefix', 'start_sequence', 
            'end_sequence', 'current_sequence', 'expiration_date', 'is_active',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['tenant', 'created_at', 'updated_at']

class CouponSerializer(serializers.ModelSerializer):
    class Meta:
        model = Coupon
        fields = [
            'id', 'code', 'description', 'type', 'value', 'min_purchase_amount',
            'start_date', 'end_date', 'is_active', 'max_uses', 'current_uses'
        ]
        read_only_fields = ['current_uses']

    def validate_code(self, value):
        return value.strip().upper()

    def validate(self, data):
        start_date = data.get('start_date')
        end_date = data.get('end_date')
        if start_date and end_date and start_date >= end_date:
            raise serializers.ValidationError("La fecha de inicio debe ser anterior a la de finalización.")
        return data

class CouponValidationSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=50)
    cart_total = serializers.DecimalField(max_digits=14, decimal_places=2, min_value=0.00)

    def validate_code(self, value):
        return value.strip().upper()


class PrinterSerializer(serializers.Serializer):
    """Serializador para información de impresoras disponibles"""
    id = serializers.CharField()
    name = serializers.CharField()
    type = serializers.ChoiceField(choices=[('usb', 'USB'), ('lan', 'LAN'), ('windows', 'Windows')])
    path = serializers.CharField(required=False, allow_blank=True)  # COM3, IP:9100, etc.
    status = serializers.ChoiceField(choices=[('online', 'Online'), ('offline', 'Offline'), ('unknown', 'Unknown')])
    is_default = serializers.BooleanField(default=False)
    capabilities = serializers.ListField(
        child=serializers.CharField(),
        required=False,
        default=list
    )  # ej: ['cut', 'bold', 'underline', 'cp850']
