from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .integration_views import IntegrationStatusView, IntegrationTestView
from .admin_views import SaasMetricsView, SystemMonitorView, test_integration_service, sync_role_permissions
from .contact_views import presentation_request, newsletter_signup
from .barbershop_views import BarbershopSettingsViewSet
from .views import BranchViewSet, PublicBrandingSettingsView

router = DefaultRouter()
router.register(r'barbershop', BarbershopSettingsViewSet, basename='barbershop-settings')
router.register(r'branches', BranchViewSet, basename='branch')

urlpatterns = [
    path('', include(router.urls)),
    path('public-branding/', PublicBrandingSettingsView.as_view(), name='public-branding'),
    path('integrations/status/', IntegrationStatusView.as_view(), name='integration-status'),
    path('integrations/test/', IntegrationTestView.as_view(), name='integration-test'),
    
    # SuperAdmin endpoints
    path('admin/metrics/', SaasMetricsView.as_view(), name='admin-saas-metrics'),
    path('admin/system-monitor/', SystemMonitorView.as_view(), name='admin-system-monitor'),
    path('admin/test-service/', test_integration_service, name='admin-test-service'),
    path('admin/sync-permissions/', sync_role_permissions, name='admin-sync-permissions'),
    
    # Contact endpoints
    path('contact/presentation/', presentation_request, name='presentation-request'),
    path('contact/newsletter/', newsletter_signup, name='newsletter-signup'),
]
