from django.db import models
from django.conf import settings as django_settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core import signing
from django.utils.translation import gettext_lazy as _

# Importar modelos adicionales
from .audit_models import SettingsAuditLog
from .barbershop_models import BarbershopSettings


class Branch(models.Model):
    """Sucursales - Solo para planes Enterprise/Multi-Branch"""
    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='branches')
    name = models.CharField(max_length=255)
    address = models.TextField(blank=True, null=True)
    is_main = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['tenant', 'name'], name='unique_branch_per_tenant')
        ]

    def save(self, *args, **kwargs):
        # Verificar que el tenant tenga un plan que permita multiples sucursales
        plan = getattr(self.tenant, 'subscription_plan', None)
        if not plan:
            sub = getattr(self.tenant, 'subscription_set', None)
            if sub:
                active_sub = sub.filter(is_active=True).first()
                if active_sub:
                    plan = active_sub.plan
        if not plan and getattr(self.tenant, 'plan_type', None):
            from apps.subscriptions_api.models import SubscriptionPlan
            plan = SubscriptionPlan.objects.filter(name=self.tenant.plan_type).first()

        allows_multi = getattr(plan, 'allows_multiple_branches', False) if plan else False
        if not allows_multi:
            if Branch.objects.filter(tenant=self.tenant).exclude(pk=self.pk).exists():
                raise ValueError(_("Tu plan actual solo permite 1 sucursal principal. Mejora a Business o Enterprise para abrir más sucursales."))
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.tenant.name})"


class Setting(models.Model):
    """Configuraciones por sucursal - Solo para planes Enterprise"""
    branch = models.OneToOneField(Branch, on_delete=models.CASCADE, related_name='settings')
    business_name = models.CharField(_("Nombre del negocio"), max_length=255)
    business_email = models.EmailField(_("Email de contacto"), blank=True, null=True)
    phone_number = models.CharField(_("Telefono"), max_length=50, blank=True, null=True)
    address = models.TextField(_("Direccion"), blank=True, null=True)
    currency = models.CharField(_("Moneda"), max_length=10, default="USD")
    tax_percentage = models.DecimalField(
        _("Porcentaje de impuestos"),
        max_digits=5,
        decimal_places=2,
        default=0,
        validators=[MinValueValidator(0), MaxValueValidator(100)]
    )
    timezone = models.CharField(_("Zona horaria"), max_length=100, default="America/Santo_Domingo")
    business_hours = models.JSONField(_("Horario de atencion"), default=dict, blank=True)
    preferences = models.JSONField(_("Preferencias generales"), default=dict, blank=True)
    logo = models.ImageField(_("Logo del negocio"), upload_to="settings/logo/", blank=True, null=True)
    theme = models.CharField(_("Tema visual"), max_length=50, default="light")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.business_name} - {self.branch.name}"


SECRET_FIELDS = [
    'smtp_password',
    'stripe_secret_key',
    'webhook_secret',
    'paypal_client_secret',
    'twilio_auth_token',
    'azul_auth1',
    'azul_auth2',
    'azul_cert_key',
]

class SystemSettings(models.Model):
    """Configuraciones globales del sistema SaaS"""
    # Configuracion General
    platform_name = models.CharField(_("Nombre de la plataforma"), max_length=255, default="Auron Suite")
    support_email = models.EmailField(_("Email de soporte"), default="soporte@auronsuite.com")

    # Configuracion de Clientes
    max_tenants = models.PositiveIntegerField(_("Maximo de clientes"), default=100)
    trial_days = models.PositiveIntegerField(
        _("Dias de prueba"),
        default=7,
        validators=[MinValueValidator(0), MaxValueValidator(365)]
    )
    default_currency = models.CharField(_("Moneda por defecto"), max_length=10, default="USD")

    # Configuracion de Plataforma
    platform_domain = models.CharField(_("Dominio principal"), max_length=255, blank=True)
    supported_languages = models.JSONField(_("Idiomas habilitados"), default=list)
    platform_commission_rate = models.DecimalField(
        _("Comision de plataforma (%)"),
        max_digits=5,
        decimal_places=2,
        default=5.00,
        validators=[MinValueValidator(0), MaxValueValidator(50)]
    )

    # Limites por Plan
    basic_plan_max_employees = models.PositiveIntegerField(_("Plan basico - max. empleados"), default=5)
    premium_plan_max_employees = models.PositiveIntegerField(_("Plan premium - max. empleados"), default=25)
    enterprise_plan_max_employees = models.PositiveIntegerField(_("Plan enterprise - max. empleados"), default=999)

    # Integraciones Globales (toggles)
    stripe_enabled = models.BooleanField(_("Stripe habilitado"), default=True)
    paypal_enabled = models.BooleanField(_("PayPal habilitado"), default=False)
    twilio_enabled = models.BooleanField(_("SMS (Twilio) habilitado"), default=False)
    sendgrid_enabled = models.BooleanField(_("Email (SendGrid) habilitado"), default=True)
    aws_s3_enabled = models.BooleanField(_("Almacenamiento (AWS S3) habilitado"), default=True)

    # Email (SMTP)
    smtp_host = models.CharField(_("Servidor SMTP"), max_length=255, blank=True)
    smtp_port = models.PositiveIntegerField(_("Puerto SMTP"), default=587)
    smtp_username = models.CharField(_("Usuario SMTP"), max_length=255, blank=True)
    smtp_password = models.CharField(_("Password SMTP"), max_length=255, blank=True)
    from_email = models.EmailField(_("Email remitente"), blank=True)
    from_name = models.CharField(_("Nombre remitente"), max_length=255, blank=True)

    # Stripe
    stripe_public_key = models.CharField(_("Stripe public key"), max_length=255, blank=True)
    stripe_secret_key = models.CharField(_("Stripe secret key"), max_length=255, blank=True)
    webhook_secret = models.CharField(_("Stripe webhook secret"), max_length=255, blank=True)

    # PayPal
    paypal_client_id = models.CharField(_("PayPal client id"), max_length=255, blank=True)
    paypal_client_secret = models.CharField(_("PayPal client secret"), max_length=255, blank=True)
    paypal_sandbox = models.BooleanField(_("PayPal sandbox"), default=True)

    # Twilio
    twilio_account_sid = models.CharField(_("Twilio account SID"), max_length=64, blank=True)
    twilio_auth_token = models.CharField(_("Twilio auth token"), max_length=255, blank=True)
    twilio_phone_number = models.CharField(_("Twilio phone number"), max_length=32, blank=True)

    # Azul (payment processor primario para RD)
    azul_enabled = models.BooleanField(_("Azul habilitado"), default=False)
    azul_sandbox = models.BooleanField(_("Azul sandbox"), default=True)
    azul_store_id = models.CharField(_("Azul Store ID"), max_length=255, blank=True)
    azul_merchant_id = models.CharField(_("Azul Merchant ID"), max_length=255, blank=True)
    azul_auth1 = models.CharField(_("Azul Auth1 (usuario)"), max_length=255, blank=True)
    azul_auth2 = models.CharField(_("Azul Auth2 (password)"), max_length=255, blank=True)
    azul_cert_key = models.TextField(_("Azul cert/key (PEM)"), blank=True,
                                      help_text="Certificado PEM para autenticación SSL mutua (opcional en JSON mode)")

    # Preferencias del Sistema
    maintenance_mode = models.BooleanField(_("Modo mantenimiento"), default=False)
    email_notifications = models.BooleanField(_("Notificaciones por email"), default=True)
    auto_suspend_expired = models.BooleanField(_("Suspender automaticamente vencidos"), default=True)
    auto_upgrade_limits = models.BooleanField(_("Auto upgrade de limites"), default=False)

    # Seguridad
    jwt_expiry_minutes = models.PositiveIntegerField(_("JWT expiry minutes"), default=60)
    max_login_attempts = models.PositiveIntegerField(_("Max login attempts"), default=5)
    login_lockout_minutes = models.PositiveIntegerField(_("Login lockout minutes"), default=5)
    password_min_length = models.PositiveIntegerField(_("Password min length"), default=8)
    require_email_verification = models.BooleanField(_("Require email verification"), default=True)
    enable_mfa = models.BooleanField(_("Enable MFA"), default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Configuracion del Sistema")
        verbose_name_plural = _("Configuraciones del Sistema")

    @staticmethod
    def _fernet():
        from cryptography.fernet import Fernet
        key = getattr(django_settings, 'FERNET_KEY', None)
        if not key:
            if not getattr(django_settings, 'DEBUG', True):
                raise RuntimeError(
                    'FERNET_KEY no esta configurada: no se permite guardar '
                    'configuracion sensible en texto plano en produccion.'
                )
            return None
        if isinstance(key, str):
            key = key.encode()
        return Fernet(key)

    @staticmethod
    def _encrypt(value):
        if not value:
            return value
        fernet = SystemSettings._fernet()
        if fernet is not None:
            try:
                payload = value.encode() if isinstance(value, str) else value
                return fernet.encrypt(payload).decode()
            except RuntimeError:
                raise
            except Exception as exc:
                if not getattr(django_settings, 'DEBUG', True):
                    raise RuntimeError('No se pudo cifrar configuracion sensible: %s' % exc) from exc
        # Fallback desarrollo / valores previos: firmado (integridad), nunca texto plano.
        return signing.dumps(value, salt="system_settings", compress=True)

    @staticmethod
    def _decrypt(value):
        if not value:
            return value
        if value.startswith('gAAAAA'):
            fernet = SystemSettings._fernet()
            if fernet is not None:
                try:
                    return fernet.decrypt(value.encode()).decode()
                except Exception:
                    return value
        try:
            return signing.loads(value, salt="system_settings")
        except (signing.BadSignature, signing.SignatureExpired):
            return value

    @staticmethod
    def _is_encrypted(value):
        """Determine if a value appears to be encrypted.
        Reconoce tokens Fernet (prefijo gAAAAA) y valores firmados con
        django.core.signing (payload:timestamp:signature).
        """
        if not value:
            return True
        if value.startswith('gAAAAA'):
            return True
        # Structural validation: signed strings contain exactly two ':' separators
        if value.count(":") == 2:
            return True
        try:
            signing.loads(value, salt="system_settings")
            return True
        except (signing.BadSignature, signing.SignatureExpired):
            return False

    def save(self, *args, **kwargs):
        if not self.pk and SystemSettings.objects.exists():
            raise ValueError(_("Solo puede existir una configuracion del sistema"))
        for field in SECRET_FIELDS:
            value = getattr(self, field)
            if value and not self._is_encrypted(value):
                setattr(self, field, self._encrypt(value))
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Configuraciones del Sistema - {self.platform_name}"

    @classmethod
    def get_settings(cls):
        """Obtener o crear la configuracion del sistema"""
        settings, created = cls.objects.get_or_create(
            pk=1,
            defaults={
                'platform_name': 'Auron Suite',
                'support_email': 'soporte@auronsuite.com',
                'max_tenants': 100,
                'trial_days': 7,
                'default_currency': 'USD',
                'platform_domain': '',
                'supported_languages': ['es', 'en'],
                'platform_commission_rate': 5.00,
                'basic_plan_max_employees': 5,
                'premium_plan_max_employees': 25,
                'enterprise_plan_max_employees': 999,
                'stripe_enabled': True,
                'paypal_enabled': False,
                'twilio_enabled': False,
                'sendgrid_enabled': True,
                'aws_s3_enabled': True,
                'smtp_host': '',
                'smtp_port': 587,
                'smtp_username': '',
                'smtp_password': '',
                'from_email': '',
                'from_name': '',
                'stripe_public_key': '',
                'stripe_secret_key': '',
                'webhook_secret': '',
                'paypal_client_id': '',
                'paypal_client_secret': '',
                'paypal_sandbox': True,
                'twilio_account_sid': '',
                'twilio_auth_token': '',
                'twilio_phone_number': '',
                'azul_enabled': False,
                'azul_sandbox': True,
                'azul_store_id': '',
                'azul_merchant_id': '',
                'azul_auth1': '',
                'azul_auth2': '',
                'azul_cert_key': '',
                'maintenance_mode': False,
                'email_notifications': True,
                'auto_suspend_expired': True,
                'auto_upgrade_limits': False,
                'jwt_expiry_minutes': 60,
                'max_login_attempts': 5,
                'login_lockout_minutes': 5,
                'password_min_length': 8,
                'require_email_verification': True,
                'enable_mfa': False
            }
        )
        # Descifrar campos secretos en memoria para que estén listos para usar
        for field in SECRET_FIELDS:
            val = getattr(settings, field, '')
            if val and settings._is_encrypted(val):
                setattr(settings, field, settings._decrypt(val))
        return settings
