from django.db import models
from apps.clients_api.models import Client
from apps.roles_api.models import Role
from django.contrib.auth import get_user_model
from apps.services_api.models import Service

User = get_user_model()

class Appointment(models.Model):
    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('no_show', 'No Show'),
    ]

    tenant = models.ForeignKey('tenants_api.Tenant', on_delete=models.CASCADE, related_name='appointments')
    branch = models.ForeignKey('settings_api.Branch', null=True, blank=True, on_delete=models.SET_NULL, related_name='branch_appointments')
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='client_appointments')
    stylist = models.ForeignKey(User, on_delete=models.CASCADE, related_name='stylist_appointments')
    service = models.ForeignKey(Service, on_delete=models.SET_NULL, null=True, blank=True, related_name='appointments')
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True, related_name='role_appointments')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='scheduled')
    sale = models.OneToOneField('pos_api.Sale', on_delete=models.SET_NULL, null=True, blank=True, related_name='appointment')
    created_at = models.DateTimeField(auto_now_add=True)
    description = models.TextField(blank=True, null=True)
    updated_at = models.DateTimeField(auto_now=True)
    date_time = models.DateTimeField()

    class Meta:
        permissions = [
            ('cancel_appointment', 'Can cancel appointments'),
            ('complete_appointment', 'Can mark appointments as complete'),
        ]
        verbose_name = 'Cita'
        verbose_name_plural = 'Citas'
        ordering = ['-date_time']
        indexes = [
            models.Index(fields=['tenant', 'date_time']),
            models.Index(fields=['tenant', 'status']),
            models.Index(fields=['tenant', 'stylist', 'date_time']),
            models.Index(fields=['tenant', 'branch', 'date_time']),
            models.Index(fields=['date_time']),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['tenant', 'stylist', 'client', 'date_time'],
                name='unique_appointment_per_stylist_client_datetime',
            ),
        ]

    def __str__(self):
        return f'{self.client} with {self.stylist} at {self.date_time}'
