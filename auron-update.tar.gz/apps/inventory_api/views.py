from rest_framework import viewsets, permissions
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from apps.audit_api.mixins import AuditLoggingMixin
from apps.tenants_api.base_viewsets import TenantScopedViewSet, TenantScopedReadOnlyViewSet
from apps.core.tenant_permissions import TenantPermissionByAction, tenant_permission
from apps.subscriptions_api.permissions import HasFeaturePermission
from .models import Product, Supplier, StockMovement
from .serializers import ProductSerializer, SupplierSerializer, StockMovementSerializer
from rest_framework.decorators import action, api_view, permission_classes
from django.db.models import Q
from rest_framework.response import Response
from django.db.models import F
from rest_framework import status


class ProductViewSet(AuditLoggingMixin, TenantScopedViewSet):
    queryset = Product.objects.select_related('category', 'branch').all()
    serializer_class = ProductSerializer
    permission_classes = [TenantPermissionByAction, HasFeaturePermission]
    required_feature = 'inventory'
    permission_map = {
        'list': 'inventory_api.view_product',
        'retrieve': 'inventory_api.view_product',
        'create': 'inventory_api.add_product',
        'update': 'inventory_api.change_product',
        'partial_update': 'inventory_api.change_product',
        'destroy': 'inventory_api.delete_product',
        'adjust_stock': 'inventory_api.adjust_stock',
        'low_stock': 'inventory_api.view_product',
        'stock_report': 'inventory_api.view_product',
        'search_by_barcode': 'inventory_api.view_product',
    }
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['is_active', 'category', 'branch']
    ordering_fields = ['name', 'price', 'stock', 'created_at']
    search_fields = ['name', 'sku', 'barcode']
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context
    
    @action(detail=False, methods=['get'])
    def low_stock(self, request):
        """Obtener productos con stock bajo (filtrado por tenant vía TenantScopedViewSet)"""
        products = self.get_queryset().filter(
            stock__lte=F('min_stock'),
            is_active=True
        )
        serializer = ProductSerializer(products, many=True)
        return Response({
            'count': products.count(),
            'products': serializer.data
        })
    
    @action(detail=True, methods=['post'])
    def adjust_stock(self, request, pk=None):
        """Ajustar stock de un producto"""
        quantity = request.data.get('quantity', 0)
        reason = (request.data.get('reason') or 'Ajuste manual').strip()

        if not isinstance(quantity, (int, float)):
            return Response(
                {'error': 'La cantidad debe ser un número'},
                status=400
            )
        if quantity == 0:
            return Response({'error': 'La cantidad no puede ser cero'}, status=400)
        if not reason or len(reason) < 3:
            return Response({'error': 'Motivo requerido (mínimo 3 caracteres)'}, status=400)

        from django.db import transaction
        with transaction.atomic():
            product = Product.objects.select_for_update().get(pk=self.get_object().pk)
            new_stock = product.stock + int(quantity)
            if new_stock < 0:
                return Response(
                    {'error': f'Stock insuficiente. Disponible: {product.stock}, solicitado: {abs(int(quantity))}'},
                    status=400
                )
            Product.objects.filter(pk=product.pk).update(stock=F('stock') + int(quantity))
            StockMovement.objects.create(
                product=product,
                quantity=int(quantity),
                reason=reason
            )
            product.refresh_from_db()

        return Response({
            'detail': f'Stock ajustado. Nuevo stock: {product.stock}',
            'new_stock': product.stock
        })
    
    @action(detail=False, methods=['get'])
    def stock_report(self, request):
        """Reporte general de inventario (filtrado por tenant)"""
        from django.db.models import Sum, Count
        
        qs = self.get_queryset().filter(is_active=True)
        
        total_products = qs.count()
        low_stock_count = qs.filter(
            stock__lte=F('min_stock'),
        ).count()
        
        total_value = qs.aggregate(
            total=Sum(F('stock') * F('price'))
        )['total'] or 0
        
        return Response({
            'total_products': total_products,
            'low_stock_count': low_stock_count,
            'total_inventory_value': float(total_value),
            'low_stock_percentage': (low_stock_count / total_products * 100) if total_products > 0 else 0
        })
    
    @action(detail=False, methods=['get'])
    def search_by_barcode(self, request):
        """Buscar producto por código de barras"""
        barcode = request.query_params.get('barcode')
        if not barcode:
            return Response({'error': 'Código de barras requerido'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            tenant = getattr(request, 'tenant', None) or getattr(request.user, 'tenant', None)
            if not tenant:
                return Response({'error': 'Tenant no encontrado'}, status=status.HTTP_400_BAD_REQUEST)
            product = Product.objects.get(
                barcode=barcode,
                tenant=tenant,
                is_active=True
            )
            serializer = ProductSerializer(product)
            return Response(serializer.data)
        except Product.DoesNotExist:
            return Response(
                {'error': 'Producto no encontrado'}, 
                status=status.HTTP_404_NOT_FOUND
            )

@api_view(['GET'])
@permission_classes([tenant_permission('inventory_api.view_product')])
def low_stock_alerts(request):
    """API endpoint para alertas de stock bajo (filtrado por tenant)"""
    from apps.tenants_api.models import Tenant
    
    qs = Product.objects.filter(
        stock__lte=F('min_stock'),
        is_active=True
    )
    tenant = getattr(request, 'tenant', None) or (None if request.user.is_superuser else request.user.tenant)
    if tenant:
        qs = qs.filter(tenant=tenant)
    elif not request.user.is_superuser:
        qs = Product.objects.none()
    
    data = ProductSerializer(qs, many=True).data
    return Response({
        'count': qs.count(),
        'products': data
    })


class SupplierViewSet(AuditLoggingMixin, TenantScopedViewSet):
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer
    permission_classes = [TenantPermissionByAction, HasFeaturePermission]
    required_feature = 'inventory'
    permission_map = {
        'list': 'inventory_api.view_supplier',
        'retrieve': 'inventory_api.view_supplier',
        'create': 'inventory_api.add_supplier',
        'update': 'inventory_api.change_supplier',
        'partial_update': 'inventory_api.change_supplier',
        'destroy': 'inventory_api.delete_supplier',
    }

class StockMovementViewSet(TenantScopedReadOnlyViewSet):
    queryset = StockMovement.objects.select_related('product', 'product__tenant').all()
    serializer_class = StockMovementSerializer
    permission_classes = [TenantPermissionByAction, HasFeaturePermission]
    required_feature = 'inventory'
    permission_map = {
        # Reutiliza permiso de lectura de inventario para permitir historial
        # a roles que ya pueden ver productos (ej. Client-Admin/Manager).
        'list': 'inventory_api.view_product',
        'retrieve': 'inventory_api.view_product',
    }

    def get_queryset(self):
        """Filtrar por tenant vía product__tenant (StockMovement no tiene tenant directo)."""
        user = self.request.user
        
        if user.is_superuser:
            tenant = getattr(self.request, 'tenant', None)
            if tenant:
                return StockMovement.objects.filter(product__tenant=tenant)
            return StockMovement.objects.all()
        
        if not hasattr(self.request, 'tenant') or not self.request.tenant:
            return StockMovement.objects.none()
        
        return StockMovement.objects.filter(product__tenant=self.request.tenant)
