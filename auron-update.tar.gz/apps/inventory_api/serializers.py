from rest_framework import serializers
from django.utils.text import slugify
from .models import Product, StockMovement, Supplier, ProductCategory


class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        fields = ['id', 'name', 'phone', 'email']


class ProductCategorySerializer(serializers.ModelSerializer):
    product_count = serializers.SerializerMethodField()

    class Meta:
        model = ProductCategory
        fields = ['id', 'name', 'description', 'is_active', 'product_count']
        read_only_fields = ['product_count']

    def get_product_count(self, obj):
        return obj.products.filter(is_active=True).count()


from apps.settings_api.models import Branch


class ProductSerializer(serializers.ModelSerializer):
    sku = serializers.CharField(required=False, allow_blank=True, allow_null=True, max_length=100)
    category = serializers.PrimaryKeyRelatedField(
        queryset=ProductCategory.objects.all(), allow_null=True, required=False
    )
    branch = serializers.PrimaryKeyRelatedField(
        queryset=Branch.objects.all(), allow_null=True, required=False
    )
    image = serializers.CharField(required=False, allow_blank=True, allow_null=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        request = self.context.get('request')
        if request and hasattr(request, 'tenant') and request.tenant:
            self.fields['category'].queryset = ProductCategory.objects.filter(tenant=request.tenant)
            self.fields['branch'].queryset = Branch.objects.filter(tenant=request.tenant)

    category_name = serializers.SerializerMethodField()
    description = serializers.CharField(default='', allow_blank=True, required=False)
    image_url = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ['id', 'name', 'sku', 'barcode', 'price', 'stock', 'min_stock', 
                  'unit', 'is_active', 'description', 'category', 'category_name', 
                  'image', 'image_url', 'branch']
        read_only_fields = ['id', 'category_name', 'image_url']

    def create(self, validated_data):
        image_file = validated_data.pop('image', None)
        instance = super().create(validated_data)
        if image_file:
            self._save_image(instance, image_file)
        return instance

    def update(self, instance, validated_data):
        image_file = validated_data.pop('image', None)
        instance = super().update(instance, validated_data)
        if image_file:
            self._save_image(instance, image_file)
        return instance

    def _save_image(self, instance, image_file):
        if not image_file:
            return
        try:
            if isinstance(image_file, str):
                image_str = image_file.strip()
                if image_str.startswith('data:image'):
                    import base64
                    from django.core.files.base import ContentFile
                    header, imgstr = image_str.split(';base64,')
                    ext = header.split('/')[-1].split('+')[0]
                    if ext == 'jpeg': ext = 'jpg'
                    file_name = f"product_{instance.id}.{ext}"
                    data = ContentFile(base64.b64decode(imgstr), name=file_name)
                    instance.image.save(file_name, data, save=True)
                elif image_str.startswith('http://') or image_str.startswith('https://'):
                    instance.image = image_str
                    instance.save(update_fields=['image'])
            else:
                instance.image = image_file
                instance.save(update_fields=['image'])
        except Exception as e:
            pass

    def get_category_name(self, obj):
        return obj.category.name if obj.category else None

    def get_image_url(self, obj):
        if obj.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        return None

    def _get_tenant(self):
        request = self.context.get('request')
        if not request:
            return None
        return getattr(request, 'tenant', None) or getattr(request.user, 'tenant', None)

    def _generate_sku(self, attrs):
        tenant = self._get_tenant()
        base_name = attrs.get('name') or (self.instance.name if self.instance else '') or 'PRODUCT'
        base = slugify(base_name).upper().replace('-', '')[:8] or 'PRODUCT'
        prefix = f"PRD-{base}"

        for i in range(1, 10000):
            candidate = f"{prefix}-{i:03d}"
            exists = Product.objects.filter(sku=candidate, tenant=tenant)
            if self.instance:
                exists = exists.exclude(pk=self.instance.pk)
            if not exists.exists():
                return candidate

        return f"{prefix}-X001"

    def validate(self, attrs):
        # Normalizar barcode "" -> None para no violar UniqueConstraint con isnull=False
        if 'barcode' in attrs:
            barcode = attrs.get('barcode')
            if barcode is not None and str(barcode).strip() == '':
                attrs['barcode'] = None
            elif barcode is not None:
                attrs['barcode'] = str(barcode).strip()

        # Validar stock no negativo
        if 'stock' in attrs and attrs['stock'] is not None and attrs['stock'] < 0:
            raise serializers.ValidationError({'stock': 'El stock no puede ser negativo'})

        sku = attrs.get('sku', None)

        if not self.instance and (sku is None or str(sku).strip() == ''):
            attrs['sku'] = self._generate_sku(attrs)
            return super().validate(attrs)

        if self.instance and sku is None:
            return super().validate(attrs)

        if str(sku).strip() == '':
            attrs['sku'] = self._generate_sku(attrs)
        else:
            attrs['sku'] = str(sku).strip()
        return super().validate(attrs)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if instance.image:
            request = self.context.get('request')
            if request:
                data['image'] = request.build_absolute_uri(instance.image.url)
            else:
                data['image'] = instance.image.url
        else:
            data['image'] = None
        return data


class StockMovementSerializer(serializers.ModelSerializer):
    class Meta:
        model = StockMovement
        fields = ['id', 'product', 'quantity', 'reason', 'created_at']
        read_only_fields = ['created_at']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        request = self.context.get('request')
        if request:
            tenant = getattr(request, 'tenant', None)
            if tenant:
                self.fields['product'].queryset = Product.objects.filter(tenant=tenant)
