from rest_framework import viewsets, permissions, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from django_filters.rest_framework import DjangoFilterBackend
from apps.audit_api.mixins import AuditLoggingMixin
from apps.tenants_api.base_viewsets import TenantScopedViewSet
from apps.tenants_api.models import Tenant
from apps.core.tenant_permissions import TenantPermissionByAction
from apps.subscriptions_api.permissions import requires_feature
from apps.subscriptions_api.validators import SubscriptionLimitValidator
from .models import Client, LoyaltyTransaction
from .serializers import ClientSerializer

class ClientViewSet(AuditLoggingMixin, TenantScopedViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer
    permission_classes = [TenantPermissionByAction]
    permission_map = {
        'list': 'clients_api.view_client',
        'retrieve': 'clients_api.view_client',
        'create': 'clients_api.add_client',
        'update': 'clients_api.change_client',
        'partial_update': 'clients_api.change_client',
        'destroy': 'clients_api.delete_client',
        'history': 'clients_api.view_client',
        'loyalty_history': 'clients_api.view_client',
        'add_loyalty_points': 'clients_api.change_client',
        'redeem_points': 'clients_api.change_client',
        'stats': 'clients_api.view_client',
        'birthdays_this_month': 'clients_api.view_client',
        'birthdays_today': 'clients_api.view_client',
        'upcoming_birthdays': 'clients_api.view_client',
    }

    filter_backends = [
        DjangoFilterBackend,
        filters.SearchFilter,
        filters.OrderingFilter
    ]
    filterset_fields = ['gender', 'is_active', 'preferred_stylist', 'branch']
    search_fields = ['full_name', 'email', 'phone']
    ordering_fields = ['created_at', 'updated_at', 'last_visit']
    ordering = ['-created_at']

    def perform_create(self, serializer):
        tenant = getattr(self.request, 'tenant', None) or getattr(self.request.user, 'tenant', None)
        if not tenant and not self.request.user.is_superuser:
            raise ValidationError('Usuario sin tenant asignado')

        SubscriptionLimitValidator.validate_client_limit(self.request.user, tenant=tenant)

        # Branch enforcement for employees (copied from TenantScopedViewSet to avoid bypass)
        save_kwargs = {'tenant': tenant, 'created_by': self.request.user}
        user = self.request.user
        if user and getattr(user, 'is_authenticated', False) and not user.is_superuser:
            from apps.auth_api.role_utils import get_effective_role_api
            user_role = get_effective_role_api(user, tenant=tenant)
            if user_role != 'CLIENT_ADMIN' and hasattr(user, 'employee_profile') and user.employee_profile:
                if user.employee_profile.branch_id:
                    branch = serializer.validated_data.get('branch')
                    if branch and branch.id != user.employee_profile.branch_id:
                        from rest_framework.exceptions import PermissionDenied
                        raise PermissionDenied("No tienes permiso para crear clientes en otra sucursal")
                    save_kwargs['branch_id'] = user.employee_profile.branch_id

        instance = serializer.save(**save_kwargs)
        self.log_action('create', instance, self.request.user, self.request)
        return instance

    @action(detail=True, methods=['get'])
    @requires_feature('client_history')
    def history(self, request, pk=None):
        client = self.get_object()
        from apps.appointments_api.models import Appointment
        from apps.pos_api.models import Sale
        
        appointments = Appointment.objects.filter(client=client).order_by('-date_time')[:10]
        sales = Sale.objects.filter(client=client).order_by('-date_time')[:10]
        
        return Response({
            'appointments': [{
                'id': apt.id,
                'date_time': apt.date_time,
                'status': apt.status,
                'service': apt.service.name if apt.service else None,
                'stylist': apt.stylist.full_name if apt.stylist else None
            } for apt in appointments],
            'sales': [{
                'id': sale.id,
                'date_time': sale.date_time,
                'total': sale.total,
                'payment_method': sale.payment_method
            } for sale in sales]
        })

    @action(detail=True, methods=['post'])
    @requires_feature('client_history')
    def add_loyalty_points(self, request, pk=None):
        from django.db import transaction
        from django.db.models import F
        client = self.get_object()
        try:
            points = int(request.data.get('points', 0))
        except (ValueError, TypeError):
            return Response({'error': 'Puntos deben ser un número entero'}, status=status.HTTP_400_BAD_REQUEST)
        if points <= 0 or points > 10000:
            return Response({'error': 'Puntos deben estar entre 1 y 10000'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            Client.objects.select_for_update().filter(pk=client.pk)
            Client.objects.filter(pk=client.pk).update(loyalty_points=F('loyalty_points') + points)
            LoyaltyTransaction.objects.create(client=client, points=points, transaction_type='earned', description=f'Puntos agregados manualmente: {points}')
            client.refresh_from_db()
        return Response({'detail': f'{points} puntos agregados. Total: {client.loyalty_points}'})

    @action(detail=True, methods=['post'])
    @requires_feature('client_history')
    def redeem_points(self, request, pk=None):
        from django.db import transaction
        from django.db.models import F
        client = self.get_object()
        try:
            points = int(request.data.get('points', 0))
        except (ValueError, TypeError):
            return Response({'error': 'Puntos deben ser un número entero'}, status=status.HTTP_400_BAD_REQUEST)
        if points <= 0:
            return Response({'error': 'Puntos deben ser mayor a 0'}, status=status.HTTP_400_BAD_REQUEST)
        with transaction.atomic():
            locked = Client.objects.select_for_update().get(pk=client.pk)
            if locked.loyalty_points < points:
                return Response({'error': 'Puntos insuficientes'}, status=status.HTTP_400_BAD_REQUEST)
            Client.objects.filter(pk=client.pk).update(loyalty_points=F('loyalty_points') - points)
            LoyaltyTransaction.objects.create(client=locked, points=points, transaction_type='redeemed', description=f'Puntos canjeados: {points}')
            locked.refresh_from_db()
            client = locked
        return Response({'detail': f'{points} puntos canjeados. Restantes: {client.loyalty_points}'})

    @action(detail=True, methods=['get'])
    def stats(self, request, pk=None):
        client = self.get_object()
        from apps.appointments_api.models import Appointment
        from apps.pos_api.models import Sale
        from django.db import models
        
        total_appointments = Appointment.objects.filter(client=client).count()
        completed_appointments = Appointment.objects.filter(client=client, status='completed').count()
        total_spent = Sale.objects.filter(client=client).aggregate(
            total=models.Sum('total')
        )['total'] or 0
        
        return Response({
            'total_appointments': total_appointments,
            'completed_appointments': completed_appointments,
            'total_spent': float(total_spent),
            'loyalty_points': client.loyalty_points,
            'last_visit': client.last_visit
        })

    @action(detail=True, methods=['get'])
    def loyalty_history(self, request, pk=None):
        client = self.get_object()
        transactions = LoyaltyTransaction.objects.filter(client=client)[:50]
        return Response([{
            'id': t.id,
            'points': t.points,
            'transaction_type': t.transaction_type,
            'description': t.description,
            'sale_id': t.sale_id,
            'created_at': t.created_at
        } for t in transactions])

    @action(detail=False, methods=['get'])
    def birthdays_this_month(self, request):
        from django.utils import timezone
        current_month = timezone.now().month
        
        clients = self.get_queryset().filter(
            birthday__month=current_month,
            is_active=True
        ).order_by('birthday__day')
        
        page = self.paginate_queryset(clients)
        if page is not None:
            serializer = ClientSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = ClientSerializer(clients, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def birthdays_today(self, request):
        from django.utils import timezone
        today = timezone.now().date()
        
        clients = self.get_queryset().filter(
            birthday__month=today.month,
            birthday__day=today.day,
            is_active=True
        )
        
        page = self.paginate_queryset(clients)
        if page is not None:
            serializer = ClientSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = ClientSerializer(clients, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def upcoming_birthdays(self, request):
        from django.utils import timezone
        from datetime import timedelta
        
        today = timezone.now().date()
        next_week = today + timedelta(days=7)
        
        # Clientes con cumpleaños en los próximos 7 días
        clients = self.get_queryset().filter(
            birthday__month__in=[today.month, next_week.month],
            is_active=True
        ).extra(
            select={
                'days_until_birthday': """
                    CASE 
                        WHEN EXTRACT(month FROM birthday) = %s AND EXTRACT(day FROM birthday) >= %s THEN 
                            EXTRACT(day FROM birthday) - %s
                        WHEN EXTRACT(month FROM birthday) = %s THEN 
                            EXTRACT(day FROM birthday) + (31 - %s)
                        ELSE 999
                    END
                """
            },
            select_params=[today.month, today.day, today.day, next_week.month, today.day]
        ).extra(
            where=["days_until_birthday <= 7"]
        ).order_by('days_until_birthday')
        
        serializer = ClientSerializer(clients, many=True)
        return Response(serializer.data)
