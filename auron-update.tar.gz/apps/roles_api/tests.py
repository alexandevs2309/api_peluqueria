from django.http import JsonResponse
from django.http import HttpRequest
import pytest
from rest_framework import status
from unittest.mock import patch
from rest_framework.test import APIClient, APIRequestFactory
from django.urls import reverse
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management import call_command

from apps.roles_api.permissions import IsActiveAndRolePermission
from apps.auth_api.factories import UserFactory
from apps.auth_api.models import User
from apps.roles_api.models import Role, UserRole, AdminActionLog
from apps.roles_api.permissions import RolePermission, role_permission_for
from apps.auth_api.utils import get_client_ip
from apps.roles_api.decorators import admin_action_log, permission_required
from apps.roles_api.default_permissions import ensure_role_default_permissions



@pytest.fixture
def admin_user(db):
    user = UserFactory(is_email_verified=True, is_superuser=True)
    admin_role, _ = Role.objects.get_or_create(name='Admin')
    UserRole.objects.get_or_create(user=user, role=admin_role, tenant=user.tenant)
    return user

@pytest.fixture
def client_user(db):
    user = UserFactory(is_email_verified=True)
    client_role, _ = Role.objects.get_or_create(name='Client')
    UserRole.objects.get_or_create(user=user, role=client_role, tenant=user.tenant)
    return user

@pytest.mark.django_db
def test_list_roles_as_admin(admin_user):
    Role.objects.get_or_create(name='Stylist')
    Role.objects.get_or_create(name='Utility')

    client = APIClient()
    client.force_authenticate(user=admin_user)

    response = client.get(reverse('role-list'))
    assert response.status_code == 200
    assert len(response.data) >= 3
    role_names = [r['name'] for r in response.data]
    assert 'Admin' in role_names

    assert AdminActionLog.objects.filter(user=admin_user, action='List roles').exists()

@pytest.mark.django_db
def test_list_roles_as_non_admin(client_user):
    client = APIClient()
    client.force_authenticate(user=client_user)

    response = client.get(reverse('role-list'))
    assert response.status_code == 403
    assert 'detail' in response.data['details']

    assert not AdminActionLog.objects.filter(user=client_user, action='List roles').exists()

@pytest.mark.django_db
def test_retrieve_role_as_admin(admin_user):
    role, _ = Role.objects.get_or_create(name='Stylist')
    permission = Permission.objects.first()
    if permission:
        role.permissions.add(permission)

    client = APIClient()
    client.force_authenticate(user=admin_user)

    response = client.get(reverse('role-detail', kwargs={'pk': role.id}))
    assert response.status_code == 200
    assert response.data['name'] == 'Stylist'
    if permission:
        assert len(response.data['permissions']) >= 1

    assert AdminActionLog.objects.filter(user=admin_user, action='Retrieve role').exists()

@pytest.mark.django_db
def test_create_role_as_admin(admin_user):
    client = APIClient()
    client.force_authenticate(user=admin_user)

    permission = Permission.objects.first()
    data = {
        'name': 'Manager-Special',
        'description': 'Role for managers',
    }
    if permission:
        data['permissions'] = [permission.id]

    response = client.post(reverse('role-list'), data, format='json')
    assert response.status_code == 201
    role = Role.objects.get(name='Manager-Special')
    assert role.description == 'Role for managers'
    if permission:
        assert role.permissions.exists()

    assert AdminActionLog.objects.filter(user=admin_user, action='Create role').exists()

@pytest.mark.django_db
def test_update_role_as_admin(admin_user):
    role, _ = Role.objects.get_or_create(name='Stylist', defaults={'description': 'Original description'})

    client = APIClient()
    client.force_authenticate(user=admin_user)

    data = {'name': 'Senior Stylist', 'description': 'Updated description'}
    response = client.put(reverse('role-detail', kwargs={'pk': role.id}), data, format='json')
    assert response.status_code == 200

    role.refresh_from_db()
    assert role.name == 'Senior Stylist'
    assert role.description == 'Updated description'

    assert AdminActionLog.objects.filter(user=admin_user, action='Update role').exists()

@pytest.mark.django_db
def test_delete_role_as_admin(admin_user):
    role, _ = Role.objects.get_or_create(name='Utility')

    client = APIClient()
    client.force_authenticate(user=admin_user)

    response = client.delete(reverse('role-detail', kwargs={'pk': role.id}))
    assert response.status_code == 204
    assert not Role.objects.filter(name='Utility').exists()

    assert AdminActionLog.objects.filter(user=admin_user, action='Delete role').exists()

@pytest.mark.django_db
def test_list_permissions_as_admin(admin_user):
    client = APIClient()
    client.force_authenticate(user=admin_user)

    response = client.get(reverse('list_permissions'))
    assert response.status_code == 200
    assert response.data['results']
    assert 'codename' in response.data['results'][0]

    assert AdminActionLog.objects.filter(user=admin_user, action='List permissions').exists()

@pytest.mark.django_db
def test_roles_unauthenticated():
    client = APIClient()
    response = client.get(reverse('role-list'))
    assert response.status_code == 401
    assert 'detail' in response.data['details']

@pytest.mark.django_db
def test_retrieve_role_as_non_admin(client_user):
    role, _ = Role.objects.get_or_create(name='Test Role')

    client = APIClient()
    client.force_authenticate(user=client_user)

    response = client.get(reverse('role-detail', kwargs={'pk': role.id}))
    assert response.status_code == 403

@pytest.mark.django_db
def test_create_role_as_non_admin(client_user):
    client = APIClient()
    client.force_authenticate(user=client_user)

    data = {'name': 'New Role', 'description': 'Test role'}
    response = client.post(reverse('role-list'), data, format='json')
    assert response.status_code == 403

@pytest.mark.django_db
def test_roles_api_permission_denies_anonymous():
    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = None
    perm = RolePermission(allowed_roles=['Admin'])
    assert not perm.has_permission(request, None)

@pytest.mark.django_db
def test_roles_api_permission_allows_superuser():
    user = User.objects.create_superuser(email="super@test.com", password="123456", full_name="Super User")
    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = user
    perm = RolePermission(allowed_roles=['Any'])
    assert perm.has_permission(request, None)

@pytest.mark.django_db
def test_roles_api_permission_allows_with_role():
    user = UserFactory(email="user@test.com", password="123456", full_name="User Test")
    role, _ = Role.objects.get_or_create(name="Stylist")
    UserRole.objects.get_or_create(user=user, role=role, tenant=user.tenant)

    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = user
    perm = RolePermission(allowed_roles=['Estilista'])
    assert perm.has_permission(request, None)

@pytest.mark.django_db
def test_roles_api_permission_denies_without_role():
    user = UserFactory(email="user2@test.com", password="123456", full_name="User2 Test")
    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = user
    perm = RolePermission(allowed_roles=['Manager'])
    assert not perm.has_permission(request, None)


@pytest.mark.django_db
def test_inactive_user_denied_permission():
    user = UserFactory(is_email_verified=True, is_active=False)
    role, _ = Role.objects.get_or_create(name="Admin")
    UserRole.objects.create(user=user, role=role, tenant=user.tenant)

    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = user

    perm = IsActiveAndRolePermission(['Admin'])
    assert not perm.has_permission(request, None)


@pytest.mark.django_db
def test_role_permission_for_dynamic_class():
    user = UserFactory(email="dynamic@test.com", password="123456", full_name="Dynamic Test")
    role, _ = Role.objects.get_or_create(name="Manager")
    UserRole.objects.get_or_create(user=user, role=role, tenant=user.tenant)

    factory = APIRequestFactory()
    request = factory.get('/')
    request.user = user

    DynamicPerm = role_permission_for(['Manager'])
    perm_instance = DynamicPerm()
    assert perm_instance.has_permission(request, None)


def test_get_client_ip_with_forwarded_for():
    request = HttpRequest()
    request.META['HTTP_X_FORWARDED_FOR'] = '1.2.3.4, 5.6.7.8'
    ip = get_client_ip(request)
    assert ip == '1.2.3.4'

def test_get_client_ip_without_forwarded_for():
    request = HttpRequest()
    request.META['REMOTE_ADDR'] = '9.8.7.6'
    ip = get_client_ip(request)
    assert ip == '9.8.7.6'

@pytest.mark.django_db
def test_role_permission_denied_for_inactive_user():
    user = UserFactory(email="inactive@test.com", password="123456", full_name="Inactive User", is_active=False)
    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = user
    perm = RolePermission(allowed_roles=["Admin"])
    assert not perm.has_permission(request, None)


@pytest.mark.django_db
def test_admin_action_log_creates_log_entry(admin_user):

    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = admin_user

    @admin_action_log("delete_user")
    def view_ok(request):
        return JsonResponse({"success": True})

    response = view_ok(request)
    assert response.status_code == 200
    assert AdminActionLog.objects.filter(user=admin_user, action="delete_user").exists()


@pytest.mark.django_db
def test_admin_action_log_swallows_logging_error(admin_user):
    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = admin_user

    @admin_action_log("delete_user")
    def view_ok(request):
        return JsonResponse({"success": True})

    with patch("apps.roles_api.decorators.AdminActionLog.objects.create", side_effect=Exception("DB error")):
        response = view_ok(request)
        assert response.status_code == 200

    assert not AdminActionLog.objects.filter(user=admin_user, action="delete_user").exists()

class DummyPermission:
    def has_permission(self, request, view):
        return False

@pytest.mark.django_db
def test_permission_required_decorator_denies_access(db):
    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = UserFactory(email="denied@test.com", password="testpass")

    @permission_required(DummyPermission)
    def dummy_view(request):
        return response({"success": True})

    response = dummy_view(request)
    assert response.status_code == status.HTTP_403_FORBIDDEN


@pytest.mark.django_db
def test_sync_roles_assigns_permissions_to_role_m2m():
    content_type, _ = ContentType.objects.get_or_create(
        app_label="clients_api",
        model="client",
    )
    permission, _ = Permission.objects.get_or_create(
        content_type=content_type,
        codename="view_client",
        defaults={"name": "Can view client"},
    )
    role, _ = Role.objects.get_or_create(name="Client-Admin")
    role.permissions.clear()

    call_command("sync_roles")

    role.refresh_from_db()
    assert role.permissions.filter(id=permission.id).exists()


@pytest.mark.django_db
def test_ensure_role_default_permissions_repairs_incomplete_client_admin_role():
    content_type, _ = ContentType.objects.get_or_create(
        app_label="auth_api",
        model="user",
    )
    permission, _ = Permission.objects.get_or_create(
        content_type=content_type,
        codename="view_user",
        defaults={"name": "Can view user"},
    )
    role, _ = Role.objects.get_or_create(name="Client-Admin")
    role.permissions.clear()
    existing_permission = Permission.objects.first()
    if existing_permission:
        role.permissions.add(existing_permission)

    assigned = ensure_role_default_permissions(role)

    assert assigned >= 1
    assert role.permissions.filter(id=permission.id).exists()
    if existing_permission:
        assert role.permissions.filter(id=existing_permission.id).exists()
